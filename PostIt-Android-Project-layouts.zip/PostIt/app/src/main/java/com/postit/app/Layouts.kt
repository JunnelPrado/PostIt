@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)

package com.postit.app

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.staggeredgrid.LazyVerticalStaggeredGrid
import androidx.compose.foundation.lazy.staggeredgrid.StaggeredGridCells
import androidx.compose.foundation.lazy.staggeredgrid.StaggeredGridItemSpan
import androidx.compose.foundation.lazy.staggeredgrid.itemsIndexed
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import kotlinx.coroutines.launch
import java.io.File
import kotlin.math.abs

// =====================================================================================================================
// Layout catalogue
// =====================================================================================================================

class LayoutInfo(val key: String, val label: String, val hint: String, val group: String)

/** Every way the homepage can show your memories. "list" and "grid" are drawn by MainActivity, the rest by this file. */
val LAYOUTS = listOf(
    LayoutInfo("sticky", "Sticky notes", "Colourful post-its", "Notes"),
    LayoutInfo("polaroid", "Polaroid", "Taped instant photos", "Pictures"),
    LayoutInfo("mosaic", "Mosaic", "Bento photo collage", "Pictures"),
    LayoutInfo("magazine", "Magazine", "Big hero stories", "Pictures"),
    LayoutInfo("gallery", "Gallery", "Tight square tiles", "Pictures"),
    LayoutInfo("carousel", "Carousel", "Swipe big cards", "Pictures"),
    LayoutInfo("list", "List", "Classic rows", "Classic"),
    LayoutInfo("grid", "Grid", "Staggered cards", "Classic")
)

/** Looks a layout up by key. Unknown keys (old saves) fall back to the list. */
fun layoutInfo(key: String): LayoutInfo = LAYOUTS.firstOrNull { it.key == key } ?: LAYOUTS.first { it.key == "list" }

/** What a tap, long-press menu entry or delete does to a memory. */
class MemoryActions(val open: (Memory) -> Unit, val edit: (Memory) -> Unit, val pin: (Memory) -> Unit, val delete: (Memory) -> Unit)

/** Everything a layout needs besides the entries themselves. */
class LayoutEnv(val pal: Pal, val filter: String, val heading: String, val count: String, val floatStyle: String, val act: MemoryActions)

fun entryKey(e: Entry): Any = when (e) {
    is Entry.Title -> "title"
    is Entry.Empty -> "empty"
    is Entry.Header -> "h_${e.text}"
    is Entry.Item -> e.m.file
}

// =====================================================================================================================
// Paper, tape and pins (shared look of the sticky notes)
// =====================================================================================================================

private class PaperTone(val top: Color, val bottom: Color)

private val PAPERS = listOf(
    PaperTone(Color(0xFFFFF59D), Color(0xFFFFEB6B)), // yellow
    PaperTone(Color(0xFFF8BBD0), Color(0xFFF48FB1)), // pink
    PaperTone(Color(0xFFC5E8B7), Color(0xFFA5D6A7)), // mint
    PaperTone(Color(0xFFB3E5FC), Color(0xFF81D4FA)), // sky
    PaperTone(Color(0xFFFFCC80), Color(0xFFFFB74D)), // orange
    PaperTone(Color(0xFFD1C4E9), Color(0xFFB39DDB)), // lavender
    PaperTone(Color(0xFFE6EE9C), Color(0xFFD4E157))  // lime
)
private val PAPER_INK = Color(0xFF2B2418)
private val TAPES = listOf(Color(0xFFFFF3B0), Color(0xFFFFC1D6), Color(0xFFB8E6FF), Color(0xFFC8F0C8))

private fun seedOf(m: Memory): Int = m.file.hashCode() and 0x7fffffff
private fun paperOf(m: Memory): PaperTone = PAPERS[seedOf(m) % PAPERS.size]

/** A steady tilt for this memory between -max and +max degrees (the same every time the page is drawn). */
private fun tiltOf(m: Memory, max: Float): Float = (((seedOf(m) / 7) % 2001) / 1000f - 1f) * max

/** A post-it with its bottom-right corner folded over. */
private class FoldShape(private val fold: Float) : Shape {
    override fun createOutline(size: Size, layoutDirection: LayoutDirection, density: Density): Outline =
        Outline.Generic(Path().apply {
            moveTo(0f, 0f)
            lineTo(size.width, 0f)
            lineTo(size.width, size.height - fold)
            lineTo(size.width - fold, size.height)
            lineTo(0f, size.height)
            close()
        })
}

private fun DrawScope.drawFlap(fold: Float) {
    val w = this.size.width
    val h = this.size.height
    val flap = Path().apply {
        moveTo(w, h - fold); lineTo(w - fold, h); lineTo(w - fold, h - fold); close()
    }
    drawPath(
        flap,
        Brush.linearGradient(
            listOf(Color.White.copy(alpha = 0.55f), Color.Black.copy(alpha = 0.20f)),
            start = Offset(w - fold, h - fold), end = Offset(w - fold / 2f, h - fold / 2f)
        )
    )
}

@Composable
private fun PushPin(modifier: Modifier = Modifier) {
    Canvas(modifier.size(24.dp)) {
        val w = this.size.width
        drawCircle(Color.Black.copy(alpha = 0.22f), w * 0.34f, Offset(w * 0.58f, w * 0.64f))
        drawCircle(Color(0xFFD32F2F), w * 0.36f, Offset(w * 0.5f, w * 0.5f))
        drawCircle(Color(0xFFFF8A80), w * 0.13f, Offset(w * 0.4f, w * 0.38f))
    }
}

@Composable
private fun Tape(color: Color, tilt: Float, modifier: Modifier = Modifier) {
    Box(modifier.size(width = 58.dp, height = 18.dp).graphicsLayer { rotationZ = tilt }.background(color.copy(alpha = 0.66f)))
}

/** Menu shown when a tile is long-pressed. Same entries as the classic cards. */
@Composable
private fun TileMenu(expanded: Boolean, m: Memory, act: MemoryActions, onDismiss: () -> Unit) {
    DropdownMenu(expanded, onDismiss) {
        if (!m.note) DropdownMenuItem({ Text("View picture") }, { onDismiss(); act.open(m) })
        DropdownMenuItem({ Text(if (m.note) "Edit note" else "Edit caption") }, { onDismiss(); act.edit(m) })
        DropdownMenuItem({ Text(if (m.pinned) "Unpin" else "Pin to top") }, { onDismiss(); act.pin(m) })
        DropdownMenuItem({ Text("Delete") }, { onDismiss(); act.delete(m) })
    }
}

/** Handwritten title, body preview and date of a text note. Fills the space it gets and fades out at the bottom edge. */
@Composable
private fun NoteFace(m: Memory, titleSp: Int, bodySp: Int, fade: Color, showDate: Boolean, modifier: Modifier = Modifier) {
    Column(modifier) {
        Box(Modifier.weight(1f).fillMaxWidth().clipToBounds()) {
            Column(Modifier.fillMaxWidth()) {
                if (m.caption.isNotEmpty()) Text(
                    m.caption, color = PAPER_INK, fontFamily = FontFamily.Cursive, fontWeight = FontWeight.Bold,
                    fontSize = titleSp.sp, lineHeight = (titleSp + 4).sp, maxLines = 2, overflow = TextOverflow.Ellipsis
                )
                if (m.body.isNotEmpty()) Text(
                    m.body, Modifier.padding(top = if (m.caption.isNotEmpty()) 4.dp else 0.dp), color = PAPER_INK.copy(alpha = 0.86f),
                    fontFamily = FontFamily.Cursive, fontSize = bodySp.sp, lineHeight = (bodySp + 5).sp, maxLines = 14, overflow = TextOverflow.Ellipsis
                )
            }
            Box(
                Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(20.dp)
                    .background(Brush.verticalGradient(listOf(Color.Transparent, fade)))
            )
        }
        if (showDate) Text(postedLabel(m.time, true), Modifier.padding(top = 6.dp), color = PAPER_INK.copy(alpha = 0.55f), fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

// =====================================================================================================================
// Sticky note (used by the Sticky notes view and as the text-note tile in picture layouts)
// =====================================================================================================================

@Composable
fun StickyNote(m: Memory, index: Int, env: LayoutEnv, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    val seed = seedOf(m)
    val tone = paperOf(m)
    val tilt = tiltOf(m, 3.2f)
    val fold = with(LocalDensity.current) { 20.dp.toPx() }
    val shape = remember(fold) { FoldShape(fold) }
    var menu by remember { mutableStateOf(false) }
    // Text notes are square-ish like real post-its; pictures keep their own height.
    val ratio = listOf(1f, 0.92f, 1.08f, 0.86f)[(seed / 3) % 4]
    val imgRatio = listOf(1.1f, 0.95f, 1.25f, 0.85f)[(seed / 5) % 4]

    Box(modifier.padding(start = 6.dp, end = 6.dp, top = 12.dp, bottom = 8.dp).floating(env.floatStyle, index).graphicsLayer { rotationZ = tilt }) {
        Column(
            Modifier.fillMaxWidth()
                .shadow(7.dp, shape, clip = false)
                .clip(shape)
                .background(Brush.verticalGradient(listOf(tone.top, tone.bottom)))
                .drawWithContent { drawContent(); drawFlap(fold) }
                .combinedClickable(onClick = { env.act.open(m) }, onLongClick = { menu = true })
                .then(if (m.note) Modifier.aspectRatio(ratio) else Modifier)
                .padding(start = if (m.note) 14.dp else 10.dp, end = if (m.note) 14.dp else 10.dp, top = if (m.note) 22.dp else 16.dp, bottom = 12.dp)
        ) {
            if (m.note) {
                NoteFace(m, 21, 17, tone.bottom, true, Modifier.fillMaxSize())
            } else {
                AsyncImage(
                    File(ctx.filesDir, m.file), m.caption,
                    Modifier.fillMaxWidth().aspectRatio(imgRatio).clip(RoundedCornerShape(3.dp)),
                    contentScale = ContentScale.Crop
                )
                if (m.caption.isNotEmpty()) Text(
                    m.caption, Modifier.padding(top = 8.dp).fillMaxWidth().clickable { env.act.edit(m) }, color = PAPER_INK,
                    fontFamily = FontFamily.Cursive, fontWeight = FontWeight.Bold, fontSize = 19.sp, lineHeight = 22.sp,
                    maxLines = 2, overflow = TextOverflow.Ellipsis
                )
                Text(postedLabel(m.time, true), Modifier.padding(top = 4.dp), color = PAPER_INK.copy(alpha = 0.55f), fontSize = 10.sp, maxLines = 1)
            }
        }
        if (m.pinned) PushPin(Modifier.align(Alignment.TopCenter).offset(y = (-10).dp))
        else Tape(TAPES[seed % TAPES.size], tilt * -1.6f, Modifier.align(Alignment.TopCenter).offset(y = (-9).dp))
        TileMenu(menu, m, env.act) { menu = false }
    }
}

// =====================================================================================================================
// Polaroid
// =====================================================================================================================

@Composable
fun PolaroidCard(m: Memory, index: Int, env: LayoutEnv, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    val seed = seedOf(m)
    val tilt = tiltOf(m, 4f)
    val ratio = listOf(1f, 0.84f, 1f, 1.15f)[(seed / 5) % 4]
    val shape = RoundedCornerShape(4.dp)
    var menu by remember { mutableStateOf(false) }

    Box(modifier.padding(start = 6.dp, end = 6.dp, top = 14.dp, bottom = 10.dp).floating(env.floatStyle, index).graphicsLayer { rotationZ = tilt }) {
        Column(
            Modifier.fillMaxWidth()
                .shadow(8.dp, shape, clip = false).clip(shape).background(Color(0xFFFDFBF6))
                .combinedClickable(onClick = { env.act.open(m) }, onLongClick = { menu = true })
                .padding(start = 9.dp, end = 9.dp, top = 9.dp, bottom = 10.dp)
        ) {
            AsyncImage(
                File(ctx.filesDir, m.file), m.caption,
                Modifier.fillMaxWidth().aspectRatio(ratio).background(Color(0xFFE6E2D8)),
                contentScale = ContentScale.Crop
            )
            Spacer(Modifier.height(8.dp))
            if (m.caption.isNotEmpty()) Text(
                m.caption, Modifier.fillMaxWidth().clickable { env.act.edit(m) }, color = Color(0xFF2B2B2B),
                fontFamily = FontFamily.Cursive, fontWeight = FontWeight.Bold, fontSize = 20.sp, lineHeight = 23.sp,
                maxLines = 2, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center
            )
            Text(postedLabel(m.time, true), Modifier.fillMaxWidth(), color = Color(0xFF8A857A), fontSize = 10.sp, maxLines = 1, textAlign = TextAlign.Center)
        }
        if (m.pinned) PushPin(Modifier.align(Alignment.TopCenter).offset(y = (-12).dp))
        else Tape(TAPES[(seed / 11) % TAPES.size], tilt * 1.5f, Modifier.align(Alignment.TopCenter).offset(y = (-11).dp))
        TileMenu(menu, m, env.act) { menu = false }
    }
}

// =====================================================================================================================
// Photo tile: one rounded picture (or coloured note) used by Mosaic, Magazine, Gallery and Carousel
// =====================================================================================================================

private enum class TileSize { Small, Medium, Big }

@Composable
private fun PhotoTile(m: Memory, env: LayoutEnv, modifier: Modifier, radius: Dp, size: TileSize, showCaption: Boolean = true) {
    val ctx = LocalContext.current
    val shape = RoundedCornerShape(radius)
    var menu by remember { mutableStateOf(false) }
    Box(modifier.clip(shape).combinedClickable(onClick = { env.act.open(m) }, onLongClick = { menu = true })) {
        if (m.note) {
            val tone = paperOf(m)
            Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(tone.top, tone.bottom))))
            val pad = when (size) { TileSize.Small -> 7.dp; TileSize.Medium -> 12.dp; TileSize.Big -> 18.dp }
            NoteFace(
                m, when (size) { TileSize.Small -> 14; TileSize.Medium -> 19; TileSize.Big -> 26 },
                when (size) { TileSize.Small -> 12; TileSize.Medium -> 15; TileSize.Big -> 19 },
                tone.bottom, size != TileSize.Small, Modifier.fillMaxSize().padding(pad)
            )
        } else {
            AsyncImage(File(ctx.filesDir, m.file), m.caption, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            if (showCaption && size != TileSize.Small && m.caption.isNotEmpty()) {
                Box(
                    Modifier.align(Alignment.BottomStart).fillMaxWidth()
                        .background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = 0.62f))))
                        .padding(start = 10.dp, end = 10.dp, top = 24.dp, bottom = 9.dp)
                ) {
                    Text(
                        m.caption, color = Color.White, fontSize = if (size == TileSize.Big) 18.sp else 12.sp,
                        fontWeight = FontWeight.SemiBold, maxLines = if (size == TileSize.Big) 2 else 1, overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
        if (m.pinned) PushPin(Modifier.align(Alignment.TopEnd).padding(4.dp))
        TileMenu(menu, m, env.act) { menu = false }
    }
}

// =====================================================================================================================
// Block builder: groups the pictures between two headings into rows of a repeating pattern
// =====================================================================================================================

private const val P_BIG_LEFT = 0   // one big tile (2/3 wide) and two stacked tiles; 3 memories
private const val P_PAIR = 1       // two portrait tiles; 2 memories
private const val P_WIDE = 2       // one wide tile; 1 memory
private const val P_BIG_RIGHT = 3  // two stacked tiles and one big tile; 3 memories
private const val P_TRIO = 4       // three squares; 3 memories

private fun patternSize(p: Int): Int = when (p) { P_WIDE -> 1; P_PAIR -> 2; else -> 3 }

private sealed class LBlock {
    class Section(val e: Entry, val index: Int) : LBlock()
    class Tiles(val items: List<Memory>, val pattern: Int) : LBlock()
}

private fun blockKey(b: LBlock): Any = when (b) {
    is LBlock.Section -> entryKey(b.e)
    is LBlock.Tiles -> "tiles_" + b.items.first().file
}

private fun blocksOf(entries: List<Entry>, sequence: List<Int>): List<LBlock> {
    val out = ArrayList<LBlock>()
    val pending = ArrayList<Memory>()
    var cycle = 0
    fun flush() {
        var i = 0
        while (i < pending.size) {
            val want = sequence[cycle % sequence.size]
            val left = pending.size - i
            // Not enough pictures left for the wanted pattern: finish with a pair or a single wide tile.
            val use = if (left >= patternSize(want)) want else if (left == 1) P_WIDE else P_PAIR
            val n = patternSize(use)
            out.add(LBlock.Tiles(pending.subList(i, i + n).toList(), use))
            i += n
            cycle++
        }
        pending.clear()
    }
    entries.forEachIndexed { idx, e ->
        if (e is Entry.Item) pending.add(e.m) else { flush(); out.add(LBlock.Section(e, idx)) }
    }
    flush()
    return out
}

/** Title, section headers and the "no notes" message: drawn exactly like the classic views. */
@Composable
private fun SectionRow(e: Entry, index: Int, env: LayoutEnv) {
    EntryContent(e, index, false, env.pal, env.filter, env.heading, env.count, env.floatStyle, {}, {}, {}, {})
}

// =====================================================================================================================
// Mosaic (bento collage)
// =====================================================================================================================

@Composable
private fun MosaicBlock(b: LBlock.Tiles, env: LayoutEnv) {
    val g = 8.dp
    val t = b.items
    val r = 18.dp
    when (b.pattern) {
        P_BIG_LEFT -> Row(Modifier.fillMaxWidth().aspectRatio(1.5f), horizontalArrangement = Arrangement.spacedBy(g)) {
            PhotoTile(t[0], env, Modifier.weight(2f).fillMaxHeight(), r, TileSize.Big)
            Column(Modifier.weight(1f).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(g)) {
                PhotoTile(t[1], env, Modifier.weight(1f).fillMaxWidth(), r, TileSize.Small)
                PhotoTile(t[2], env, Modifier.weight(1f).fillMaxWidth(), r, TileSize.Small)
            }
        }
        P_BIG_RIGHT -> Row(Modifier.fillMaxWidth().aspectRatio(1.5f), horizontalArrangement = Arrangement.spacedBy(g)) {
            Column(Modifier.weight(1f).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(g)) {
                PhotoTile(t[1], env, Modifier.weight(1f).fillMaxWidth(), r, TileSize.Small)
                PhotoTile(t[2], env, Modifier.weight(1f).fillMaxWidth(), r, TileSize.Small)
            }
            PhotoTile(t[0], env, Modifier.weight(2f).fillMaxHeight(), r, TileSize.Big)
        }
        P_PAIR -> Row(Modifier.fillMaxWidth().aspectRatio(1.55f), horizontalArrangement = Arrangement.spacedBy(g)) {
            PhotoTile(t[0], env, Modifier.weight(1f).fillMaxHeight(), r, TileSize.Medium)
            PhotoTile(t[1], env, Modifier.weight(1f).fillMaxHeight(), r, TileSize.Medium)
        }
        P_TRIO -> Row(Modifier.fillMaxWidth().aspectRatio(3.1f), horizontalArrangement = Arrangement.spacedBy(g)) {
            for (m in t) PhotoTile(m, env, Modifier.weight(1f).fillMaxHeight(), r, TileSize.Small)
        }
        else -> PhotoTile(t[0], env, Modifier.fillMaxWidth().aspectRatio(1.78f), r, TileSize.Big)
    }
}

@Composable
private fun MosaicHost(entries: List<Entry>, env: LayoutEnv, pad: PaddingValues) {
    val blocks = blocksOf(entries, listOf(P_BIG_LEFT, P_PAIR, P_WIDE, P_BIG_RIGHT, P_TRIO))
    LazyColumn(Modifier.fillMaxSize(), contentPadding = pad, verticalArrangement = Arrangement.spacedBy(8.dp)) {
        itemsIndexed(blocks, key = { _, b -> blockKey(b) }) { _, b ->
            when (b) {
                is LBlock.Section -> SectionRow(b.e, b.index, env)
                is LBlock.Tiles -> MosaicBlock(b, env)
            }
        }
    }
}

// =====================================================================================================================
// Magazine (hero story, then a staggered pair, and so on)
// =====================================================================================================================

@Composable
private fun MagazineHero(m: Memory, env: LayoutEnv) {
    val ctx = LocalContext.current
    val shape = RoundedCornerShape(28.dp)
    var menu by remember { mutableStateOf(false) }
    Box(Modifier.fillMaxWidth().aspectRatio(0.88f).clip(shape).combinedClickable(onClick = { env.act.open(m) }, onLongClick = { menu = true })) {
        if (m.note) {
            val tone = paperOf(m)
            Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(tone.top, tone.bottom))))
            NoteFace(m, 34, 22, tone.bottom, true, Modifier.fillMaxSize().padding(26.dp))
        } else {
            AsyncImage(File(ctx.filesDir, m.file), m.caption, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            Column(
                Modifier.align(Alignment.BottomStart).fillMaxWidth()
                    .background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = 0.78f))))
                    .padding(start = 20.dp, end = 20.dp, top = 70.dp, bottom = 20.dp)
            ) {
                Text(postedLabel(m.time, true).uppercase(), color = Accent, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.6.sp, maxLines = 1)
                if (m.caption.isNotEmpty()) Text(
                    m.caption, Modifier.padding(top = 4.dp), color = Color.White, fontFamily = FontFamily.Serif,
                    fontWeight = FontWeight.Bold, fontSize = 28.sp, lineHeight = 33.sp, maxLines = 3, overflow = TextOverflow.Ellipsis
                )
                if (m.body.isNotEmpty()) Text(
                    m.body, Modifier.padding(top = 6.dp), color = Color.White.copy(alpha = 0.85f), fontFamily = FontFamily.Serif,
                    fontStyle = FontStyle.Italic, fontSize = 14.sp, lineHeight = 19.sp, maxLines = 2, overflow = TextOverflow.Ellipsis
                )
            }
        }
        if (m.pinned) Text(
            "\uD83D\uDCCC PINNED", Modifier.align(Alignment.TopStart).padding(16.dp).clip(RoundedCornerShape(50)).background(Color.Black.copy(alpha = 0.45f)).padding(horizontal = 10.dp, vertical = 4.dp),
            color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp
        )
        TileMenu(menu, m, env.act) { menu = false }
    }
}

@Composable
private fun MagazineCard(m: Memory, env: LayoutEnv, modifier: Modifier) {
    Column(modifier) {
        PhotoTile(m, env, Modifier.fillMaxWidth().aspectRatio(0.78f), 22.dp, TileSize.Medium, showCaption = false)
        if (!m.note && m.caption.isNotEmpty()) Text(
            m.caption, Modifier.padding(top = 8.dp, start = 4.dp, end = 4.dp), color = env.pal.main, fontFamily = FontFamily.Serif,
            fontWeight = FontWeight.SemiBold, fontSize = 15.sp, lineHeight = 19.sp, maxLines = 2, overflow = TextOverflow.Ellipsis
        )
        Text(
            postedLabel(m.time, true).uppercase(), Modifier.padding(top = if (m.note) 8.dp else 2.dp, start = 4.dp), color = env.pal.sub,
            fontSize = 10.sp, letterSpacing = 1.2.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
private fun MagazineHost(entries: List<Entry>, env: LayoutEnv, pad: PaddingValues) {
    val blocks = blocksOf(entries, listOf(P_WIDE, P_PAIR))
    LazyColumn(Modifier.fillMaxSize(), contentPadding = pad, verticalArrangement = Arrangement.spacedBy(16.dp)) {
        itemsIndexed(blocks, key = { _, b -> blockKey(b) }) { _, b ->
            when (b) {
                is LBlock.Section -> SectionRow(b.e, b.index, env)
                is LBlock.Tiles -> if (b.pattern == P_WIDE) MagazineHero(b.items[0], env) else Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    MagazineCard(b.items[0], env, Modifier.weight(1f))
                    MagazineCard(b.items[1], env, Modifier.weight(1f).padding(top = 30.dp))
                }
            }
        }
    }
}

// =====================================================================================================================
// Gallery (tight square tiles)
// =====================================================================================================================

@Composable
private fun GalleryHost(entries: List<Entry>, env: LayoutEnv, pad: PaddingValues) {
    val w = LocalConfiguration.current.screenWidthDp
    val cols = when { w >= 900 -> 6; w >= 600 -> 5; else -> 3 }
    LazyVerticalGrid(
        GridCells.Fixed(cols), Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 3.dp, end = 3.dp, bottom = pad.calculateBottomPadding()),
        verticalArrangement = Arrangement.spacedBy(3.dp), horizontalArrangement = Arrangement.spacedBy(3.dp)
    ) {
        itemsIndexed(
            entries, key = { _, e -> entryKey(e) },
            span = { _, e -> if (e is Entry.Item) GridItemSpan(1) else GridItemSpan(maxLineSpan) }
        ) { i, e ->
            when (e) {
                is Entry.Item -> PhotoTile(e.m, env, Modifier.aspectRatio(1f), 6.dp, TileSize.Small)
                else -> Box(Modifier.padding(horizontal = 9.dp)) { SectionRow(e, i, env) }
            }
        }
    }
}

// =====================================================================================================================
// Carousel (swipe through big cards)
// =====================================================================================================================

@Composable
private fun CarouselCard(m: Memory, page: Int, total: Int, env: LayoutEnv, modifier: Modifier) {
    val ctx = LocalContext.current
    val shape = RoundedCornerShape(30.dp)
    var menu by remember { mutableStateOf(false) }
    Box(modifier.shadow(10.dp, shape, clip = false).clip(shape).combinedClickable(onClick = { env.act.open(m) }, onLongClick = { menu = true })) {
        if (m.note) {
            val tone = paperOf(m)
            Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(tone.top, tone.bottom))))
            NoteFace(m, 36, 24, tone.bottom, true, Modifier.fillMaxSize().padding(start = 26.dp, end = 26.dp, top = 56.dp, bottom = 24.dp))
        } else {
            AsyncImage(File(ctx.filesDir, m.file), m.caption, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            Column(
                Modifier.align(Alignment.BottomStart).fillMaxWidth()
                    .background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = 0.78f))))
                    .padding(start = 22.dp, end = 22.dp, top = 90.dp, bottom = 24.dp)
            ) {
                if (m.caption.isNotEmpty()) Text(
                    m.caption, color = Color.White, fontFamily = FontFamily.Serif, fontWeight = FontWeight.Bold,
                    fontSize = 28.sp, lineHeight = 33.sp, maxLines = 3, overflow = TextOverflow.Ellipsis
                )
                Text(postedLabel(m.time, false), Modifier.padding(top = 6.dp), color = Accent, fontSize = 13.sp, fontWeight = FontWeight.Medium, maxLines = 1)
            }
        }
        Text(
            "${page + 1} / $total", Modifier.align(Alignment.TopStart).padding(16.dp).clip(RoundedCornerShape(50)).background(Color.Black.copy(alpha = 0.45f)).padding(horizontal = 12.dp, vertical = 5.dp),
            color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold
        )
        if (m.pinned) PushPin(Modifier.align(Alignment.TopEnd).padding(14.dp))
        TileMenu(menu, m, env.act) { menu = false }
    }
}

@Composable
private fun CarouselHost(entries: List<Entry>, env: LayoutEnv, pad: PaddingValues) {
    val items = entries.filterIsInstance<Entry.Item>().map { it.m }
    Column(Modifier.fillMaxSize()) {
        entries.firstOrNull { it is Entry.Title }?.let { SectionRow(it, 0, env) }
        if (items.isEmpty()) {
            entries.firstOrNull { it is Entry.Empty }?.let { SectionRow(it, 1, env) }
        } else {
            val state = rememberPagerState(pageCount = { items.size })
            HorizontalPager(
                state, Modifier.weight(1f).fillMaxWidth().padding(bottom = pad.calculateBottomPadding()),
                contentPadding = PaddingValues(horizontal = 40.dp), pageSpacing = 14.dp
            ) { page ->
                val m = items.getOrNull(page)
                if (m != null) CarouselCard(
                    m, page, items.size, env,
                    Modifier.fillMaxSize().padding(vertical = 10.dp).graphicsLayer {
                        val off = abs((state.currentPage - page) + state.currentPageOffsetFraction).coerceIn(0f, 1f)
                        val s = 1f - 0.08f * off
                        scaleX = s; scaleY = s; alpha = 1f - 0.4f * off
                    }
                )
            }
        }
    }
}

// =====================================================================================================================
// Sticky notes and Polaroid boards (staggered columns that follow the screen width)
// =====================================================================================================================

@Composable
private fun BoardHost(polaroid: Boolean, entries: List<Entry>, env: LayoutEnv, pad: PaddingValues) {
    val w = LocalConfiguration.current.screenWidthDp
    val cols = when { w >= 900 -> 4; w >= 600 -> 3; else -> 2 }
    LazyVerticalStaggeredGrid(
        StaggeredGridCells.Fixed(cols), Modifier.fillMaxSize(), contentPadding = pad,
        verticalItemSpacing = 6.dp, horizontalArrangement = Arrangement.spacedBy(2.dp)
    ) {
        itemsIndexed(
            entries, key = { _, e -> entryKey(e) },
            span = { _, e -> if (e is Entry.Item) StaggeredGridItemSpan.SingleLane else StaggeredGridItemSpan.FullLine }
        ) { i, e ->
            when (e) {
                is Entry.Item -> if (polaroid && !e.m.note) PolaroidCard(e.m, i, env) else StickyNote(e.m, i, env)
                else -> SectionRow(e, i, env)
            }
        }
    }
}

/** Draws every layout that MainActivity does not draw itself ("list" and "grid"). */
@Composable
fun MemoryLayoutHost(layout: String, entries: List<Entry>, env: LayoutEnv, pad: PaddingValues) {
    when (layout) {
        "sticky" -> BoardHost(false, entries, env, pad)
        "polaroid" -> BoardHost(true, entries, env, pad)
        "mosaic" -> MosaicHost(entries, env, pad)
        "magazine" -> MagazineHost(entries, env, pad)
        "gallery" -> GalleryHost(entries, env, pad)
        "carousel" -> CarouselHost(entries, env, pad)
        else -> BoardHost(false, entries, env, pad)
    }
}

// =====================================================================================================================
// Layout icon (shown on the grid-panel button) and layout picker sheet
// =====================================================================================================================

@Composable
fun LayoutIcon(key: String, color: Color, size: Dp = 24.dp) {
    when (key) {
        "list" -> ListIcon(color, size)
        "grid" -> GridIcon(color, size)
        else -> Canvas(Modifier.size(size)) {
            val w = this.size.width
            val st = Stroke(2.2.dp.toPx())
            fun rr(x: Float, y: Float, bw: Float, bh: Float, fill: Boolean = false, c: Color = color) =
                drawRoundRect(c, Offset(w * x, w * y), Size(w * bw, w * bh), CornerRadius(w * 0.06f), style = if (fill) androidx.compose.ui.graphics.drawscope.Fill else st)
            when (key) {
                "sticky" -> {
                    drawPath(Path().apply {
                        moveTo(w * 0.14f, w * 0.14f); lineTo(w * 0.86f, w * 0.14f); lineTo(w * 0.86f, w * 0.58f)
                        lineTo(w * 0.58f, w * 0.86f); lineTo(w * 0.14f, w * 0.86f); close()
                    }, color, style = st)
                    drawPath(Path().apply { moveTo(w * 0.86f, w * 0.58f); lineTo(w * 0.58f, w * 0.58f); lineTo(w * 0.58f, w * 0.86f) }, color, style = st)
                    rr(0.26f, 0.3f, 0.4f, 0.07f, true); rr(0.26f, 0.46f, 0.26f, 0.07f, true)
                }
                "polaroid" -> {
                    rr(0.16f, 0.08f, 0.68f, 0.84f)
                    rr(0.27f, 0.19f, 0.46f, 0.44f, true, color.copy(alpha = 0.6f))
                }
                "mosaic" -> { rr(0.08f, 0.08f, 0.52f, 0.84f); rr(0.68f, 0.08f, 0.24f, 0.38f); rr(0.68f, 0.54f, 0.24f, 0.38f) }
                "magazine" -> { rr(0.08f, 0.08f, 0.84f, 0.46f); rr(0.08f, 0.62f, 0.4f, 0.3f); rr(0.52f, 0.62f, 0.4f, 0.3f) }
                "gallery" -> { for (i in 0..2) for (j in 0..2) rr(0.08f + i * 0.31f, 0.08f + j * 0.31f, 0.22f, 0.22f, true) }
                else -> { rr(0.28f, 0.12f, 0.44f, 0.76f); rr(0.06f, 0.26f, 0.1f, 0.48f, true); rr(0.84f, 0.26f, 0.1f, 0.48f, true) }
            }
        }
    }
}

private val PREVIEW_COLORS = listOf(Color(0xFFFFB74D), Color(0xFF4FC3F7), Color(0xFFF06292), Color(0xFF81C784), Color(0xFFBA68C8), Color(0xFFFFD54F))

/** A tiny drawing of each layout for the picker. */
@Composable
private fun LayoutPreview(key: String, ink: Color, modifier: Modifier) {
    Canvas(modifier) {
        val w = this.size.width
        val h = this.size.height
        val line = ink.copy(alpha = 0.28f)
        fun box(x: Float, y: Float, bw: Float, bh: Float, c: Color, r: Float = 0.09f) =
            drawRoundRect(c, Offset(w * x, h * y), Size(w * bw, h * bh), CornerRadius(minOf(w, h) * r))
        val p = PREVIEW_COLORS
        when (key) {
            "list" -> {
                for (i in 0..2) {
                    val y = 0.1f + i * 0.29f
                    box(0.08f, y, 0.84f, 0.23f, ink.copy(alpha = 0.12f))
                    box(0.13f, y + 0.05f, 0.4f, 0.04f, line, 0.02f); box(0.13f, y + 0.13f, 0.28f, 0.04f, line, 0.02f)
                    box(0.76f, y + 0.035f, 0.12f, 0.16f, p[i], 0.05f)
                }
            }
            "grid" -> {
                box(0.1f, 0.1f, 0.38f, 0.4f, p[0]); box(0.1f, 0.55f, 0.38f, 0.3f, p[1])
                box(0.52f, 0.1f, 0.38f, 0.28f, p[2]); box(0.52f, 0.43f, 0.38f, 0.42f, p[3])
            }
            "sticky" -> {
                val s = h * 0.42f
                val notes = listOf(
                    Triple(Offset(w * 0.2f, h * 0.3f), -7f, Color(0xFFFFF176)), Triple(Offset(w * 0.5f, h * 0.36f), 4f, Color(0xFFF48FB1)),
                    Triple(Offset(w * 0.8f, h * 0.3f), -3f, Color(0xFF81D4FA)), Triple(Offset(w * 0.34f, h * 0.74f), 5f, Color(0xFFA5D6A7)),
                    Triple(Offset(w * 0.68f, h * 0.76f), -5f, Color(0xFFFFB74D))
                )
                for ((c, deg, col) in notes) rotate(deg, c) {
                    drawRoundRect(col, Offset(c.x - s / 2, c.y - s / 2), Size(s, s), CornerRadius(s * 0.06f))
                    drawRect(ink.copy(alpha = 0.3f), Offset(c.x - s * 0.34f, c.y - s * 0.12f), Size(s * 0.5f, s * 0.07f))
                    drawRect(ink.copy(alpha = 0.3f), Offset(c.x - s * 0.34f, c.y + s * 0.06f), Size(s * 0.34f, s * 0.07f))
                }
            }
            "polaroid" -> {
                val fw = w * 0.3f
                val fh = h * 0.76f
                val frames = listOf(Triple(Offset(w * 0.32f, h * 0.5f), -7f, p[1]), Triple(Offset(w * 0.68f, h * 0.52f), 6f, p[2]))
                for ((c, deg, col) in frames) rotate(deg, c) {
                    val tl = Offset(c.x - fw / 2, c.y - fh / 2)
                    drawRoundRect(Color.White, tl, Size(fw, fh), CornerRadius(3f))
                    drawRoundRect(ink.copy(alpha = 0.15f), tl, Size(fw, fh), CornerRadius(3f), style = Stroke(1.5f))
                    val pad = fw * 0.1f
                    drawRect(col, Offset(tl.x + pad, tl.y + pad), Size(fw - pad * 2, fw - pad * 2))
                    drawRect(ink.copy(alpha = 0.25f), Offset(tl.x + fw * 0.25f, tl.y + fh * 0.84f), Size(fw * 0.5f, fh * 0.05f))
                }
            }
            "mosaic" -> { box(0.06f, 0.1f, 0.56f, 0.8f, p[0]); box(0.66f, 0.1f, 0.28f, 0.38f, p[1]); box(0.66f, 0.52f, 0.28f, 0.38f, p[2]) }
            "magazine" -> {
                box(0.08f, 0.1f, 0.84f, 0.46f, p[4]); box(0.14f, 0.43f, 0.4f, 0.04f, Color.White.copy(alpha = 0.85f), 0.02f)
                box(0.08f, 0.6f, 0.4f, 0.3f, p[1]); box(0.52f, 0.67f, 0.4f, 0.23f, p[3])
            }
            "gallery" -> {
                val gap = w * 0.02f
                val cell = (w * 0.84f - gap * 4) / 5
                val top = (h - (cell * 3 + gap * 2)) / 2
                for (r in 0..2) for (c in 0..4) drawRoundRect(
                    p[(r * 5 + c) % p.size], Offset(w * 0.08f + c * (cell + gap), top + r * (cell + gap)), Size(cell, cell), CornerRadius(cell * 0.15f)
                )
            }
            else -> {
                box(0.3f, 0.07f, 0.4f, 0.72f, p[2], 0.1f); box(0.06f, 0.18f, 0.2f, 0.5f, p[1], 0.1f); box(0.74f, 0.18f, 0.2f, 0.5f, p[3], 0.1f)
                for (i in 0..2) drawCircle(if (i == 1) ink.copy(alpha = 0.7f) else ink.copy(alpha = 0.25f), h * 0.025f, Offset(w * (0.44f + i * 0.06f), h * 0.91f))
            }
        }
    }
}

@Composable
private fun LayoutOption(info: LayoutInfo, selected: Boolean, ink: Color, card: Color, modifier: Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(20.dp)
    Column(
        modifier.clip(shape).background(card)
            .border(if (selected) 2.dp else 1.dp, if (selected) Accent else ink.copy(alpha = 0.08f), shape)
            .clickable(onClick = onClick).padding(10.dp)
    ) {
        Box(Modifier.fillMaxWidth().height(96.dp).clip(RoundedCornerShape(14.dp)).background(ink.copy(alpha = 0.05f))) {
            LayoutPreview(info.key, ink, Modifier.fillMaxSize())
            if (selected) Box(Modifier.align(Alignment.TopEnd).padding(6.dp).size(22.dp).clip(CircleShape).background(Accent), Alignment.Center) {
                Icon(Icons.Filled.Check, null, Modifier.size(14.dp), tint = Color.Black)
            }
        }
        Text(info.label, Modifier.padding(top = 8.dp), color = ink, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(info.hint, color = ink.copy(alpha = 0.6f), fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

/** Bottom sheet opened from "Switch layout": tap a drawing to change the homepage layout right away. */
@Composable
fun LayoutPicker(current: String, dark: Boolean, onPick: (String) -> Unit, onDismiss: () -> Unit) {
    val state = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val scope = rememberCoroutineScope()
    val haptic = LocalHapticFeedback.current
    val ink = if (dark) Color.White else Color(0xFF1C1C1E)
    val card = if (dark) Color(0xFF2A2A2D) else Color(0xFFF0F0F3)
    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = state, containerColor = if (dark) Color(0xFF1B1B1D) else Color.White) {
        Column(Modifier.verticalScroll(rememberScrollState()).padding(horizontal = 18.dp).navigationBarsPadding()) {
            Text("Choose a layout", color = ink, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Text("Pick how your notes and pictures look on the homepage.", Modifier.padding(top = 2.dp), color = ink.copy(alpha = 0.6f), fontSize = 13.sp)
            for (group in listOf("Notes", "Pictures", "Classic")) {
                Text(group.uppercase(), Modifier.padding(top = 18.dp, bottom = 8.dp), color = Accent, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.6.sp)
                LAYOUTS.filter { it.group == group }.chunked(2).forEach { row ->
                    Row(Modifier.fillMaxWidth().padding(bottom = 10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        row.forEach { info ->
                            LayoutOption(info, info.key == current, ink, card, Modifier.weight(1f)) {
                                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                onPick(info.key)
                                scope.launch { state.hide() }.invokeOnCompletion { onDismiss() }
                            }
                        }
                        if (row.size == 1) Spacer(Modifier.weight(1f))
                    }
                }
            }
            Spacer(Modifier.height(16.dp))
        }
    }
}
