# PostIt

Post your memorable pictures on a styled homepage (Grid, Masonry or Mosaic), tap to view full screen,
and customize it from Settings, including a live animated homepage background
(Aurora, Sunset, Ocean, Neon, Forest, Rose) or your own photo with dimming and blur. Developed by Junnel Entoma.
Homepage pictures are compact notes-style cards, and you can write text notes (pencil button) that sit beside them.
Pictures can float in different styles (Float, Sway, Drift, Pulse) from Settings, and every picture has a pin button that keeps it at the top of the homepage.
Opening the app shows the system launch screen with the icon and "Developed by: Junnel Entoma" at the lower part (Android 12+), then goes straight to the homepage.
The launcher icon is a "memories" icon (stacked polaroid photos with a heart) and supports themed icons on Android 13+.

## Get the APK from GitHub (no Android Studio needed)
1. Create a new repository on github.com and upload this project (or the .zip) plus the
   `.github/workflows/build.yml` workflow.
2. Open the **Actions** tab. **Build PostIt APK** runs on every push (or press **Run workflow**).
3. When it turns green, open the run and download **PostIt-apk** under *Artifacts*.
   Unzip it and install `PostIt.apk`.

## Photo Studio: AI Smart Filter
The **AI** tab in Photo Studio looks at your photo (exposure, tonal range, colour cast, saturation and rough scene such as
Portrait, Landscape, Sunset, Low light or Food), then suggests the **Best** look and builds eight ready-made looks
(Auto Enhance, Portrait Glow, Vivid Scenery, Golden Hour, Night Boost, Food Fresh, Cinematic, B&W Drama) tuned to that
photo. Tap **Auto** for the best match, and use **AI strength** to dial it up or down. It runs on the phone, so nothing is uploaded.

## Editable image notes
Tap the **caption** of an image note to edit it. Tap the **picture** to view it full screen.

## Photo Studio: new AI icon
The AI tab now uses an animated gradient sparkle icon (spinning aurora ring, pulsing four-point star) instead of the robot emoji.

## Grid icon (all homepage buttons in one place)
The bottom group of buttons is now a single animated **grid icon**. Tap it and a responsive grid panel springs open (the icon spins into an X) with every button inside it as a tile: **New note** (hero tile), **Grid/List view**, **Anniversaries** and **Add picture**. Tiles pop in one after another with a bounce and a haptic tick; tap outside the panel, the X or Back to close it. **Long-press the grid icon for a quick new note.**
The panel is responsive: the number of columns follows the screen width (2 on small phones, 3 on larger ones, 4 on tablets/landscape) and it never gets wider than 420dp.

## Customize Buttons
Settings > **Customize Buttons** has a live, tappable preview of the grid icon and lets you show or hide each button inside it, pick a style (Dark, Glass, Aurora, Light), button color, size, grid columns (Auto, 2, 3 or 4) and which side the icon sits on (left, center, right).

## Note sheet (new note, edit note, edit caption)
The New note pop-up is now a full-screen sheet with a card that adapts to the screen (max 560dp wide, the middle scrolls so it works in landscape and with the keyboard open, and Save/Cancel stay visible). It has a gold header with the date, glowing focus fields (Title and Note), the keyboard opens automatically (Next jumps from title to note), quick-insert chips (Bullet, Task, Date, Time) that insert at the cursor, a live word count, and a gradient Save button that stays disabled until there is something to save. Closing with unsaved changes asks "Discard your changes?". The same sheet is used for Edit note and for Edit caption on pictures (with the picture shown on top).

## Pictures
Tap a picture on the homepage to view it full screen. Tap the full-screen picture and it flips over so you can write a note on the back (saved automatically); tap **Flip back to picture** to return. Tap the caption to edit it. Long-press a card for View picture, Edit caption, Pin and Delete.

## Anniversary countdown
Every anniversary shows a live **days left** badge, a months/days breakdown, the anniversary number (1st, 2nd...) and a progress bar. The count is exact (calendar days, no clock rounding) and updates by itself at midnight, when you open the app, and when the phone's date, time or time zone changes. On the day it shows "Today!". Feb 29 anniversaries are celebrated on Feb 28 in non-leap years. The sidebar header shows the next upcoming anniversary.

## Layouts (Switch layout)
Open the grid icon and tap **Layouts** (Switch layout). A bottom sheet shows a drawing of every layout; tap one and the homepage changes right away (it cross-fades, and your choice is remembered). The button also shows the icon of the layout you are using. You can pick the same layouts from Settings > Notes layout.

**Notes**
- **Sticky notes**: every text note is a colourful post-it (yellow, pink, mint, sky, orange, lavender, lime) with handwritten text, a folded corner, a soft shadow, a slight tilt and a strip of tape. Pinned notes get a red push-pin instead of tape. Pictures are stuck on a post-it with their caption below.

**Pictures**
- **Polaroid**: instant-photo frames with a handwritten caption and date, slightly tilted and taped to the page. Text notes appear as post-its between them.
- **Mosaic**: a bento photo collage that repeats big + two small, a pair, one wide picture, two small + big, and a row of three. Text notes become coloured tiles inside the collage.
- **Magazine**: a big hero picture with a serif headline, date and the note you wrote on the back, followed by a staggered pair of portrait cards, and so on.
- **Gallery**: tight square tiles (3 columns on phones, 5 to 6 on tablets), like a photo gallery.
- **Carousel**: swipe through big cards with a "3 / 12" counter; the cards next to the centre one peek in and shrink slightly.

**Classic**: List and Grid, unchanged.

All layouts keep the same actions: tap a picture to view it full screen (tap a note to edit it), long-press a tile for View picture, Edit caption / Edit note, Pin and Delete, and pinned memories stay at the top. Floating pictures (Settings) work in the sticky and Polaroid views too. The sticky and Polaroid views use 2 columns on phones, 3 on large phones and 4 on tablets. The new code lives in `Layouts.kt`.

## Version number
The sidebar (hamburger menu) ends with a small footer: a thin divider, a **Version** pill (for example "Version 1.7") and the "Developed by" line. The number is read from the installed app itself, so it always matches `versionName` in `app/build.gradle.kts`.


## Video memories
Add a video from the grid icon (**Add video** tile, with the new video icon) or from the drawer. Pick a video, add a caption and tap **Post**: it appears on the homepage like any other memory, showing its first frame with a play button, in every layout (Sticky notes, Polaroid, Mosaic, Magazine, Gallery, Carousel, List, Grid). Tap it to play full screen with play/pause and seek controls. The drawer has a new **Videos** filter, and you can pin, edit the caption of or delete a video like a picture. Show or hide the **Add video** tile in Settings > Customize Buttons.

## New post sheet (pictures and videos)
Adding a picture or a video now opens a sheet that matches the note sheet: a large preview (videos show length, file size and frame size and a play button), a caption, an optional note, a **Pin to top** switch and an **Add date** chip. **Post** shows progress while a video is copied in, and closing with typed text asks before discarding.
