@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)

package com.postit.app

import android.app.Activity
import android.content.Context
import android.os.Build
import android.content.SharedPreferences
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts.PickVisualMedia
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.DateFormat
import java.util.Date
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.lazy.staggeredgrid.LazyVerticalStaggeredGrid
import androidx.compose.foundation.lazy.staggeredgrid.StaggeredGridCells
import androidx.compose.foundation.lazy.staggeredgrid.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.material.icons.filled.Close
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.border
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.StartOffset
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.tween
import androidx.compose.ui.composed
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.filled.Edit
import androidx.compose.ui.unit.Dp
import androidx.compose.animation.core.LinearEasing
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.ui.viewinterop.AndroidView
import android.widget.ImageView
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.staggeredgrid.StaggeredGridItemSpan
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Search
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import java.util.TimeZone
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ColorMatrix as AColorMatrix
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.rotate
import kotlin.math.hypot
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.luminance
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.Crossfade
import android.content.BroadcastReceiver
import android.content.Intent
import android.content.IntentFilter
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.compose.ui.platform.LocalLifecycleOwner

import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.semantics.Role

import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.draw.drawBehind
import androidx.compose.material.icons.filled.Check
import android.media.MediaMetadataRetriever
import android.widget.FrameLayout
import android.widget.MediaController
import android.widget.VideoView
import android.view.Gravity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        // The system launch screen (icon + "Developed by: Junnel Entoma") stays up briefly, then the app opens directly.
        val splash = installSplashScreen()
        val start = System.currentTimeMillis()
        splash.setKeepOnScreenCondition { System.currentTimeMillis() - start < 1500 }
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { PostItApp() }
    }
}

data class Memory(val file: String, val caption: String, val time: Long, val pinned: Boolean = false, val body: String = "", val note: Boolean = false, val video: String = "")

fun load(p: SharedPreferences): List<Memory> {
    val a = JSONArray(p.getString("memories", "[]"))
    return (0 until a.length()).map { val o = a.getJSONObject(it); Memory(o.getString("f"), o.getString("c"), o.getLong("t"), o.optBoolean("p", false), o.optString("b", ""), o.optBoolean("n", false), o.optString("v", "")) }
}

fun save(p: SharedPreferences, l: List<Memory>) {
    val a = JSONArray(l.map { JSONObject().put("f", it.file).put("c", it.caption).put("t", it.time).put("p", it.pinned).put("b", it.body).put("n", it.note).put("v", it.video) })
    p.edit().putString("memories", a.toString()).apply()
}

val FLOAT_STYLES = listOf("off" to "Off", "bob" to "Float", "sway" to "Sway", "drift" to "Drift", "pulse" to "Pulse")

/** Makes a picture gently float. Each picture starts at a different phase so the page feels alive. */
fun Modifier.floating(style: String, index: Int): Modifier = if (style == "off") this else composed {
    val tr = rememberInfiniteTransition(label = "float")
    val v by tr.animateFloat(
        -1f, 1f,
        infiniteRepeatable(tween(2600, easing = FastOutSlowInEasing), RepeatMode.Reverse, StartOffset((index * 370) % 2600)),
        label = "v"
    )
    graphicsLayer {
        when (style) {
            "bob" -> translationY = v * 6f * density
            "sway" -> { rotationZ = v * 2.5f; translationY = v * 2f * density }
            "drift" -> { translationX = v * 5f * density; translationY = (v * v - 0.5f) * 8f * density }
            "pulse" -> { scaleX = 1f + v * 0.03f; scaleY = 1f + v * 0.03f }
        }
    }
}


@Composable
fun SwitchRow(title: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(title, Modifier.weight(1f)); Switch(checked, onChange)
    }
}


/** True when this memory is a video. [Memory.file] is then its thumbnail picture and [Memory.video] the video file. */
val Memory.isVideo: Boolean get() = video.isNotEmpty()

/** Removes every file that belongs to a memory (picture or thumbnail, plus the video file). */
fun deleteFiles(ctx: Context, m: Memory) {
    File(ctx.filesDir, m.file).delete()
    if (m.video.isNotEmpty()) File(ctx.filesDir, m.video).delete()
}

/** First frame of a video as a picture (max [max] px on the long side), or null if it cannot be read. */
fun videoThumb(ctx: Context, uri: Uri?, path: String? = null, max: Int = 1024): Bitmap? = try {
    val r = MediaMetadataRetriever()
    try {
        if (uri != null) r.setDataSource(ctx, uri) else r.setDataSource(path)
        val raw = r.getFrameAtTime(1_000_000L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC) ?: r.getFrameAtTime(0L)
        raw?.let { b ->
            val s = max.toFloat() / maxOf(b.width, b.height)
            if (s < 1f) Bitmap.createScaledBitmap(b, (b.width * s).toInt().coerceAtLeast(1), (b.height * s).toInt().coerceAtLeast(1), true) else b
        }
    } finally { r.release() }
} catch (e: Exception) { null }

/** Copies a picked video into the app and makes its thumbnail. Runs off the main thread. Returns the new memory. */
suspend fun importVideo(ctx: Context, uri: Uri, caption: String, body: String = "", pinned: Boolean = false): Memory? = withContext(Dispatchers.IO) {
    try {
        val now = System.currentTimeMillis()
        val vid = "vid_$now.mp4"
        val thumb = "vth_$now.jpg"
        ctx.contentResolver.openInputStream(uri)?.use { i -> File(ctx.filesDir, vid).outputStream().use { o -> i.copyTo(o) } } ?: return@withContext null
        val bmp = videoThumb(ctx, null, File(ctx.filesDir, vid).absolutePath)
            ?: Bitmap.createBitmap(640, 360, Bitmap.Config.ARGB_8888).also { android.graphics.Canvas(it).drawColor(0xFF1B1B1F.toInt()) }
        File(ctx.filesDir, thumb).outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 88, it) }
        Memory(thumb, caption, now, pinned, body, video = vid)
    } catch (e: Exception) { null }
}

class MediaMeta(val durationMs: Long, val sizeBytes: Long, val w: Int, val h: Int)

/** Length, file size and frame size of a picked video (any field can be 0 when the phone does not say). */
fun videoMeta(ctx: Context, uri: Uri): MediaMeta? = try {
    val r = MediaMetadataRetriever()
    try {
        r.setDataSource(ctx, uri)
        val dur = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
        var w = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0
        var h = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
        val rot = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
        if (rot == 90 || rot == 270) { val t = w; w = h; h = t }
        val size = try { ctx.contentResolver.openAssetFileDescriptor(uri, "r")?.use { it.length } ?: 0L } catch (e: Exception) { 0L }
        MediaMeta(dur, size, w, h)
    } finally { r.release() }
} catch (e: Exception) { null }

fun fmtDuration(ms: Long): String {
    val s = ms / 1000; val h = s / 3600; val mi = (s % 3600) / 60; val sec = s % 60
    return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, mi, sec) else String.format(Locale.US, "%d:%02d", mi, sec)
}

fun fmtSize(b: Long): String = if (b >= 1_048_576L) String.format(Locale.US, "%.1f MB", b / 1_048_576.0) else "${maxOf(1L, b / 1024)} KB"

val Accent = Color(0xFFF4B400)
private val DarkScheme = darkColorScheme(
    primary = Accent, onPrimary = Color.Black, background = Color.Black, surface = Color(0xFF121212),
    surfaceVariant = Color(0xFF232325), secondaryContainer = Color(0xFF4A3B00), onSecondaryContainer = Accent
)
private val LightScheme = lightColorScheme(primary = Color(0xFFC79100), onPrimary = Color.White, secondaryContainer = Color(0xFFFFE9A8))

/** One row of the "All memories" screen. */
sealed class Entry {
    object Title : Entry()
    object Empty : Entry()
    class Header(val text: String) : Entry()
    class Item(val m: Memory) : Entry()
}

class Pal(val bg: Color, val main: Color, val sub: Color, val glass: Boolean)

private fun startOfDay(daysAgo: Int): Long {
    val c = Calendar.getInstance()
    c.set(Calendar.HOUR_OF_DAY, 0); c.set(Calendar.MINUTE, 0); c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0)
    c.add(Calendar.DAY_OF_YEAR, -daysAgo)
    return c.timeInMillis
}

/** Section title: Today / Last 7 days / October / September 2024 ... */
fun bucketOf(t: Long): String {
    if (t >= startOfDay(0)) return "Today"
    if (t >= startOfDay(7)) return "Last 7 days"
    val c = Calendar.getInstance(); val y = c.get(Calendar.YEAR); c.timeInMillis = t
    return SimpleDateFormat(if (c.get(Calendar.YEAR) == y) "MMMM" else "MMMM yyyy", Locale.getDefault()).format(Date(t))
}

/** Right-hand date on a card: Just now / 4:26 PM / Yesterday / October 14. */
fun dateLabel(t: Long): String {
    val f = { p: String -> SimpleDateFormat(p, Locale.getDefault()).format(Date(t)) }
    return when {
        System.currentTimeMillis() - t < 60_000 -> "Just now"
        t >= startOfDay(0) -> f("h:mm a")
        t >= startOfDay(1) -> "Yesterday"
        t >= startOfDay(0).let { Calendar.getInstance().apply { timeInMillis = it; set(Calendar.DAY_OF_YEAR, 1) }.timeInMillis } -> f("MMMM d")
        else -> f("MMM d, yyyy")
    }
}

/** Date and time a note was posted: "Nov 19, 2026 · 2:05 PM" (grid cards drop the year: "Nov 19 · 2:05 PM"). */
fun postedLabel(t: Long, compact: Boolean): String =
    SimpleDateFormat(if (compact) "MMM d \u00B7 h:mm a" else "MMM d, yyyy \u00B7 h:mm a", Locale.getDefault()).format(Date(t))

/** Icon, colours and label of a sidebar filter. The drawer rows and the main heading both read from here so they always match. */
class FilterLook(val emoji: String, val label: String, val c1: Color, val c2: Color)

fun filterLook(f: String): FilterLook = when (f) {
    "pinned" -> FilterLook("\uD83D\uDCCC", "Pinned", Color(0xFFFF5252), Color(0xFFFF9100))
    "notes" -> FilterLook("\uD83D\uDCDD", "Text notes", Color(0xFF00C853), Color(0xFF00BFA5))
    "images" -> FilterLook("\uD83D\uDDBC\uFE0F", "Images", Color(0xFFFF4081), Color(0xFFFF80AB))
    "videos" -> FilterLook("\uD83C\uDFAC", "Videos", Color(0xFF00B0FF), Color(0xFF2979FF))
    else -> FilterLook("\uD83D\uDDC2\uFE0F", "All memories", Color(0xFF7C4DFF), Color(0xFF448AFF))
}

@Composable
fun FolderIcon(color: Color, size: Dp = 20.dp) = Canvas(Modifier.size(size)) {
    drawRoundRect(color, Offset(0f, this.size.height * 0.08f), Size(this.size.width * 0.5f, this.size.height * 0.3f), CornerRadius(this.size.width * 0.1f))
    drawRoundRect(color, Offset(0f, this.size.height * 0.24f), Size(this.size.width, this.size.height * 0.68f), CornerRadius(this.size.width * 0.14f))
}

@Composable
fun VideoIcon(color: Color, size: Dp = 24.dp) = Canvas(Modifier.size(size)) {
    val w = this.size.width; val h = this.size.height
    drawRoundRect(color, Offset(w * 0.06f, h * 0.24f), Size(w * 0.64f, h * 0.52f), CornerRadius(w * 0.12f))
    drawPath(Path().apply { moveTo(w * 0.76f, h * 0.43f); lineTo(w * 0.95f, h * 0.29f); lineTo(w * 0.95f, h * 0.71f); lineTo(w * 0.76f, h * 0.57f); close() }, SolidColor(color))
}

/** Round play button drawn on top of a video thumbnail. */
@Composable
fun PlayBadge(modifier: Modifier = Modifier, badge: Dp = 40.dp) {
    Box(modifier.size(badge).clip(CircleShape).background(Color.Black.copy(alpha = 0.5f)).border(1.5.dp, Color.White.copy(alpha = 0.85f), CircleShape), Alignment.Center) {
        Canvas(Modifier.size(badge * 0.42f)) {
            val w = this.size.width; val h = this.size.height
            drawPath(Path().apply { moveTo(w * 0.18f, 0f); lineTo(w, h / 2f); lineTo(w * 0.18f, h); close() }, SolidColor(Color.White))
        }
    }
}

@Composable
fun GridIcon(color: Color, size: Dp = 24.dp) = Canvas(Modifier.size(size)) {
    val s = this.size.width * 0.38f; val o = this.size.width * 0.62f
    for (x in listOf(0.06f * this.size.width, o - 0.06f * this.size.width)) for (y in listOf(0.06f * this.size.width, o - 0.06f * this.size.width))
        drawRoundRect(color, Offset(x, y), Size(s, s), CornerRadius(s * 0.28f), style = Stroke(2.2.dp.toPx()))
}

@Composable
fun ListIcon(color: Color, size: Dp = 24.dp) = Canvas(Modifier.size(size)) {
    for (i in 0..2) drawRoundRect(color, Offset(this.size.width * 0.08f, this.size.height * (0.16f + i * 0.3f)), Size(this.size.width * 0.84f, this.size.height * 0.14f), CornerRadius(this.size.height * 0.07f))
}

@Composable
fun PictureIcon(color: Color, size: Dp = 24.dp) = Canvas(Modifier.size(size)) {
    val w = this.size.width; val st = Stroke(2.2.dp.toPx())
    drawRoundRect(color, Offset(w * 0.06f, w * 0.12f), Size(w * 0.88f, w * 0.76f), CornerRadius(w * 0.16f), style = st)
    drawCircle(color, w * 0.08f, Offset(w * 0.34f, w * 0.38f))
    drawPath(Path().apply { moveTo(w * 0.1f, w * 0.8f); lineTo(w * 0.42f, w * 0.52f); lineTo(w * 0.62f, w * 0.7f); lineTo(w * 0.76f, w * 0.58f); lineTo(w * 0.9f, w * 0.76f) }, color, style = st)
}

// ---------------------------------------------------------------- Customizable bottom buttons

val PILL_COLORS = listOf(Accent, Color(0xFF22D3EE), Color(0xFFFF4D8D), Color(0xFF8B5CF6), Color(0xFF34D399), Color.White)
val PILL_STYLES = listOf("dark" to "Dark", "glass" to "Glass", "gradient" to "Aurora", "light" to "Light")

data class PillCfg(
    val layout: Boolean = true, val note: Boolean = true, val cal: Boolean = true, val pic: Boolean = true,
    val style: String = "dark", val color: Int = 0, val size: String = "M", val pos: String = "center",
    val cols: Int = 0, // 0 = automatic (responsive), otherwise 2..4 columns in the grid panel
    val vid: Boolean = true
)

fun loadPill(p: SharedPreferences) = PillCfg(
    p.getBoolean("pillLayout", true), p.getBoolean("pillNote", true), p.getBoolean("pillCal", true), p.getBoolean("pillPic", true),
    p.getString("pillStyle", "dark") ?: "dark", p.getInt("pillColor", 0).coerceIn(0, PILL_COLORS.lastIndex),
    p.getString("pillSize", "M") ?: "M", p.getString("pillPos", "center") ?: "center", p.getInt("pillCols", 0).coerceIn(0, 4), p.getBoolean("pillVid", true)
)

fun savePill(p: SharedPreferences, c: PillCfg) {
    p.edit().putBoolean("pillLayout", c.layout).putBoolean("pillNote", c.note).putBoolean("pillCal", c.cal).putBoolean("pillPic", c.pic)
        .putString("pillStyle", c.style).putInt("pillColor", c.color).putString("pillSize", c.size).putString("pillPos", c.pos).putInt("pillCols", c.cols).putBoolean("pillVid", c.vid).apply()
}

// ---------------------------------------------------------------- Grid dock: every homepage button lives inside one grid icon

private class DockItem(val key: String, val label: String, val hint: String, val icon: @Composable (Color) -> Unit, val onClick: () -> Unit)

/** Animated grid glyph: four rounded squares that spin into a close (X) as [p] goes from 0 to 1. */
@Composable
fun GridGlyph(p: Float, tint: Color, size: Dp = 28.dp) = Canvas(Modifier.size(size)) {
    val w = this.size.width
    val mid = Offset(w / 2, w / 2)
    val cell = w * 0.34f; val gap = w * 0.08f
    val a = (1f - p).coerceIn(0f, 1f)
    if (a > 0.01f) {
        val sc = 1f - 0.35f * p.coerceIn(0f, 1f)
        rotate(degrees = 90f * p, pivot = mid) {
            for (i in 0..3) {
                val cx = w / 2 + (if (i % 2 == 0) -1 else 1) * (cell / 2 + gap / 2)
                val cy = w / 2 + (if (i < 2) -1 else 1) * (cell / 2 + gap / 2)
                val s = cell * sc
                drawRoundRect(tint.copy(alpha = a * (if (i == 1) 1f else 0.6f)), Offset(cx - s / 2, cy - s / 2), Size(s, s), CornerRadius(s * 0.3f))
            }
        }
    }
    if (p > 0.01f) {
        val col = tint.copy(alpha = p.coerceIn(0f, 1f))
        val st = w * 0.1f
        rotate(degrees = -90f * (1f - p), pivot = mid) {
            drawLine(col, Offset(w * 0.28f, w * 0.28f), Offset(w * 0.72f, w * 0.72f), st, StrokeCap.Round)
            drawLine(col, Offset(w * 0.72f, w * 0.28f), Offset(w * 0.28f, w * 0.72f), st, StrokeCap.Round)
        }
    }
}

private fun dockBrush(style: String): Brush = when (style) {
    "glass" -> Brush.verticalGradient(listOf(Color(0xCC34344C), Color(0xCC181826)))
    "gradient" -> Brush.linearGradient(listOf(Color(0xFF2A1B6B), Color(0xFF0F6E7A)))
    "light" -> SolidColor(Color(0xFFF4F4F7))
    else -> Brush.verticalGradient(listOf(Color(0xFF3E3E42), Color(0xFF2A2A2D)))
}

private fun dockBorder(style: String): Color = when (style) {
    "glass" -> Color.White.copy(alpha = 0.30f)
    "gradient" -> Color.White.copy(alpha = 0.18f)
    "light" -> Color.Black.copy(alpha = 0.07f)
    else -> Color.White.copy(alpha = 0.09f)
}

/** Staggered pop-in used by every tile in the grid panel. */
@Composable
private fun dockPop(open: Boolean, order: Int): State<Float> {
    var shown by remember { mutableStateOf(false) }
    LaunchedEffect(open) { if (open) { delay(40L + order * 55L); shown = true } else shown = false }
    return animateFloatAsState(if (shown) 1f else 0f, spring(dampingRatio = 0.6f, stiffness = Spring.StiffnessLow), label = "dockPop")
}

@Composable
private fun DockHero(item: DockItem, order: Int, open: Boolean, k: Float, accent: Color, onAccent: Color, onClick: () -> Unit) {
    val pop by dockPop(open, order)
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val press by animateFloatAsState(if (pressed) 0.96f else 1f, spring(Spring.DampingRatioMediumBouncy, Spring.StiffnessMedium), label = "heroPress")
    val shape = RoundedCornerShape(22.dp)
    Row(
        Modifier.fillMaxWidth()
            .graphicsLayer { val s = (0.6f + 0.4f * pop) * press; scaleX = s; scaleY = s; alpha = pop.coerceIn(0f, 1f) }
            .clip(shape).background(Brush.horizontalGradient(listOf(accent, accent.copy(alpha = 0.78f))))
            .clickable(interactionSource = src, indication = null, onClickLabel = item.label, role = Role.Button, onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size((44 * k).dp).clip(CircleShape).background(onAccent.copy(alpha = 0.16f)), Alignment.Center) { item.icon(onAccent) }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(item.label, color = onAccent, fontSize = 16.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(item.hint, color = onAccent.copy(alpha = 0.72f), fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Icon(Icons.Filled.ArrowForward, null, tint = onAccent.copy(alpha = 0.8f), modifier = Modifier.size(20.dp))
    }
}

@Composable
private fun DockTile(item: DockItem, order: Int, open: Boolean, k: Float, accent: Color, tint: Color, ink: Color, light: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val pop by dockPop(open, order)
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val press by animateFloatAsState(if (pressed) 0.92f else 1f, spring(Spring.DampingRatioMediumBouncy, Spring.StiffnessMedium), label = "tilePress")
    val shape = RoundedCornerShape(20.dp)
    Column(
        modifier
            .graphicsLayer { val s = (0.5f + 0.5f * pop) * press; scaleX = s; scaleY = s; alpha = pop.coerceIn(0f, 1f) }
            .clip(shape).background(ink.copy(alpha = if (light) 0.06f else 0.09f)).border(1.dp, ink.copy(alpha = 0.08f), shape)
            .clickable(interactionSource = src, indication = null, onClickLabel = item.label, role = Role.Button, onClick = onClick)
            .heightIn(min = (88 * k).dp).padding(horizontal = 6.dp, vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
    ) {
        Box(
            Modifier.size((46 * k).dp).clip(RoundedCornerShape(16.dp))
                .background(Brush.linearGradient(listOf(accent.copy(alpha = 0.34f), accent.copy(alpha = 0.12f)))),
            Alignment.Center
        ) { item.icon(tint) }
        Spacer(Modifier.height(8.dp))
        Text(item.label, color = ink, fontSize = 12.sp, lineHeight = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 2, textAlign = TextAlign.Center, overflow = TextOverflow.Ellipsis)
        Text(item.hint, color = ink.copy(alpha = 0.55f), fontSize = 10.sp, maxLines = 1, textAlign = TextAlign.Center, overflow = TextOverflow.Ellipsis)
    }
}

/**
 * One grid icon that holds all the homepage buttons. Tap it and a responsive grid panel springs open with
 * New note (hero), layout switch, anniversaries and add picture. Long-press the icon for a quick new note.
 * Look, buttons, columns, size and side come from Settings (PillCfg).
 */
@Composable
fun BoxScope.GridDock(
    layoutKey: String, cfg: PillCfg,
    onLayout: () -> Unit, onNew: () -> Unit, onCalendar: () -> Unit, onPicture: () -> Unit, onVideo: () -> Unit,
    insets: Boolean = true, initiallyOpen: Boolean = false, handleBack: Boolean = true
) {
    val k = when (cfg.size) { "S" -> 0.88f; "L" -> 1.12f; else -> 1f }
    val accent = PILL_COLORS[cfg.color.coerceIn(0, PILL_COLORS.lastIndex)]
    val light = cfg.style == "light"
    val ink = if (light) Color(0xFF1C1C1E) else Color.White
    val tint = if (light && accent.luminance() > 0.8f) Color(0xFF555555) else accent
    val onAccent = if (accent.luminance() > 0.5f) Color.Black else Color.White
    val haptic = LocalHapticFeedback.current

    var open by remember { mutableStateOf(initiallyOpen) }
    val p by animateFloatAsState(if (open) 1f else 0f, spring(dampingRatio = 0.72f, stiffness = Spring.StiffnessMediumLow), label = "dock")
    BackHandler(handleBack && open) { open = false }
    fun fire(action: () -> Unit) { open = false; action() }

    val items = buildList {
        if (cfg.note) add(DockItem("note", "New note", "Write something", { c -> Icon(Icons.Filled.Add, null, tint = c, modifier = Modifier.size(26.dp)) }, onNew))
        if (cfg.layout) add(DockItem("layout", "Layouts", "Switch layout", { c -> LayoutIcon(layoutKey, c) }, onLayout))
        if (cfg.cal) add(DockItem("cal", "Anniversaries", "Countdowns", { c -> CalendarIcon(c) }, onCalendar))
        if (cfg.pic) add(DockItem("pic", "Add picture", "From gallery", { c -> PictureIcon(c) }, onPicture))
        if (cfg.vid) add(DockItem("vid", "Add video", "From gallery", { c -> VideoIcon(c) }, onVideo))
    }
    val hero = items.firstOrNull { it.key == "note" }
    val rest = items.filter { it !== hero }

    val hAlign = when (cfg.pos) { "left" -> Alignment.Start; "right" -> Alignment.End; else -> Alignment.CenterHorizontally }
    val bAlign = when (cfg.pos) { "left" -> Alignment.BottomStart; "right" -> Alignment.BottomEnd; else -> Alignment.BottomCenter }
    val origin = TransformOrigin(when (cfg.pos) { "left" -> 0.1f; "right" -> 0.9f; else -> 0.5f }, 1f)

    // Dim the page behind the panel; tapping it closes the panel.
    if (p > 0.01f) Box(
        Modifier.matchParentSize().background(Color.Black.copy(alpha = 0.5f * p.coerceIn(0f, 1f)))
            .pointerInput(Unit) { detectTapGestures { open = false } }
    )

    BoxWithConstraints(
        Modifier.matchParentSize().then(if (insets) Modifier.navigationBarsPadding() else Modifier).padding(20.dp),
        contentAlignment = bAlign
    ) {
        // Responsive: the number of columns follows the available width (or the column count chosen in Settings).
        val panelW = minOf(maxWidth, 420.dp)
        val inner = panelW - 28.dp
        val auto = ((inner + 10.dp) / ((92 * k).dp + 10.dp)).toInt()
        val cols = (if (cfg.cols in 2..4) cfg.cols else auto).coerceIn(1, 4).coerceAtMost(maxOf(1, rest.size))
        val panelShape = RoundedCornerShape(30.dp)

        Column(horizontalAlignment = hAlign) {
            if (p > 0.01f) {
                Column(
                    Modifier.widthIn(max = 420.dp).fillMaxWidth()
                        .graphicsLayer {
                            val s = 0.7f + 0.3f * p
                            scaleX = s; scaleY = s; alpha = p.coerceIn(0f, 1f)
                            transformOrigin = origin; translationY = (1f - p) * 24.dp.toPx()
                        }
                        .then(if (cfg.style == "glass") Modifier else Modifier.shadow(20.dp, panelShape, clip = false))
                        .clip(panelShape).background(dockBrush(cfg.style)).border(1.dp, dockBorder(cfg.style), panelShape)
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    var order = 0
                    hero?.let { h -> DockHero(h, order++, open, k, accent, onAccent) { fire(h.onClick) } }
                    rest.chunked(cols).forEach { row ->
                        Row(Modifier.fillMaxWidth().height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            row.forEach { item ->
                                DockTile(item, order++, open, k, accent, tint, ink, light, Modifier.weight(1f).fillMaxHeight()) { fire(item.onClick) }
                            }
                        }
                    }
                }
                Spacer(Modifier.height(12.dp))
            }

            // The grid icon itself.
            val fabSize = (62 * k).dp
            val fabShape = RoundedCornerShape((22 * k).dp)
            val tr = rememberInfiniteTransition(label = "dockPulse")
            val pulse by tr.animateFloat(0f, 1f, infiniteRepeatable(tween(2400, easing = LinearEasing)), label = "pulse")
            val src = remember { MutableInteractionSource() }
            val pressed by src.collectIsPressedAsState()
            val press by animateFloatAsState(if (pressed) 0.9f else 1f, spring(Spring.DampingRatioMediumBouncy, Spring.StiffnessMedium), label = "fabPress")
            Box(Modifier.size(fabSize), Alignment.Center) {
                Box(
                    Modifier.fillMaxSize().graphicsLayer {
                        val s = 1f + 0.4f * pulse; scaleX = s; scaleY = s
                        alpha = (1f - pulse) * 0.35f * (1f - p.coerceIn(0f, 1f))
                    }.border(2.dp, accent, fabShape)
                )
                Box(
                    Modifier.fillMaxSize()
                        .graphicsLayer { scaleX = press; scaleY = press }
                        .then(if (cfg.style == "glass") Modifier else Modifier.shadow(14.dp, fabShape, clip = false))
                        .clip(fabShape).background(dockBrush(cfg.style)).border(1.dp, dockBorder(cfg.style), fabShape)
                        .combinedClickable(
                            interactionSource = src, indication = null, role = Role.Button, onClickLabel = if (open) "Close buttons" else "Open buttons",
                            onClick = { haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove); open = !open },
                            onLongClickLabel = "New note",
                            onLongClick = {
                                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                if (cfg.note) fire(onNew) else open = !open
                            }
                        ),
                    Alignment.Center
                ) { GridGlyph(p, tint, (28 * k).dp) }
            }
        }
    }
}

/** Settings icon for the button customizer: a glowing grid icon whose four tiles light up in turn, plus sparkles. */
@Composable
fun PillIcon(iconSize: Dp = 40.dp) {
    val tr = rememberInfiniteTransition(label = "pillIcon")
    val glow by tr.animateFloat(0.55f, 1f, infiniteRepeatable(tween(1500, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "glow")
    val hop by tr.animateFloat(0f, 1f, infiniteRepeatable(tween(2400, easing = LinearEasing)), label = "hop")
    Canvas(Modifier.size(iconSize)) {
        val w = this.size.width; val h = this.size.height
        val grad = Brush.linearGradient(listOf(Color(0xFF22D3EE), Color(0xFF8B5CF6), Color(0xFFFF4D8D)), Offset.Zero, Offset(w, h))
        drawRoundRect(Brush.radialGradient(listOf(Color(0xFF8B5CF6).copy(alpha = 0.5f * glow), Color.Transparent), Offset(w / 2, h / 2), w * 0.62f), Offset.Zero, Size(w, h), CornerRadius(w * 0.3f))
        drawRoundRect(Color(0xFF1B1442), Offset(w * 0.1f, h * 0.1f), Size(w * 0.8f, h * 0.8f), CornerRadius(w * 0.24f))
        drawRoundRect(grad, Offset(w * 0.1f, h * 0.1f), Size(w * 0.8f, h * 0.8f), CornerRadius(w * 0.24f), style = Stroke(w * 0.05f))
        val active = (hop * 4).toInt().coerceIn(0, 3)
        val s = w * 0.24f
        for (i in 0..3) {
            val cx = w * (0.34f + (i % 2) * 0.32f); val cy = h * (0.34f + (i / 2) * 0.32f)
            val on = i == active
            val sz = if (on) s * 1.1f else s
            drawRoundRect(if (on) Color.White else Color.White.copy(alpha = 0.45f), Offset(cx - sz / 2, cy - sz / 2), Size(sz, sz), CornerRadius(sz * 0.3f))
        }
        drawPath(sparklePath(w * 0.84f, h * 0.16f, w * 0.15f * glow, 0.14f), SolidColor(Color(0xFFFFD36B)))
        drawPath(sparklePath(w * 0.16f, h * 0.14f, w * 0.08f, 0.14f), SolidColor(Color.White.copy(alpha = glow)))
    }
}

@Composable
fun PillToggleRow(icon: @Composable () -> Unit, label: String, checked: Boolean, enabled: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(40.dp).clip(RoundedCornerShape(12.dp)).background(Color(0xFF3A3A3C)), Alignment.Center) { icon() }
        Spacer(Modifier.width(14.dp))
        Text(label, Modifier.weight(1f))
        Switch(checked, onChange, enabled = enabled)
    }
}

@Composable
fun PillCustomizer(cfg: PillCfg, layoutKey: String, onChange: (PillCfg) -> Unit, onBack: () -> Unit) {
    val on = listOf(cfg.layout, cfg.note, cfg.cal, cfg.pic, cfg.vid).count { it }
    Scaffold(topBar = {
        TopAppBar(title = { Text("Customize buttons") }, navigationIcon = { IconButton(onBack) { Icon(Icons.Filled.ArrowBack, "Back") } })
    }) { pad ->
        Column(Modifier.padding(pad).padding(16.dp).verticalScroll(rememberScrollState())) {
            // Live preview: the real grid icon and panel, fully tappable
            Box(
                Modifier.fillMaxWidth().height(470.dp).clip(RoundedCornerShape(24.dp))
                    .background(Brush.linearGradient(listOf(Color(0xFF2A1B6B), Color(0xFF0F6E7A), Color(0xFFD9552B))))
            ) { GridDock(layoutKey, cfg, {}, {}, {}, {}, {}, insets = false, initiallyOpen = true, handleBack = false) }
            Text("Live preview of your grid icon. Tap it to open or close.", Modifier.fillMaxWidth().padding(top = 8.dp), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center)

            Text("Buttons inside the grid", Modifier.padding(top = 20.dp), style = MaterialTheme.typography.titleMedium)
            Text("Show only what you use. At least one stays on.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            PillToggleRow({ LayoutIcon("sticky", Accent, 22.dp) }, "Layouts (sticky notes, picture views)", cfg.layout, !(cfg.layout && on == 1)) { onChange(cfg.copy(layout = it)) }
            PillToggleRow({ Icon(Icons.Filled.Add, null, tint = Accent) }, "New note (+)", cfg.note, !(cfg.note && on == 1)) { onChange(cfg.copy(note = it)) }
            PillToggleRow({ CalendarIcon(Accent, 22.dp) }, "Anniversaries", cfg.cal, !(cfg.cal && on == 1)) { onChange(cfg.copy(cal = it)) }
            PillToggleRow({ PictureIcon(Accent, 22.dp) }, "Add picture", cfg.pic, !(cfg.pic && on == 1)) { onChange(cfg.copy(pic = it)) }
            PillToggleRow({ VideoIcon(Accent, 22.dp) }, "Add video", cfg.vid, !(cfg.vid && on == 1)) { onChange(cfg.copy(vid = it)) }

            Text("Style", Modifier.padding(top = 16.dp), style = MaterialTheme.typography.titleMedium)
            Row(Modifier.padding(vertical = 8.dp).horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                for ((k, label) in PILL_STYLES) FilterChip(selected = cfg.style == k, onClick = { onChange(cfg.copy(style = k)) }, label = { Text(label) })
            }
            Text("Button color", Modifier.padding(top = 8.dp), style = MaterialTheme.typography.titleMedium)
            Row(Modifier.padding(vertical = 10.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                PILL_COLORS.forEachIndexed { i, c ->
                    Box(
                        Modifier.size(38.dp).clip(CircleShape).background(c)
                            .border(if (cfg.color == i) 3.dp else 1.dp, if (cfg.color == i) MaterialTheme.colorScheme.onSurface else Color.Gray.copy(alpha = 0.5f), CircleShape)
                            .clickable { onChange(cfg.copy(color = i)) }
                    )
                }
            }
            Text("Size", Modifier.padding(top = 8.dp), style = MaterialTheme.typography.titleMedium)
            Row(Modifier.padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                for ((k, label) in listOf("S" to "Small", "M" to "Medium", "L" to "Large")) FilterChip(selected = cfg.size == k, onClick = { onChange(cfg.copy(size = k)) }, label = { Text(label) })
            }
            Text("Grid columns", Modifier.padding(top = 8.dp), style = MaterialTheme.typography.titleMedium)
            Text("Auto fits the screen width, so it also adapts to landscape and tablets.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Row(Modifier.padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                for ((n, label) in listOf(0 to "Auto", 2 to "2", 3 to "3", 4 to "4")) FilterChip(selected = cfg.cols == n, onClick = { onChange(cfg.copy(cols = n)) }, label = { Text(label) })
            }
            Text("Position", Modifier.padding(top = 8.dp), style = MaterialTheme.typography.titleMedium)
            Row(Modifier.padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                for ((k, label) in listOf("left" to "Left", "center" to "Center", "right" to "Right")) FilterChip(selected = cfg.pos == k, onClick = { onChange(cfg.copy(pos = k)) }, label = { Text(label) })
            }
            OutlinedButton({ onChange(PillCfg()) }, Modifier.padding(top = 12.dp)) { Text("Reset to default") }
        }
    }
}

// ---------------------------------------------------------------- Note sheet (new note / edit note / edit caption)

/** Inserts [text] at the cursor (replacing any selection). With [ownLine] it first starts a new line if needed. */
private fun insertAt(tf: TextFieldValue, text: String, ownLine: Boolean): TextFieldValue {
    val s = tf.selection.min.coerceIn(0, tf.text.length); val e = tf.selection.max.coerceIn(0, tf.text.length)
    val ins = if (ownLine && s > 0 && tf.text[s - 1] != '\n') "\n" + text else text
    return TextFieldValue(tf.text.substring(0, s) + ins + tf.text.substring(e), TextRange(s + ins.length))
}

@Composable
private fun NoteField(
    label: String, hint: String, value: TextFieldValue, onChange: (TextFieldValue) -> Unit,
    ink: Color, accent: Color, singleLine: Boolean, minHeight: Dp, textStyle: TextStyle,
    keyboard: KeyboardOptions, actions: KeyboardActions, focus: FocusRequester
) {
    var focused by remember { mutableStateOf(false) }
    val f by animateFloatAsState(if (focused) 1f else 0f, tween(180), label = "fieldFocus")
    val shape = RoundedCornerShape(18.dp)
    Column {
        Text(label, color = lerp(ink.copy(alpha = 0.55f), accent, f), fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp, modifier = Modifier.padding(start = 4.dp, bottom = 6.dp))
        Box(
            Modifier.fillMaxWidth().clip(shape).background(ink.copy(alpha = 0.06f))
                .border(if (focused) 1.5.dp else 1.dp, lerp(ink.copy(alpha = 0.12f), accent, f), shape)
                .padding(horizontal = 16.dp, vertical = 14.dp)
        ) {
            BasicTextField(
                value, onChange,
                Modifier.fillMaxWidth().heightIn(min = maxOf(minHeight - 28.dp, 0.dp)).focusRequester(focus).onFocusChanged { focused = it.isFocused },
                textStyle = textStyle, singleLine = singleLine, minLines = if (singleLine) 1 else 4,
                keyboardOptions = keyboard, keyboardActions = actions, cursorBrush = SolidColor(accent),
                decorationBox = { inner -> Box { if (value.text.isEmpty()) Text(hint, style = textStyle, color = ink.copy(alpha = 0.35f)); inner() } }
            )
        }
    }
}

@Composable
private fun NoteChip(text: String, ink: Color, onClick: () -> Unit) {
    val shape = RoundedCornerShape(50)
    Box(Modifier.clip(shape).background(ink.copy(alpha = 0.08f)).border(1.dp, ink.copy(alpha = 0.10f), shape).clickable(onClick = onClick).padding(horizontal = 12.dp, vertical = 7.dp)) {
        Text(text, color = ink.copy(alpha = 0.85f), fontSize = 12.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun NoteButton(text: String, modifier: Modifier, bg: Brush, fg: Color, border: Color?, enabled: Boolean = true, check: Boolean = false, onClick: () -> Unit) {
    val a by animateFloatAsState(if (enabled) 1f else 0.38f, tween(200), label = "btnA")
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val sc by animateFloatAsState(if (pressed && enabled) 0.95f else 1f, spring(Spring.DampingRatioMediumBouncy, Spring.StiffnessMedium), label = "btnS")
    val shape = RoundedCornerShape(50)
    Row(
        modifier.graphicsLayer { alpha = a; scaleX = sc; scaleY = sc }.clip(shape).background(bg)
            .then(if (border != null) Modifier.border(1.dp, border, shape) else Modifier)
            .clickable(interactionSource = src, indication = null, enabled = enabled, role = Role.Button, onClick = onClick)
            .padding(horizontal = 22.dp, vertical = 13.dp),
        Arrangement.Center, Alignment.CenterVertically
    ) {
        if (check) { Icon(Icons.Filled.Check, null, tint = fg, modifier = Modifier.size(18.dp)); Spacer(Modifier.width(6.dp)) }
        Text(text, color = fg, fontWeight = FontWeight.Bold, fontSize = 15.sp, maxLines = 1)
    }
}

/**
 * Full-screen dialog with a card that adapts to the screen: it never gets wider than 560dp, the middle part scrolls
 * (so it still works in landscape or with the keyboard open) and the Save/Cancel footer stays visible.
 * mode: 0 = new note, 1 = edit note, 2 = edit picture caption.
 */
@Composable
fun NoteSheet(mode: Int, image: File?, initialTitle: String, initialBody: String, onSave: (String, String) -> Unit, onDismiss: () -> Unit) {
    val dark = MaterialTheme.colorScheme.background.luminance() < 0.5f
    val ink = if (dark) Color.White else Color(0xFF1C1B22)
    val accent = Accent
    val onGold = Color(0xFF2A1D00)
    val gold = Brush.horizontalGradient(listOf(Accent, Color(0xFFFF9E40)))
    val haptic = LocalHapticFeedback.current

    var title by remember { mutableStateOf(TextFieldValue(initialTitle, TextRange(initialTitle.length))) }
    var body by remember { mutableStateOf(TextFieldValue(initialBody, TextRange(initialBody.length))) }
    var confirmDiscard by remember { mutableStateOf(false) }
    val titleFocus = remember { FocusRequester() }
    val bodyFocus = remember { FocusRequester() }
    val stamp = remember { SimpleDateFormat("EEE, MMM d \u00B7 h:mm a", Locale.getDefault()).format(Date()) }

    fun dirty() = title.text != initialTitle || body.text != initialBody
    fun canSave() = mode == 2 || title.text.isNotBlank() || body.text.isNotBlank()
    fun close() { if (dirty()) confirmDiscard = true else onDismiss() }
    fun save() { if (canSave()) { haptic.performHapticFeedback(HapticFeedbackType.LongPress); onSave(title.text.trim(), body.text.trim()) } }

    var shown by remember { mutableStateOf(false) }
    val e by animateFloatAsState(if (shown) 1f else 0f, spring(dampingRatio = 0.78f, stiffness = Spring.StiffnessMediumLow), label = "sheet")
    LaunchedEffect(Unit) {
        shown = true
        delay(300)
        try { (if (mode == 1) bodyFocus else titleFocus).requestFocus() } catch (_: Exception) { }
    }

    val heading = when (mode) { 0 -> "New note"; 1 -> "Edit note"; else -> "Edit caption" }
    val shape = RoundedCornerShape(32.dp)

    Dialog(onDismissRequest = { close() }, properties = DialogProperties(dismissOnClickOutside = false, usePlatformDefaultWidth = false, decorFitsSystemWindows = false)) {
        Box(
            Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.35f * e.coerceIn(0f, 1f)))
                .pointerInput(Unit) { detectTapGestures { close() } }
                .safeDrawingPadding().padding(16.dp),
            Alignment.Center
        ) {
            Column(
                Modifier.widthIn(max = 560.dp).fillMaxWidth()
                    .graphicsLayer {
                        val s = 0.92f + 0.08f * e
                        scaleX = s; scaleY = s; alpha = e.coerceIn(0f, 1f); translationY = (1f - e) * 40.dp.toPx()
                    }
                    .shadow(28.dp, shape, clip = false)
                    .clip(shape)
                    .background(if (dark) Brush.verticalGradient(listOf(Color(0xFF26213D), Color(0xFF15131E))) else Brush.verticalGradient(listOf(Color.White, Color(0xFFF7F3E8))))
                    .drawBehind { drawRect(Brush.radialGradient(listOf(accent.copy(alpha = if (dark) 0.22f else 0.25f), Color.Transparent), Offset.Zero, this.size.width * 0.85f)) }
                    .border(1.dp, ink.copy(alpha = 0.10f), shape)
                    .pointerInput(Unit) { detectTapGestures { } }
            ) {
                // Header
                Row(Modifier.fillMaxWidth().padding(start = 20.dp, end = 8.dp, top = 18.dp, bottom = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(46.dp).clip(RoundedCornerShape(15.dp)).background(gold), Alignment.Center) {
                        when (mode) {
                            0 -> Icon(Icons.Filled.Add, null, tint = onGold, modifier = Modifier.size(26.dp))
                            1 -> Icon(Icons.Filled.Edit, null, tint = onGold, modifier = Modifier.size(22.dp))
                            else -> PictureIcon(onGold, 22.dp)
                        }
                    }
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text(heading, color = ink, fontSize = 22.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(stamp, color = ink.copy(alpha = 0.55f), fontSize = 12.sp, maxLines = 1)
                    }
                    IconButton({ close() }) { Icon(Icons.Filled.Close, "Close", tint = ink.copy(alpha = 0.6f)) }
                }

                // Scrollable middle
                Column(Modifier.weight(1f, fill = false).verticalScroll(rememberScrollState()).padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    if (image != null) AsyncImage(image, null, Modifier.fillMaxWidth().height(150.dp).clip(RoundedCornerShape(20.dp)), contentScale = ContentScale.Crop)
                    NoteField(
                        if (mode == 2) "CAPTION" else "TITLE", if (mode == 2) "Add a caption\u2026" else "Give your note a title",
                        title, { title = it }, ink, accent, true, 0.dp,
                        TextStyle(color = ink, fontSize = 18.sp, fontWeight = FontWeight.SemiBold),
                        KeyboardOptions(capitalization = KeyboardCapitalization.Sentences, imeAction = if (mode == 2) ImeAction.Done else ImeAction.Next),
                        KeyboardActions(onNext = { bodyFocus.requestFocus() }, onDone = { save() }), titleFocus
                    )
                    if (mode != 2) {
                        NoteField(
                            "NOTE", "Write your thoughts\u2026", body, { body = it }, ink, accent, false, 150.dp,
                            TextStyle(color = ink, fontSize = 16.sp, lineHeight = 24.sp),
                            KeyboardOptions(capitalization = KeyboardCapitalization.Sentences, imeAction = ImeAction.Default),
                            KeyboardActions(), bodyFocus
                        )
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Row(Modifier.weight(1f).horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                NoteChip("\u2022 Bullet", ink) { body = insertAt(body, "\u2022 ", true); bodyFocus.requestFocus() }
                                NoteChip("\u2610 Task", ink) { body = insertAt(body, "\u2610 ", true); bodyFocus.requestFocus() }
                                NoteChip("\uD83D\uDCC5 Date", ink) { body = insertAt(body, SimpleDateFormat("MMM d, yyyy", Locale.getDefault()).format(Date()), false); bodyFocus.requestFocus() }
                                NoteChip("\u23F0 Time", ink) { body = insertAt(body, SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date()), false); bodyFocus.requestFocus() }
                            }
                            val words = body.text.trim().split(Regex("\\s+")).count { it.isNotEmpty() }
                            Text("$words words", Modifier.padding(start = 10.dp), color = ink.copy(alpha = 0.45f), fontSize = 11.sp, maxLines = 1)
                        }
                    }
                    Spacer(Modifier.height(2.dp))
                }

                // Footer (turns into a discard confirmation when closing with unsaved changes)
                Column(Modifier.fillMaxWidth().animateContentSize().padding(horizontal = 20.dp, vertical = 16.dp)) {
                    if (confirmDiscard) {
                        Text("Discard your changes?", color = ink, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(bottom = 10.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            NoteButton("Keep editing", Modifier.weight(1f), SolidColor(ink.copy(alpha = 0.08f)), ink, ink.copy(alpha = 0.12f)) { confirmDiscard = false }
                            NoteButton("Discard", Modifier.weight(1f), SolidColor(Color(0xFFE5484D)), Color.White, null) { onDismiss() }
                        }
                    } else {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            TextButton({ close() }) { Text("Cancel", color = ink.copy(alpha = 0.75f), fontWeight = FontWeight.SemiBold) }
                            Spacer(Modifier.weight(1f))
                            NoteButton("Save", Modifier, gold, onGold, null, canSave(), true) { save() }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ToggleChip(text: String, on: Boolean, ink: Color, onClick: () -> Unit) {
    val shape = RoundedCornerShape(50)
    Box(
        Modifier.clip(shape).background(if (on) Accent.copy(alpha = 0.2f) else ink.copy(alpha = 0.08f))
            .border(1.dp, if (on) Accent else ink.copy(alpha = 0.10f), shape).clickable(onClick = onClick).padding(horizontal = 12.dp, vertical = 7.dp)
    ) { Text(text, color = if (on) Accent else ink.copy(alpha = 0.85f), fontSize = 12.sp, fontWeight = FontWeight.Medium) }
}

@Composable
private fun InfoPill(text: String) {
    Text(text, Modifier.clip(RoundedCornerShape(50)).background(Color.Black.copy(alpha = 0.55f)).padding(horizontal = 9.dp, vertical = 3.dp), color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
}

/**
 * "New video memory" / "New picture" sheet: big preview (with length, size and frame size for videos), caption,
 * optional note, pin switch and a Post button that shows progress while a video is being added.
 */
@Composable
fun MediaPostSheet(video: Boolean, uri: Uri, busy: Boolean, onPost: (String, String, Boolean) -> Unit, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val dark = MaterialTheme.colorScheme.background.luminance() < 0.5f
    val ink = if (dark) Color.White else Color(0xFF1C1B22)
    val onGold = Color(0xFF2A1D00)
    val gold = Brush.horizontalGradient(listOf(Accent, Color(0xFFFF9E40)))
    val haptic = LocalHapticFeedback.current
    var caption by remember { mutableStateOf(TextFieldValue("")) }
    var note by remember { mutableStateOf(TextFieldValue("")) }
    var pinned by remember { mutableStateOf(false) }
    var confirmDiscard by remember { mutableStateOf(false) }
    var thumb by remember { mutableStateOf<Bitmap?>(null) }
    var meta by remember { mutableStateOf<MediaMeta?>(null) }
    val capFocus = remember { FocusRequester() }
    val noteFocus = remember { FocusRequester() }
    val stamp = remember { SimpleDateFormat("EEE, MMM d \u00B7 h:mm a", Locale.getDefault()).format(Date()) }

    LaunchedEffect(uri) {
        if (video) {
            val t = withContext(Dispatchers.IO) { videoThumb(ctx, uri, null, 960) }
            val mt = withContext(Dispatchers.IO) { videoMeta(ctx, uri) }
            thumb = t; meta = mt
        }
    }

    fun dirty() = caption.text.isNotEmpty() || note.text.isNotEmpty() || pinned
    fun close() { if (busy) return; if (dirty()) confirmDiscard = true else onDismiss() }
    fun post() { if (!busy) { haptic.performHapticFeedback(HapticFeedbackType.LongPress); onPost(caption.text.trim(), note.text.trim(), pinned) } }

    var shown by remember { mutableStateOf(false) }
    val e by animateFloatAsState(if (shown) 1f else 0f, spring(dampingRatio = 0.78f, stiffness = Spring.StiffnessMediumLow), label = "mediaSheet")
    LaunchedEffect(Unit) { shown = true }
    val shape = RoundedCornerShape(32.dp)

    Dialog(onDismissRequest = { close() }, properties = DialogProperties(dismissOnClickOutside = false, usePlatformDefaultWidth = false, decorFitsSystemWindows = false)) {
        Box(
            Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.45f * e.coerceIn(0f, 1f)))
                .pointerInput(Unit) { detectTapGestures { close() } }
                .safeDrawingPadding().padding(16.dp),
            Alignment.Center
        ) {
            Column(
                Modifier.widthIn(max = 560.dp).fillMaxWidth()
                    .graphicsLayer { val s = 0.92f + 0.08f * e; scaleX = s; scaleY = s; alpha = e.coerceIn(0f, 1f); translationY = (1f - e) * 40.dp.toPx() }
                    .shadow(28.dp, shape, clip = false).clip(shape)
                    .background(if (dark) Brush.verticalGradient(listOf(Color(0xFF26213D), Color(0xFF15131E))) else Brush.verticalGradient(listOf(Color.White, Color(0xFFF7F3E8))))
                    .drawBehind { drawRect(Brush.radialGradient(listOf(Accent.copy(alpha = if (dark) 0.22f else 0.25f), Color.Transparent), Offset.Zero, this.size.width * 0.85f)) }
                    .border(1.dp, ink.copy(alpha = 0.10f), shape)
                    .pointerInput(Unit) { detectTapGestures { } }
            ) {
                // Header
                Row(Modifier.fillMaxWidth().padding(start = 20.dp, end = 8.dp, top = 18.dp, bottom = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(46.dp).clip(RoundedCornerShape(15.dp)).background(gold), Alignment.Center) {
                        if (video) VideoIcon(onGold, 26.dp) else PictureIcon(onGold, 24.dp)
                    }
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text(if (video) "New video memory" else "New picture", color = ink, fontSize = 22.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(stamp, color = ink.copy(alpha = 0.55f), fontSize = 12.sp, maxLines = 1)
                    }
                    IconButton({ close() }, enabled = !busy) { Icon(Icons.Filled.Close, "Close", tint = ink.copy(alpha = 0.6f)) }
                }

                // Scrollable middle
                Column(Modifier.weight(1f, fill = false).verticalScroll(rememberScrollState()).padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Box(Modifier.fillMaxWidth().aspectRatio(1.6f).clip(RoundedCornerShape(22.dp)).background(Color(0xFF111114))) {
                        if (video) thumb?.let { Image(it.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop) }
                        else AsyncImage(uri, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                        Box(Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(64.dp).background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = 0.6f)))))
                        if (video) {
                            if (busy || thumb == null) CircularProgressIndicator(Modifier.align(Alignment.Center).size(40.dp), color = Accent, strokeWidth = 3.dp)
                            else PlayBadge(Modifier.align(Alignment.Center), 58.dp)
                            meta?.let { mt ->
                                Row(Modifier.align(Alignment.BottomStart).padding(12.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    if (mt.durationMs > 0) InfoPill("\u25B6 " + fmtDuration(mt.durationMs))
                                    if (mt.sizeBytes > 0) InfoPill(fmtSize(mt.sizeBytes))
                                    if (mt.w > 0 && mt.h > 0) InfoPill("${mt.w}\u00D7${mt.h}")
                                }
                            }
                        }
                        if (pinned) Text("\uD83D\uDCCC", Modifier.align(Alignment.TopEnd).padding(12.dp), fontSize = 20.sp)
                        if (busy) LinearProgressIndicator(Modifier.align(Alignment.BottomCenter).fillMaxWidth(), color = Accent, trackColor = Color.White.copy(alpha = 0.2f))
                    }
                    NoteField(
                        "CAPTION", if (video) "Say something about this video\u2026" else "Add a caption\u2026", caption, { caption = it }, ink, Accent, true, 0.dp,
                        TextStyle(color = ink, fontSize = 18.sp, fontWeight = FontWeight.SemiBold),
                        KeyboardOptions(capitalization = KeyboardCapitalization.Sentences, imeAction = ImeAction.Next),
                        KeyboardActions(onNext = { noteFocus.requestFocus() }), capFocus
                    )
                    NoteField(
                        "NOTE (OPTIONAL)", "Where was it? Who is in it?", note, { note = it }, ink, Accent, false, 96.dp,
                        TextStyle(color = ink, fontSize = 16.sp, lineHeight = 24.sp),
                        KeyboardOptions(capitalization = KeyboardCapitalization.Sentences, imeAction = ImeAction.Default),
                        KeyboardActions(), noteFocus
                    )
                    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        ToggleChip(if (pinned) "\uD83D\uDCCC Pinned to top" else "\uD83D\uDCCC Pin to top", pinned, ink) { pinned = !pinned }
                        NoteChip("\uD83D\uDCC5 Add date", ink) { caption = insertAt(caption, SimpleDateFormat("MMM d, yyyy", Locale.getDefault()).format(Date()), false) }
                    }
                    Spacer(Modifier.height(2.dp))
                }

                // Footer
                Column(Modifier.fillMaxWidth().animateContentSize().padding(horizontal = 20.dp, vertical = 16.dp)) {
                    if (confirmDiscard) {
                        Text("Discard this ${if (video) "video" else "picture"}?", color = ink, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(bottom = 10.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            NoteButton("Keep editing", Modifier.weight(1f), SolidColor(ink.copy(alpha = 0.08f)), ink, ink.copy(alpha = 0.12f)) { confirmDiscard = false }
                            NoteButton("Discard", Modifier.weight(1f), SolidColor(Color(0xFFE5484D)), Color.White, null) { onDismiss() }
                        }
                    } else {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            TextButton({ close() }, enabled = !busy) { Text("Cancel", color = ink.copy(alpha = 0.75f), fontWeight = FontWeight.SemiBold) }
                            Spacer(Modifier.weight(1f))
                            NoteButton(if (busy) "Adding\u2026" else "Post", Modifier, gold, onGold, null, !busy && (!video || thumb != null), !busy) { post() }
                        }
                    }
                }
            }
        }
    }
}

/** Notes-app card: title, optional thumbnail, date. Tap the picture for full screen, tap the text to edit, long-press for more. */
@Composable
fun NoteCard(m: Memory, compact: Boolean, index: Int, floatStyle: String, pal: Pal, onOpen: () -> Unit, onEdit: () -> Unit, onPin: () -> Unit, onDelete: () -> Unit) {
    val ctx = LocalContext.current
    val shape = RoundedCornerShape(20.dp)
    var menu by remember { mutableStateOf(false) }
    val title = if (m.note) m.caption else m.caption.ifEmpty { if (m.isVideo) "Video memory" else "Image note" }
    val preview = if (m.note) m.body else ""
    val photo = File(ctx.filesDir, m.file)
    Box(Modifier.fillMaxWidth().floating(floatStyle, index)) {
        Column(
            Modifier.fillMaxWidth().clip(shape).background(pal.bg)
                .then(if (pal.glass) Modifier.border(1.dp, Color.White.copy(alpha = 0.25f), shape) else Modifier)
                .combinedClickable(onClick = onEdit, onLongClick = { menu = true }).padding(16.dp)
        ) {
            if (compact && !m.note) {
                Box(Modifier.fillMaxWidth().aspectRatio(1.2f).clip(RoundedCornerShape(14.dp)).combinedClickable(onClick = onOpen, onLongClick = { menu = true })) {
                    AsyncImage(photo, m.caption, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                    if (m.isVideo) PlayBadge(Modifier.align(Alignment.Center), 44.dp)
                }
                Spacer(Modifier.height(10.dp))
            }
            Row(verticalAlignment = Alignment.Top) {
                Column(Modifier.weight(1f)) {
                    if (title.isNotEmpty()) Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(title, Modifier.weight(1f, fill = false), color = pal.main, fontSize = 20.sp, fontWeight = FontWeight.Medium, maxLines = if (compact) 2 else 1, overflow = TextOverflow.Ellipsis)
                        if (m.pinned) Text("\uD83D\uDCCC", Modifier.padding(start = 6.dp), fontSize = 14.sp)
                    }
                    if (preview.isNotEmpty()) Text(preview, Modifier.padding(top = 4.dp), color = pal.sub, fontSize = 16.sp, lineHeight = 22.sp, maxLines = if (compact) 4 else 2, overflow = TextOverflow.Ellipsis)
                }
                if (!compact && !m.note) {
                    Spacer(Modifier.width(12.dp))
                    Box(Modifier.size(64.dp).clip(RoundedCornerShape(14.dp)).combinedClickable(onClick = onOpen, onLongClick = { menu = true })) {
                        AsyncImage(photo, m.caption, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                        if (m.isVideo) PlayBadge(Modifier.align(Alignment.Center), 28.dp)
                    }
                }
            }
            Spacer(Modifier.height(14.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                CalendarIcon(Accent, 18.dp)
                Spacer(Modifier.width(if (compact) 6.dp else 8.dp))
                Text(postedLabel(m.time, compact), Modifier.weight(1f), color = pal.sub, fontSize = if (compact) 12.sp else 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
        DropdownMenu(menu, { menu = false }) {
            if (!m.note) DropdownMenuItem({ Text(if (m.isVideo) "Play video" else "View picture") }, { menu = false; onOpen() })
            DropdownMenuItem({ Text(if (m.note) "Edit note" else "Edit caption") }, { menu = false; onEdit() })
            DropdownMenuItem({ Text(if (m.pinned) "Unpin" else "Pin to top") }, { menu = false; onPin() })
            DropdownMenuItem({ Text("Delete") }, { menu = false; onDelete() })
        }
    }
}

/** Full-screen picture. Tap the picture to flip it and write a note on the back (saved automatically). */
@Composable
fun PhotoViewer(m: Memory, onNote: (String) -> Unit, onEdit: () -> Unit, onClose: () -> Unit) {
    val ctx = LocalContext.current
    var flipped by remember { mutableStateOf(false) }
    val rot by animateFloatAsState(if (flipped) 180f else 0f, tween(650, easing = FastOutSlowInEasing), label = "viewerFlip")
    var text by remember(m.file) { mutableStateOf(m.body) }
    val curText by rememberUpdatedState(text)
    val curBody by rememberUpdatedState(m.body)
    val save by rememberUpdatedState(onNote)
    val focus = remember { FocusRequester() }
    LaunchedEffect(text) { delay(400); if (text != curBody) save(text) }
    LaunchedEffect(flipped) { if (flipped) { delay(700); focus.requestFocus() } }
    DisposableEffect(Unit) { onDispose { if (curText != curBody) save(curText) } }
    Box(Modifier.fillMaxSize().background(Color.Black)) {
        Box(Modifier.fillMaxSize().graphicsLayer { rotationY = rot; cameraDistance = 16f * density }) {
            if (rot <= 90f) {
                Box(Modifier.fillMaxSize().pointerInput(Unit) { detectTapGestures { flipped = true } }) {
                    AsyncImage(File(ctx.filesDir, m.file), m.caption, Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
                    Column(Modifier.align(Alignment.BottomCenter).fillMaxWidth().background(Color.Black.copy(alpha = 0.55f)).navigationBarsPadding().padding(16.dp)) {
                        if (m.caption.isNotEmpty()) Text(m.caption, Modifier.clickable { onEdit() }, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Medium)
                        Text(if (m.body.isEmpty()) "Tap the picture to flip it and add a note" else "Tap the picture to flip it and read your note", Modifier.padding(top = 4.dp), color = Accent, fontSize = 12.sp)
                    }
                }
            } else {
                Column(Modifier.fillMaxSize().graphicsLayer { rotationY = 180f }.statusBarsPadding().navigationBarsPadding().imePadding().padding(start = 20.dp, end = 20.dp, top = 64.dp, bottom = 20.dp)) {
                    Column(Modifier.weight(1f).fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(Brush.verticalGradient(listOf(Color(0xFFFFF8E1), Color(0xFFFFECB3)))).padding(20.dp)) {
                        Text("NOTES ON THE BACK", color = Color(0xFF8A5A00), fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                        if (m.caption.isNotEmpty()) Text(m.caption, color = Color(0xFF3B2A10), fontSize = 20.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 4.dp))
                        Box(Modifier.padding(vertical = 10.dp).fillMaxWidth().height(2.dp).background(Color(0xFFE0B84C)))
                        TextField(
                            text, { text = it }, Modifier.fillMaxWidth().weight(1f).focusRequester(focus),
                            placeholder = { Text("Write something on the back of this picture...") },
                            textStyle = TextStyle(fontSize = 18.sp, lineHeight = 26.sp, fontStyle = androidx.compose.ui.text.font.FontStyle.Italic),
                            colors = TextFieldDefaults.colors(
                                focusedContainerColor = Color.Transparent, unfocusedContainerColor = Color.Transparent,
                                focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent,
                                focusedTextColor = Color(0xFF3B2A10), unfocusedTextColor = Color(0xFF3B2A10), cursorColor = Color(0xFF8A5A00),
                                focusedPlaceholderColor = Color(0xFF8A7A5A), unfocusedPlaceholderColor = Color(0xFF8A7A5A)
                            )
                        )
                    }
                    Button({ if (text != m.body) onNote(text); flipped = false }, Modifier.fillMaxWidth().padding(top = 14.dp), colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Color.Black)) { Text("Flip back to picture", fontWeight = FontWeight.Bold) }
                }
            }
        }
        IconButton(onClose, Modifier.align(Alignment.TopEnd).statusBarsPadding().padding(8.dp)) { Icon(Icons.Filled.Close, "Close", tint = Color.White) }
    }
}

/** Full-screen video player with the standard play/pause/seek controls. Starts playing right away. */
@Composable
fun VideoViewer(m: Memory, onEdit: () -> Unit, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val file = remember(m.video) { File(ctx.filesDir, m.video) }
    val player = remember { arrayOfNulls<VideoView>(1) }
    DisposableEffect(Unit) { onDispose { player[0]?.let { v -> (v.tag as? MediaController)?.hide(); v.stopPlayback() } } }
    Box(Modifier.fillMaxSize().background(Color.Black)) {
        AndroidView(
            factory = { c ->
                val vv = VideoView(c)
                val mc = MediaController(c)
                mc.setAnchorView(vv); vv.setMediaController(mc); vv.tag = mc; player[0] = vv
                vv.setVideoPath(file.absolutePath)
                vv.setOnPreparedListener { it.isLooping = false; vv.start() }
                FrameLayout(c).apply { addView(vv, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT, Gravity.CENTER)) }
            },
            modifier = Modifier.fillMaxSize()
        )
        if (m.caption.isNotEmpty()) Text(
            m.caption, Modifier.align(Alignment.TopStart).statusBarsPadding().padding(start = 16.dp, end = 64.dp, top = 14.dp).clickable { onEdit() },
            color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Medium, maxLines = 2, overflow = TextOverflow.Ellipsis
        )
        IconButton(onClose, Modifier.align(Alignment.TopEnd).statusBarsPadding().padding(8.dp)) { Icon(Icons.Filled.Close, "Close", tint = Color.White) }
    }
}

@Composable
fun EntryContent(
    e: Entry, index: Int, compact: Boolean, pal: Pal, filter: String, heading: String, count: String, floatStyle: String,
    onOpen: (Memory) -> Unit, onEdit: (Memory) -> Unit, onPin: (Memory) -> Unit, onDelete: (Memory) -> Unit
) {
    when (e) {
        is Entry.Title -> Row(Modifier.padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            val look = filterLook(filter)
            Box(Modifier.size(52.dp).clip(RoundedCornerShape(16.dp)).background(Brush.linearGradient(listOf(look.c1, look.c2))), Alignment.Center) { Text(look.emoji, fontSize = 26.sp) }
            Spacer(Modifier.width(14.dp))
            Column {
                Text(heading, color = pal.main, fontSize = 30.sp, fontWeight = FontWeight.SemiBold)
                Text(count, color = pal.sub, fontSize = 16.sp, modifier = Modifier.padding(top = 2.dp))
            }
        }
        is Entry.Header -> Text(e.text, Modifier.padding(start = 12.dp, top = 22.dp, bottom = 2.dp), color = pal.sub, fontSize = 18.sp)
        is Entry.Empty -> Text("No notes here yet.\nTap + to write a note, or add a photo or a video.", Modifier.fillMaxWidth().padding(top = 60.dp), color = pal.sub, textAlign = TextAlign.Center)
        is Entry.Item -> NoteCard(e.m, compact, index, floatStyle, pal, { onOpen(e.m) }, { onEdit(e.m) }, { onPin(e.m) }, { onDelete(e.m) })
    }
}


/** Version name of the installed app (from versionName in build.gradle.kts), or "" if it cannot be read. */
fun appVersion(ctx: Context): String = try {
    ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName ?: ""
} catch (e: Exception) { "" }

@Composable
fun PostItApp() {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("postit", Context.MODE_PRIVATE) }
    var dark by remember { mutableStateOf(prefs.getBoolean("dark", true)) }
    var cols by remember { mutableIntStateOf(prefs.getInt("gridCols", 2)) }
    var newest by remember { mutableStateOf(prefs.getBoolean("newest", true)) }
    var memories by remember { mutableStateOf(load(prefs)) }
    var settings by remember { mutableStateOf(false) }
    var pending by remember { mutableStateOf<Uri?>(null) }
    var pendingVideo by remember { mutableStateOf<Uri?>(null) }
    var videoBusy by remember { mutableStateOf(false) }
    val appScope = rememberCoroutineScope()
    var caption by remember { mutableStateOf("") }
    var confirmClear by remember { mutableStateOf(false) }
    var viewing by remember { mutableStateOf<Memory?>(null) }
    var noteOpen by remember { mutableStateOf(false) }
    var noteEditing by remember { mutableStateOf<Memory?>(null) }
    var noteTitle by remember { mutableStateOf("") }
    var noteBody by remember { mutableStateOf("") }
    fun editNote(m: Memory?) { noteEditing = m; noteTitle = m?.caption ?: ""; noteBody = m?.body ?: ""; noteOpen = true }
    var layout by remember { mutableStateOf(layoutInfo(prefs.getString("layout", "list") ?: "list").key) }
    var layoutOpen by remember { mutableStateOf(false) }
    var filter by remember { mutableStateOf("all") }
    var searching by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    var moreOpen by remember { mutableStateOf(false) }
    var calOpen by remember { mutableStateOf(false) }
    var editorOpen by remember { mutableStateOf(false) }
    var pillOpen by remember { mutableStateOf(false) }
    var pill by remember { mutableStateOf(loadPill(prefs)) }
    var annivs by remember { mutableStateOf(loadAnn(prefs)) }
    var floatStyle by remember { mutableStateOf(prefs.getString("floatStyle", "off") ?: "off") }

    var bgKind by remember { mutableStateOf(prefs.getString("bgKind", "none") ?: "none") }
    var bgPhoto by remember { mutableStateOf(prefs.getString("bgPhoto", "") ?: "") }
    var bgAnimated by remember { mutableStateOf(prefs.getBoolean("bgAnimated", true)) }
    var bgSparkles by remember { mutableStateOf(prefs.getBoolean("bgSparkles", true)) }
    var bgDim by remember { mutableFloatStateOf(prefs.getFloat("bgDim", 0.25f)) }
    var bgBlur by remember { mutableFloatStateOf(prefs.getFloat("bgBlur", 0f)) }

    val picker = rememberLauncherForActivityResult(PickVisualMedia()) { uri -> pending = uri; caption = "" }
    // The system document picker is used for videos (instead of the Photo Picker) because it still works when the Photo Picker says "Can't load some Photos".
    val videoPicker = rememberLauncherForActivityResult(androidx.activity.result.contract.ActivityResultContracts.OpenDocument()) { uri -> if (uri != null) { pendingVideo = uri; caption = "" } }
    val bgPicker = rememberLauncherForActivityResult(PickVisualMedia()) { uri ->
        if (uri != null) {
            val name = "bg_${System.currentTimeMillis()}"
            ctx.contentResolver.openInputStream(uri)?.use { i -> File(ctx.filesDir, name).outputStream().use { o -> i.copyTo(o) } }
            if (bgPhoto.isNotEmpty()) File(ctx.filesDir, bgPhoto).delete()
            bgPhoto = name; bgKind = "custom"
            prefs.edit().putString("bgPhoto", name).putString("bgKind", "custom").apply()
        }
    }
    fun commit(l: List<Memory>) { memories = l; save(prefs, l) }
    BackHandler(settings) { settings = false }
    BackHandler(pillOpen) { pillOpen = false }
    BackHandler(calOpen) { calOpen = false }
    BackHandler(editorOpen) { editorOpen = false }

    // Keep status/navigation bar icons readable on top of the background.
    val view = LocalView.current
    val lightBars = !editorOpen && !dark && !(bgKind != "none" && !settings && !calOpen)
    SideEffect {
        val win = (view.context as Activity).window
        val c = WindowCompat.getInsetsController(win, view)
        c.isAppearanceLightStatusBars = lightBars
        c.isAppearanceLightNavigationBars = lightBars
    }

    MaterialTheme(colorScheme = if (dark) DarkScheme else LightScheme) {
        if (editorOpen) {
            PhotoEditor({ editorOpen = false }, { name -> commit(memories + Memory(name, "Edited photo", System.currentTimeMillis())) })
        } else if (pillOpen) {
            PillCustomizer(pill, layout, { pill = it; savePill(prefs, it) }, { pillOpen = false })
        } else if (calOpen) {
            AnniversaryScreen(annivs, { annivs = it; saveAnn(prefs, it) }, { calOpen = false })
        } else if (settings) {
            Scaffold(topBar = {
                TopAppBar(title = { Text("Settings") }, navigationIcon = {
                    IconButton({ settings = false }) { Icon(Icons.Filled.ArrowBack, "Back") }
                })
            }) { pad ->
                Column(Modifier.padding(pad).padding(16.dp).verticalScroll(rememberScrollState())) {
                    Box(
                        Modifier.fillMaxWidth().padding(bottom = 12.dp).clip(RoundedCornerShape(20.dp))
                            .background(Brush.linearGradient(listOf(Color(0xFF6C3BFF), Color(0xFFFF4D8D), Color(0xFFFF9E40))))
                            .clickable { editorOpen = true }.padding(18.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("\uD83C\uDFA8", fontSize = 34.sp)
                            Spacer(Modifier.width(14.dp))
                            Column(Modifier.weight(1f)) {
                                Text("Photo Studio", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                                Text("Filters, adjustments, crop & rotate", color = Color.White.copy(alpha = 0.85f), fontSize = 13.sp)
                            }
                            Text("\u203A", color = Color.White, fontSize = 30.sp)
                        }
                    }
                    Box(
                        Modifier.fillMaxWidth().padding(bottom = 12.dp).clip(RoundedCornerShape(20.dp))
                            .background(Brush.linearGradient(listOf(Color(0xFF0EA5E9), Color(0xFF8B5CF6), Color(0xFFFF4D8D))))
                            .clickable { pillOpen = true }.padding(18.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.size(56.dp).clip(RoundedCornerShape(16.dp)).background(Color.Black.copy(alpha = 0.25f)), Alignment.Center) { PillIcon(44.dp) }
                            Spacer(Modifier.width(14.dp))
                            Column(Modifier.weight(1f)) {
                                Text("Customize Buttons", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                                Text("Show, hide, restyle & move the bottom buttons", color = Color.White.copy(alpha = 0.9f), fontSize = 13.sp)
                            }
                            Text("\u203A", color = Color.White, fontSize = 30.sp)
                        }
                    }
                    SwitchRow("Dark mode", dark) { dark = it; prefs.edit().putBoolean("dark", it).apply() }
                    SwitchRow("Newest memories first", newest) { newest = it; prefs.edit().putBoolean("newest", it).apply() }
                    Text("Columns in grid view", Modifier.padding(top = 8.dp))
                    Row(Modifier.padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        for (n in 2..4) FilterChip(selected = cols == n, onClick = { cols = n; prefs.edit().putInt("gridCols", n).apply() }, label = { Text("$n") })
                    }
                    Text("Notes layout", Modifier.padding(top = 8.dp))
                    Text("Sticky notes, Polaroid, Mosaic, Magazine, Gallery, Carousel, List or Grid.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Row(Modifier.padding(vertical = 8.dp).horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        for (info in LAYOUTS) {
                            FilterChip(selected = layout == info.key, onClick = { layout = info.key; prefs.edit().putString("layout", info.key).apply() }, label = { Text(info.label) })
                        }
                    }
                    Text("Floating pictures", Modifier.padding(top = 8.dp))
                    Text("Make the pictures on your homepage float in a style you like.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Row(Modifier.padding(vertical = 8.dp).horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        for ((k, label) in FLOAT_STYLES) {
                            FilterChip(selected = floatStyle == k, onClick = { floatStyle = k; prefs.edit().putString("floatStyle", k).apply() }, label = { Text(label) })
                        }
                    }
                    Text("Homepage background", Modifier.padding(top = 16.dp), style = MaterialTheme.typography.titleMedium)
                    Text("Pick a live background for your homepage.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Row(Modifier.padding(vertical = 12.dp).horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        val photoFile = if (bgPhoto.isNotEmpty()) File(ctx.filesDir, bgPhoto) else null
                        val options = listOf("none" to "Off") + THEMES.map { it.key to it.label } + listOf("custom" to "Photo")
                        for ((k, label) in options) {
                            BgSwatch(k, label, bgKind == k, photoFile, dark) {
                                if (k == "custom" && photoFile == null) bgPicker.launch(PickVisualMediaRequest(PickVisualMedia.ImageOnly))
                                else { bgKind = k; prefs.edit().putString("bgKind", k).apply() }
                            }
                        }
                    }
                    if (bgKind == "custom") {
                        OutlinedButton({ bgPicker.launch(PickVisualMediaRequest(PickVisualMedia.ImageOnly)) }) { Text("Choose a different photo") }
                        Text("Photo dimming: ${(bgDim * 100).toInt()}%", Modifier.padding(top = 8.dp))
                        Slider(bgDim, { bgDim = it }, valueRange = 0f..0.8f, onValueChangeFinished = { prefs.edit().putFloat("bgDim", bgDim).apply() })
                        if (Build.VERSION.SDK_INT >= 31) {
                            Text("Photo blur: ${bgBlur.toInt()}")
                            Slider(bgBlur, { bgBlur = it }, valueRange = 0f..25f, onValueChangeFinished = { prefs.edit().putFloat("bgBlur", bgBlur).apply() })
                        }
                    } else if (bgKind != "none") {
                        SwitchRow("Animate background", bgAnimated) { bgAnimated = it; prefs.edit().putBoolean("bgAnimated", it).apply() }
                        SwitchRow("Floating sparkles", bgSparkles) { bgSparkles = it; prefs.edit().putBoolean("bgSparkles", it).apply() }
                    }
                    Spacer(Modifier.height(16.dp))
                    Button({ confirmClear = true }, colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)) {
                        Text("Delete all memories (${memories.size})")
                    }
                    Text("Developed by Junnel Entoma", Modifier.fillMaxWidth().padding(top = 24.dp), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center)
                }
            }

        } else {
            val themed = bgKind != "none"
            val light = !dark && !themed
            val main = if (light) Color(0xFF121212) else Color.White
            val pal = Pal(when { themed -> Color.Black.copy(alpha = 0.4f); dark -> Color(0xFF232325); else -> Color(0xFFF0F0F3) }, main, main.copy(alpha = 0.62f), themed)
            val drawerState = rememberDrawerState(DrawerValue.Closed)
            val scope = rememberCoroutineScope()
            val focus = remember { FocusRequester() }
            LaunchedEffect(searching) { if (searching) focus.requestFocus() }
            BackHandler(searching) { searching = false; query = "" }

            val q = query.trim().lowercase()
            val sorted = (if (newest) memories.sortedByDescending { it.time } else memories.sortedBy { it.time }).filter { m ->
                (when (filter) { "pinned" -> m.pinned; "notes" -> m.note; "images" -> !m.note && !m.isVideo; "videos" -> m.isVideo; else -> true }) &&
                    (q.isEmpty() || m.caption.lowercase().contains(q) || m.body.lowercase().contains(q))
            }
            val entries = buildList<Entry> {
                add(Entry.Title)
                if (sorted.isEmpty()) add(Entry.Empty)
                val top = if (filter == "pinned") emptyList() else sorted.filter { it.pinned }
                if (top.isNotEmpty()) { add(Entry.Header("Pinned")); top.forEach { add(Entry.Item(it)) } }
                var last = ""
                sorted.filter { it !in top }.forEach { m ->
                    val b = bucketOf(m.time)
                    if (b != last) { add(Entry.Header(b)); last = b }
                    add(Entry.Item(m))
                }
            }
            val heading = filterLook(filter).label
            val count = "${sorted.size} ${if (sorted.size == 1) "note" else "notes"}"
            val open: (Memory) -> Unit = { if (it.note) editNote(it) else viewing = it }
            val del: (Memory) -> Unit = { deleteFiles(ctx, it); commit(memories - it) }
            val pin: (Memory) -> Unit = { m -> commit(memories.map { if (it.file == m.file) it.copy(pinned = !it.pinned) else it }) }
            val keyOf: (Entry) -> Any = { e -> when (e) { is Entry.Title -> "title"; is Entry.Empty -> "empty"; is Entry.Header -> "h_${e.text}"; is Entry.Item -> e.m.file } }
            val pad = PaddingValues(start = 12.dp, end = 12.dp, bottom = 130.dp)

            ModalNavigationDrawer(drawerState = drawerState, drawerContent = {
                ModalDrawerSheet {
                    Column(Modifier.verticalScroll(rememberScrollState())) {
                        Box(Modifier.fillMaxWidth().background(Brush.linearGradient(listOf(Color(0xFF2A1B6B), Color(0xFF0F6E7A), Color(0xFFD9552B)))).statusBarsPadding().padding(22.dp)) {
                            Column {
                                Box(Modifier.size(56.dp).graphicsLayer { rotationZ = -8f }.clip(RoundedCornerShape(16.dp)).background(Brush.linearGradient(listOf(Color(0xFFFFEB3B), Color(0xFFFFB300)))), Alignment.Center) { Text("\uD83D\uDCCC", fontSize = 28.sp) }
                                Spacer(Modifier.height(14.dp))
                                Text("PostIt", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Black)
                                Text("Your memories, pinned", color = Color.White.copy(alpha = 0.8f), fontSize = 13.sp)
                                Spacer(Modifier.height(10.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    for (t in listOf("${memories.size} memories", "${annivs.size} anniversaries"))
                                        Text(t, Modifier.clip(RoundedCornerShape(50)).background(Color.White.copy(alpha = 0.2f)).padding(horizontal = 10.dp, vertical = 4.dp), color = Color.White, fontSize = 12.sp)
                                }
                                val dayNow by rememberToday()
                                annivs.minByOrNull { it.countdown(dayNow).days }?.let { n ->
                                    val dl = n.countdown(dayNow).days
                                    Text("Next: ${n.title} \u2022 " + when (dl) { 0 -> "today!"; 1 -> "tomorrow"; else -> "in $dl days" }, Modifier.padding(top = 10.dp), color = Color.White.copy(alpha = 0.9f), fontSize = 13.sp, fontWeight = FontWeight.Medium)
                                }
                            }
                        }
                        Spacer(Modifier.height(8.dp))
                        val close: () -> Unit = { scope.launch { drawerState.close() } }
                        DrawerItem({ Text(filterLook("all").emoji, fontSize = 18.sp) }, filterLook("all").label, "${memories.size}", filter == "all", filterLook("all").c1, filterLook("all").c2) { filter = "all"; close() }
                        DrawerItem({ Text(filterLook("pinned").emoji, fontSize = 18.sp) }, filterLook("pinned").label, "${memories.count { it.pinned }}", filter == "pinned", filterLook("pinned").c1, filterLook("pinned").c2) { filter = "pinned"; close() }
                        DrawerItem({ Text(filterLook("notes").emoji, fontSize = 18.sp) }, filterLook("notes").label, "${memories.count { it.note }}", filter == "notes", filterLook("notes").c1, filterLook("notes").c2) { filter = "notes"; close() }
                        DrawerItem({ Text(filterLook("images").emoji, fontSize = 18.sp) }, filterLook("images").label, "${memories.count { !it.note && !it.isVideo }}", filter == "images", filterLook("images").c1, filterLook("images").c2) { filter = "images"; close() }
                        DrawerItem({ VideoIcon(Color.White, 22.dp) }, filterLook("videos").label, "${memories.count { it.isVideo }}", filter == "videos", filterLook("videos").c1, filterLook("videos").c2) { filter = "videos"; close() }
                        Spacer(Modifier.height(10.dp))
                        DrawerItem({ CalendarIcon(Color.White, 20.dp) }, "Anniversaries", "${annivs.size}", false, Color(0xFFF4B400), Color(0xFFFF7A59)) { calOpen = true; close() }
                        DrawerItem({ Text("\uD83C\uDFA8", fontSize = 18.sp) }, "Photo Studio", null, false, Color(0xFF6C3BFF), Color(0xFFFF4D8D)) { editorOpen = true; close() }
                        DrawerItem({ Icon(Icons.Filled.Settings, null, Modifier.size(20.dp), tint = Color.White) }, "Settings", null, false, Color(0xFF607D8B), Color(0xFF90A4AE)) { settings = true; close() }
                        val appVer = remember { appVersion(ctx) }
                        Column(Modifier.fillMaxWidth().padding(top = 14.dp, bottom = 22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Box(Modifier.padding(horizontal = 24.dp).fillMaxWidth().height(1.dp).background(MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.15f)))
                            if (appVer.isNotEmpty()) Text(
                                "Version $appVer",
                                Modifier.padding(top = 16.dp).clip(RoundedCornerShape(50)).background(MaterialTheme.colorScheme.primary.copy(alpha = 0.14f)).padding(horizontal = 14.dp, vertical = 5.dp),
                                color = MaterialTheme.colorScheme.primary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, maxLines = 1
                            )
                            Text("Developed by Junnel Entoma", Modifier.padding(top = 10.dp), textAlign = TextAlign.Center, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }) {
                Box(Modifier.fillMaxSize().background(if (themed) Color.Transparent else MaterialTheme.colorScheme.background)) {
                    if (themed) HomeBackground(
                        bgKind, bgAnimated, bgSparkles, dark,
                        if (bgPhoto.isNotEmpty()) File(ctx.filesDir, bgPhoto) else null,
                        bgDim, bgBlur, Modifier.fillMaxSize()
                    )
                    Column(Modifier.fillMaxSize().statusBarsPadding()) {
                        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp).height(64.dp), verticalAlignment = Alignment.CenterVertically) {
                            if (searching) {
                                IconButton({ searching = false; query = "" }) { Icon(Icons.Filled.ArrowBack, "Close search", tint = main) }
                                TextField(
                                    query, { query = it }, Modifier.weight(1f).focusRequester(focus), singleLine = true, placeholder = { Text("Search notes") },
                                    colors = TextFieldDefaults.colors(
                                        focusedContainerColor = Color.Transparent, unfocusedContainerColor = Color.Transparent,
                                        focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent,
                                        focusedTextColor = main, unfocusedTextColor = main, cursorColor = Accent,
                                        focusedPlaceholderColor = pal.sub, unfocusedPlaceholderColor = pal.sub
                                    )
                                )
                            } else {
                                Box(Modifier.padding(start = 4.dp)) { MenuOrb(drawerState.targetValue == DrawerValue.Open, main) { scope.launch { drawerState.open() } } }
                                Spacer(Modifier.weight(1f))
                                IconButton({ searching = true }) { Icon(Icons.Filled.Search, "Search", tint = main) }
                                Box {
                                    IconButton({ moreOpen = true }) { Icon(Icons.Filled.MoreVert, "More", tint = main) }
                                    DropdownMenu(moreOpen, { moreOpen = false }) {
                                        DropdownMenuItem({ Text(if (newest) "Show oldest first" else "Show newest first") }, { newest = !newest; prefs.edit().putBoolean("newest", newest).apply(); moreOpen = false })
                                    }
                                }
                            }
                        }
                        val content: @Composable (Entry, Int, Boolean) -> Unit = { e, i, compact ->
                            EntryContent(e, i, compact, pal, filter, heading, count, floatStyle, open, { editNote(it) }, pin, del)
                        }
                        val env = LayoutEnv(pal, filter, heading, count, floatStyle, MemoryActions(open, { editNote(it) }, pin, del))
                        Crossfade(layout, Modifier.fillMaxSize(), animationSpec = tween(260), label = "layoutFade") { lay ->
                            when (lay) {
                                "grid" -> LazyVerticalStaggeredGrid(
                                    StaggeredGridCells.Fixed(cols), Modifier.fillMaxSize(), contentPadding = pad,
                                    verticalItemSpacing = 10.dp, horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    itemsIndexed(entries, key = { _, e -> keyOf(e) }, span = { _, e -> if (e is Entry.Item) StaggeredGridItemSpan.SingleLane else StaggeredGridItemSpan.FullLine }) { i, e -> content(e, i, true) }
                                }
                                "list" -> LazyColumn(Modifier.fillMaxSize(), contentPadding = pad, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                    itemsIndexed(entries, key = { _, e -> keyOf(e) }) { i, e -> content(e, i, false) }
                                }
                                else -> MemoryLayoutHost(lay, entries, env, pad)
                            }
                        }
                    }
                    GridDock(
                        layout, pill,
                        { layoutOpen = true },
                        { editNote(null) },
                        { calOpen = true },
                        { picker.launch(PickVisualMediaRequest(PickVisualMedia.ImageOnly)) },
                        { videoPicker.launch(arrayOf("video/*")) }
                    )
                }
            }
        }


        if (layoutOpen) LayoutPicker(layout, dark, { layout = it; prefs.edit().putString("layout", it).apply() }, { layoutOpen = false })

        pending?.let { uri ->
            MediaPostSheet(false, uri, false, { cap, note, pin ->
                val name = "img_${System.currentTimeMillis()}"
                ctx.contentResolver.openInputStream(uri)?.use { i -> File(ctx.filesDir, name).outputStream().use { o -> i.copyTo(o) } }
                commit(memories + Memory(name, cap, System.currentTimeMillis(), pin, note))
                pending = null
            }, { pending = null })
        }
        pendingVideo?.let { uri ->
            MediaPostSheet(true, uri, videoBusy, { cap, note, pin ->
                videoBusy = true
                appScope.launch {
                    val mem = importVideo(ctx, uri, cap, note, pin)
                    if (mem != null) commit(memories + mem) else Toast.makeText(ctx, "Could not add this video", Toast.LENGTH_SHORT).show()
                    videoBusy = false; pendingVideo = null
                }
            }, { pendingVideo = null })
        }
        viewing?.let { m ->
            val cur = memories.firstOrNull { it.file == m.file } ?: m
            Dialog(onDismissRequest = { viewing = null }, properties = DialogProperties(usePlatformDefaultWidth = false)) {
                if (cur.isVideo) VideoViewer(cur, { viewing = null; editNote(cur) }, { viewing = null })
                else PhotoViewer(cur, { t -> commit(memories.map { if (it.file == m.file) it.copy(body = t) else it }) }, { viewing = null; editNote(cur) }, { viewing = null })
            }
        }
        if (confirmClear) {
            AlertDialog(
                onDismissRequest = { confirmClear = false }, title = { Text("Delete all memories?") }, text = { Text("This cannot be undone.") },
                confirmButton = { TextButton({ memories.forEach { deleteFiles(ctx, it) }; commit(emptyList()); confirmClear = false }) { Text("Delete") } },
                dismissButton = { TextButton({ confirmClear = false }) { Text("Cancel") } }
            )
        }

        if (noteOpen) {
            val ed = noteEditing
            NoteSheet(
                mode = when { ed == null -> 0; !ed.note -> 2; else -> 1 },
                image = ed?.takeIf { !it.note }?.let { File(ctx.filesDir, it.file) },
                initialTitle = noteTitle, initialBody = noteBody,
                onSave = { t, b ->
                    val now = System.currentTimeMillis()
                    if (ed == null) commit(memories + Memory("note_$now", t, now, false, b, true))
                    else commit(memories.map { if (it.file == ed.file) it.copy(caption = t, body = b) else it })
                    noteOpen = false
                },
                onDismiss = { noteOpen = false }
            )
        }
    }
}

// ---------------------------------------------------------------- Anniversary calendar

data class Anniv(val id: Long, val title: String, val year: Int, val month: Int, val day: Int)

val MONTHS = listOf("January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December")

fun loadAnn(p: SharedPreferences): List<Anniv> {
    val a = JSONArray(p.getString("anniv", "[]"))
    return (0 until a.length()).map { val o = a.getJSONObject(it); Anniv(o.getLong("i"), o.getString("t"), o.getInt("y"), o.getInt("m"), o.getInt("d")) }
}

fun saveAnn(p: SharedPreferences, l: List<Anniv>) {
    val a = JSONArray(l.map { JSONObject().put("i", it.id).put("t", it.title).put("y", it.year).put("m", it.month).put("d", it.day) })
    p.edit().putString("anniv", a.toString()).apply()
}

/** Anniversaries repeat every year, starting from the year they were first set. */
fun Anniv.on(y: Int, m: Int, d: Int) = month == m && day == d && y >= year

// ---- Countdown engine: exact calendar-day maths (no clock/DST rounding), refreshed every midnight.

data class Day(val y: Int, val m: Int, val d: Int)

fun nowDay(): Day { val c = Calendar.getInstance(); return Day(c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH)) }

fun isLeap(y: Int) = (y % 4 == 0 && y % 100 != 0) || y % 400 == 0
fun daysIn(y: Int, m: Int) = when (m) { 2 -> if (isLeap(y)) 29 else 28; 4, 6, 9, 11 -> 30; else -> 31 }

/** Days since 1970-01-01 for a calendar date. */
fun epochDay(y: Int, m: Int, d: Int): Long {
    val yy = if (m <= 2) y - 1 else y
    val era = (if (yy >= 0) yy else yy - 399) / 400
    val yoe = yy - era * 400
    val doy = (153 * (m + (if (m > 2) -3 else 9)) + 2) / 5 + d - 1
    val doe = yoe * 365 + yoe / 4 - yoe / 100 + doy
    return era * 146097L + doe - 719468L
}

fun ordinal(n: Int) = "$n" + when { n % 100 in 11..13 -> "th"; n % 10 == 1 -> "st"; n % 10 == 2 -> "nd"; n % 10 == 3 -> "rd"; else -> "th" }

class Countdown(val days: Int, val years: Int, val months: Int, val rem: Int)

/** A Feb 29 anniversary is celebrated on Feb 28 in years that have no Feb 29. */
fun Anniv.occ(y: Int) = if (month == 2 && day == 29 && !isLeap(y)) 28 else day

/** Days left (0 = today), which anniversary number it will be, and the months/days breakdown. */
fun Anniv.countdown(t: Day): Countdown {
    val todayEpoch = epochDay(t.y, t.m, t.d)
    fun left(yy: Int) = (epochDay(yy, month, occ(yy)) - todayEpoch).toInt()
    var y = maxOf(t.y, year)
    var days = left(y)
    if (days < 0) { y++; days = left(y) }
    val od = occ(y)
    var mo = (y * 12 + month) - (t.y * 12 + t.m)
    if (od < t.d) mo--
    mo = mo.coerceAtLeast(0)
    val am = t.y * 12 + t.m - 1 + mo
    val ay = am / 12; val amo = am % 12 + 1
    val ad = minOf(t.d, daysIn(ay, amo))
    val rem = (epochDay(y, month, od) - epochDay(ay, amo, ad)).toInt().coerceAtLeast(0)
    return Countdown(days, y - year, mo, rem)
}

fun Countdown.breakdown(): String {
    if (days < 7) return ""
    if (days < 31) return "${days / 7} wk" + if (days % 7 > 0) " ${days % 7} d" else ""
    return listOfNotNull(
        (months / 12).takeIf { it > 0 }?.let { "$it yr" },
        (months % 12).takeIf { it > 0 }?.let { "$it mo" },
        rem.takeIf { it > 0 }?.let { "$it d" }
    ).joinToString(" ")
}

/** Today's date as live state: it moves forward at midnight, when the app resumes, and when the phone's date, time or time zone changes. */
@Composable
fun rememberToday(): State<Day> {
    val ctx = LocalContext.current
    val owner = LocalLifecycleOwner.current
    val day = remember { mutableStateOf(nowDay()) }
    LaunchedEffect(day.value) {
        while (true) {
            val n = Calendar.getInstance()
            val next = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, 1); set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 1); set(Calendar.MILLISECOND, 0) }
            delay((next.timeInMillis - n.timeInMillis).coerceAtLeast(1000L))
            day.value = nowDay()
        }
    }
    DisposableEffect(ctx, owner) {
        val refresh = { day.value = nowDay() }
        val receiver = object : BroadcastReceiver() { override fun onReceive(c: Context?, i: Intent?) { refresh() } }
        val filter = IntentFilter().apply { addAction(Intent.ACTION_DATE_CHANGED); addAction(Intent.ACTION_TIME_CHANGED); addAction(Intent.ACTION_TIMEZONE_CHANGED) }
        ctx.registerReceiver(receiver, filter)
        val obs = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) refresh() }
        owner.lifecycle.addObserver(obs)
        onDispose { ctx.unregisterReceiver(receiver); owner.lifecycle.removeObserver(obs) }
    }
    return day
}

@Composable
fun CalendarIcon(color: Color, size: Dp = 24.dp) = Canvas(Modifier.size(size)) {
    val w = this.size.width; val sw = 2.2.dp.toPx()
    drawRoundRect(color, Offset(w * 0.08f, w * 0.16f), Size(w * 0.84f, w * 0.76f), CornerRadius(w * 0.16f), style = Stroke(sw))
    drawLine(color, Offset(w * 0.08f, w * 0.4f), Offset(w * 0.92f, w * 0.4f), strokeWidth = sw)
    drawLine(color, Offset(w * 0.32f, w * 0.06f), Offset(w * 0.32f, w * 0.26f), strokeWidth = sw)
    drawLine(color, Offset(w * 0.68f, w * 0.06f), Offset(w * 0.68f, w * 0.26f), strokeWidth = sw)
    drawCircle(color, w * 0.07f, Offset(w * 0.5f, w * 0.66f))
}

@Composable
fun AnnivDialog(initial: Anniv?, def: Triple<Int, Int, Int>, onSave: (Anniv) -> Unit, onDismiss: () -> Unit) {
    var title by remember { mutableStateOf(initial?.title ?: "") }
    var y by remember { mutableIntStateOf(initial?.year ?: def.first) }
    var m by remember { mutableIntStateOf(initial?.month ?: def.second) }
    var d by remember { mutableIntStateOf(initial?.day ?: def.third) }
    var picking by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "New anniversary" else "Edit anniversary") },
        text = {
            Column {
                OutlinedTextField(title, { title = it }, label = { Text("Title") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(12.dp))
                OutlinedButton({ picking = true }, Modifier.fillMaxWidth()) { Text("${MONTHS[m - 1]} $d, $y") }
                Text("Repeats every year", Modifier.padding(top = 8.dp), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        },
        confirmButton = { TextButton({ onSave(Anniv(initial?.id ?: System.currentTimeMillis(), title.trim(), y, m, d)) }, enabled = title.isNotBlank()) { Text("Save") } },
        dismissButton = { TextButton(onDismiss) { Text("Cancel") } }
    )
    if (picking) {
        val utc = TimeZone.getTimeZone("UTC")
        val st = rememberDatePickerState(initialSelectedDateMillis = Calendar.getInstance(utc).apply { clear(); set(y, m - 1, d) }.timeInMillis)
        DatePickerDialog(
            { picking = false },
            confirmButton = {
                TextButton({
                    st.selectedDateMillis?.let { ms -> val c = Calendar.getInstance(utc); c.timeInMillis = ms; y = c.get(Calendar.YEAR); m = c.get(Calendar.MONTH) + 1; d = c.get(Calendar.DAY_OF_MONTH) }
                    picking = false
                }) { Text("OK") }
            },
            dismissButton = { TextButton({ picking = false }) { Text("Cancel") } }
        ) { DatePicker(st) }
    }
}

@Composable
fun AnnivRow(a: Anniv, today: Day, onEdit: () -> Unit, onDelete: () -> Unit) {
    val c = a.countdown(today)
    val sub = MaterialTheme.colorScheme.onSurfaceVariant
    val frac = ((365 - c.days) / 365f).coerceIn(0f, 1f)
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(MaterialTheme.colorScheme.surfaceVariant).clickable(onClick = onEdit).padding(start = 16.dp, top = 12.dp, bottom = 12.dp, end = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(a.title, fontSize = 18.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text("${MONTHS[a.month - 1]} ${a.day}, ${a.year}", fontSize = 14.sp, color = sub)
            if (c.years > 0) Text("${ordinal(c.years)} anniversary", fontSize = 13.sp, color = Accent, fontWeight = FontWeight.Medium)
            val bd = c.breakdown()
            if (bd.isNotEmpty()) Text(bd, fontSize = 13.sp, color = sub)
            Box(Modifier.padding(top = 8.dp, end = 12.dp).fillMaxWidth().height(4.dp).clip(RoundedCornerShape(50)).background(Color.White.copy(alpha = 0.1f))) {
                Box(Modifier.fillMaxWidth(frac).fillMaxHeight().clip(RoundedCornerShape(50)).background(Brush.horizontalGradient(listOf(Accent, Color(0xFFFF7A59)))))
            }
        }
        Column(
            Modifier.width(78.dp).clip(RoundedCornerShape(16.dp)).background(Accent.copy(alpha = 0.14f)).padding(vertical = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            if (c.days == 0) {
                Text("\uD83C\uDF89", fontSize = 24.sp)
                Text("Today!", color = Accent, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            } else {
                Text("${c.days}", color = Accent, fontWeight = FontWeight.Black, fontSize = 28.sp, lineHeight = 30.sp)
                Text(if (c.days == 1) "day left" else "days left", color = Accent, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
            }
        }
        IconButton(onDelete) { Icon(Icons.Filled.Delete, "Delete", Modifier.size(18.dp), tint = sub) }
    }
}

@Composable
fun AnniversaryScreen(list: List<Anniv>, onChange: (List<Anniv>) -> Unit, onBack: () -> Unit) {
    val today by rememberToday()
    val ty = today.y; val tm = today.m; val td = today.d
    var ym by remember { mutableIntStateOf(ty * 12 + tm - 1) }
    var sel by remember { mutableStateOf(Triple(ty, tm, td)) }
    var editing by remember { mutableStateOf<Anniv?>(null) }
    var dialog by remember { mutableStateOf(false) }
    var lastToday by remember { mutableStateOf(today) }
    LaunchedEffect(today) {
        if (today != lastToday) {
            if (sel == Triple(lastToday.y, lastToday.m, lastToday.d)) { sel = Triple(ty, tm, td); ym = ty * 12 + tm - 1 }
            lastToday = today
        }
    }
    val year = ym / 12; val month = ym % 12 + 1
    val first = Calendar.getInstance().apply { set(year, month - 1, 1) }
    val offset = first.get(Calendar.DAY_OF_WEEK) - 1
    val dim = first.getActualMaximum(Calendar.DAY_OF_MONTH)
    val weeks = (offset + dim + 6) / 7
    val onDay = list.filter { it.on(sel.first, sel.second, sel.third) }
    val upcoming = list.sortedBy { it.countdown(today).days }
    val fg = MaterialTheme.colorScheme.onBackground

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Anniversaries") },
                navigationIcon = { IconButton(onBack) { Icon(Icons.Filled.ArrowBack, "Back") } },
                actions = { TextButton({ ym = ty * 12 + tm - 1; sel = Triple(ty, tm, td) }) { Text("Today", color = Accent) } }
            )
        },
        floatingActionButton = {
            FloatingActionButton({ editing = null; dialog = true }, containerColor = Accent, contentColor = Color.White) { Icon(Icons.Filled.Add, "Add anniversary") }
        }
    ) { pad ->
        LazyColumn(Modifier.fillMaxSize().padding(pad), contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 96.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            item {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    IconButton({ ym-- }) { Icon(Icons.Filled.ArrowBack, "Previous month") }
                    Text("${MONTHS[month - 1]} $year", Modifier.weight(1f), textAlign = TextAlign.Center, fontSize = 20.sp, fontWeight = FontWeight.Medium)
                    IconButton({ ym++ }) { Icon(Icons.Filled.ArrowForward, "Next month") }
                }
                Row(Modifier.fillMaxWidth()) {
                    for (w in listOf("S", "M", "T", "W", "T", "F", "S")) Text(w, Modifier.weight(1f), textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
                }
                for (w in 0 until weeks) Row(Modifier.fillMaxWidth()) {
                    for (c in 0..6) {
                        val d = w * 7 + c - offset + 1
                        if (d < 1 || d > dim) { Spacer(Modifier.weight(1f).aspectRatio(1f)); continue }
                        val isSel = sel == Triple(year, month, d)
                        val isToday = year == ty && month == tm && d == td
                        val has = list.any { it.on(year, month, d) }
                        Box(
                            Modifier.weight(1f).aspectRatio(1f).padding(3.dp).clip(CircleShape)
                                .background(if (isSel) Accent else Color.Transparent)
                                .then(if (isToday && !isSel) Modifier.border(1.5.dp, Accent, CircleShape) else Modifier)
                                .clickable { sel = Triple(year, month, d) },
                            Alignment.Center
                        ) {
                            Text("$d", color = if (isSel) Color.Black else fg, fontWeight = if (isToday) FontWeight.Bold else FontWeight.Normal)
                            if (has) Box(Modifier.align(Alignment.BottomCenter).padding(bottom = 5.dp).size(5.dp).clip(CircleShape).background(if (isSel) Color.Black else Accent))
                        }
                    }
                }
            }
            item { Text("${MONTHS[sel.second - 1]} ${sel.third}, ${sel.first}", Modifier.padding(top = 12.dp), fontSize = 16.sp, fontWeight = FontWeight.SemiBold) }
            if (onDay.isEmpty()) item { Text("No anniversaries on this day.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
            items(onDay, key = { "d${it.id}" }) { a -> AnnivRow(a, today, { editing = a; dialog = true }, { onChange(list - a) }) }
            item { Text("Upcoming", Modifier.padding(top = 16.dp), fontSize = 16.sp, fontWeight = FontWeight.SemiBold) }
            if (upcoming.isEmpty()) item { Text("Tap + to add your first anniversary.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
            items(upcoming, key = { "u${it.id}" }) { a -> AnnivRow(a, today, { editing = a; dialog = true }, { onChange(list - a) }) }
        }
    }
    if (dialog) {
        AnnivDialog(editing, sel, { n ->
            onChange(if (editing == null) list + n else list.map { if (it.id == n.id) n else it })
            val vy = maxOf(year, n.year)
            sel = Triple(vy, n.month, n.day)
            ym = vy * 12 + n.month - 1
            dialog = false
        }, { dialog = false })
    }
}


// ---------------------------------------------------------------- Sidebar icon + drawer rows

/** Animated menu button: gradient tile whose bars morph into an X while the drawer is open. */
@Composable
fun MenuOrb(open: Boolean, tint: Color, onClick: () -> Unit) {
    val p by animateFloatAsState(if (open) 1f else 0f, tween(350), label = "orb")
    val shape = RoundedCornerShape(14.dp)
    Box(
        Modifier.size(44.dp).clip(shape)
            .background(Brush.linearGradient(listOf(Accent.copy(alpha = 0.30f), Color(0xFFFF7A59).copy(alpha = 0.22f))))
            .border(1.dp, Accent.copy(alpha = 0.6f), shape).clickable(onClick = onClick),
        Alignment.Center
    ) {
        Canvas(Modifier.size(22.dp)) {
            val w = size.width; val h = size.height; val t = 2.6.dp.toPx(); val cx = w / 2f; val cy = h / 2f
            fun bar(y: Float, len: Float, deg: Float, a: Float) {
                val l = w * len
                val x = w * 0.04f + ((w - l) / 2f - w * 0.04f) * p
                rotate(deg, Offset(cx, cy)) { drawRoundRect(tint.copy(alpha = a), Offset(x, y - t / 2f), Size(l, t), CornerRadius(t / 2f)) }
            }
            bar(h * 0.2f + (cy - h * 0.2f) * p, 0.92f, 45f * p, 1f)
            bar(cy, 0.55f, 0f, 1f - p)
            bar(h * 0.8f - (h * 0.8f - cy) * p, 0.75f + 0.17f * p, -45f * p, 1f)
        }
    }
}

@Composable
fun DrawerItem(icon: @Composable () -> Unit, label: String, badge: String?, selected: Boolean, c1: Color, c2: Color, onClick: () -> Unit) {
    Row(
        Modifier.padding(horizontal = 12.dp, vertical = 2.dp).fillMaxWidth().clip(RoundedCornerShape(16.dp))
            .background(if (selected) Accent.copy(alpha = 0.18f) else Color.Transparent).clickable(onClick = onClick).padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(38.dp).clip(RoundedCornerShape(12.dp)).background(Brush.linearGradient(listOf(c1, c2))), Alignment.Center) { icon() }
        Spacer(Modifier.width(14.dp))
        Text(label, Modifier.weight(1f), fontSize = 16.sp, fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium)
        if (badge != null) Text(badge, fontSize = 14.sp, color = if (selected) Accent else MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

// ---------------------------------------------------------------- Photo Studio

data class Edit(
    val filter: Int = 0, val bright: Float = 0f, val contrast: Float = 1f, val sat: Float = 1f, val warm: Float = 0f,
    val vignette: Float = 0f, val rot: Int = 0, val flip: Boolean = false, val ratio: Float = 0f
)

val FILTERS = listOf("Original", "Vivid", "Warm", "Cool", "Mono", "Noir", "Sepia", "Fade", "Dream")
val RATIOS = listOf("Free" to 0f, "1:1" to 1f, "4:5" to 0.8f, "4:3" to 1.3333f, "16:9" to 1.7778f, "9:16" to 0.5625f)

private fun cm(vararg v: Float) = AColorMatrix(v)

fun filterBase(i: Int): AColorMatrix {
    val m = AColorMatrix()
    when (i) {
        1 -> { m.setSaturation(1.5f); m.postConcat(cm(1.1f,0f,0f,0f,-8f, 0f,1.1f,0f,0f,-8f, 0f,0f,1.1f,0f,-8f, 0f,0f,0f,1f,0f)) }
        2 -> m.set(floatArrayOf(1.12f,0f,0f,0f,8f, 0f,1.02f,0f,0f,0f, 0f,0f,0.88f,0f,-8f, 0f,0f,0f,1f,0f))
        3 -> m.set(floatArrayOf(0.88f,0f,0f,0f,-6f, 0f,1f,0f,0f,0f, 0f,0f,1.14f,0f,10f, 0f,0f,0f,1f,0f))
        4 -> m.setSaturation(0f)
        5 -> { m.setSaturation(0f); m.postConcat(cm(1.45f,0f,0f,0f,-45f, 0f,1.45f,0f,0f,-45f, 0f,0f,1.45f,0f,-45f, 0f,0f,0f,1f,0f)) }
        6 -> m.set(floatArrayOf(0.393f,0.769f,0.189f,0f,0f, 0.349f,0.686f,0.168f,0f,0f, 0.272f,0.534f,0.131f,0f,0f, 0f,0f,0f,1f,0f))
        7 -> { m.setSaturation(0.75f); m.postConcat(cm(0.85f,0f,0f,0f,28f, 0f,0.85f,0f,0f,28f, 0f,0f,0.85f,0f,28f, 0f,0f,0f,1f,0f)) }
        8 -> { m.setSaturation(1.25f); m.postConcat(cm(1f,0f,0f,0f,18f, 0f,1f,0f,0f,6f, 0f,0f,1.08f,0f,22f, 0f,0f,0f,1f,0f)) }
    }
    return m
}

fun adjustMatrix(e: Edit): AColorMatrix {
    val m = filterBase(e.filter)
    val sat = AColorMatrix().apply { setSaturation(e.sat) }
    val c = e.contrast
    val t = (1f - c) * 128f + e.bright * 100f
    val w = e.warm * 30f
    m.postConcat(sat)
    m.postConcat(cm(c,0f,0f,0f,t, 0f,c,0f,0f,t, 0f,0f,c,0f,t, 0f,0f,0f,1f,0f))
    m.postConcat(cm(1f,0f,0f,0f,w, 0f,1f,0f,0f,0f, 0f,0f,1f,0f,-w, 0f,0f,0f,1f,0f))
    return m
}

fun colorFilterOf(e: Edit) = androidx.compose.ui.graphics.ColorFilter.colorMatrix(androidx.compose.ui.graphics.ColorMatrix(adjustMatrix(e).array))

fun decodeBitmap(ctx: Context, uri: Uri, max: Int = 2048): Bitmap? = try {
    val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
    var s = 1
    while (o.outWidth / s > max || o.outHeight / s > max) s *= 2
    val o2 = BitmapFactory.Options().apply { inSampleSize = s }
    ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o2) }
} catch (ex: Exception) { null }

fun transformBmp(b: Bitmap, rot: Int, flip: Boolean): Bitmap {
    if (rot == 0 && !flip) return b
    val m = android.graphics.Matrix()
    m.postRotate(rot.toFloat())
    if (flip) m.postScale(-1f, 1f)
    return Bitmap.createBitmap(b, 0, 0, b.width, b.height, m, true)
}

/** Full-resolution export: rotate/flip, centre-crop to ratio, colour matrix, vignette. */
fun renderEdit(src: Bitmap, e: Edit): Bitmap {
    val base = transformBmp(src, e.rot, e.flip)
    var w = base.width; var h = base.height; var x = 0; var y = 0
    if (e.ratio > 0f) {
        if (w.toFloat() / h > e.ratio) { val nw = (h * e.ratio).toInt(); x = (w - nw) / 2; w = nw }
        else { val nh = (w / e.ratio).toInt(); y = (h - nh) / 2; h = nh }
    }
    val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
    val c = android.graphics.Canvas(out)
    val p = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG or android.graphics.Paint.FILTER_BITMAP_FLAG)
    p.colorFilter = android.graphics.ColorMatrixColorFilter(adjustMatrix(e))
    c.drawBitmap(base, -x.toFloat(), -y.toFloat(), p)
    if (e.vignette > 0f) {
        val vp = android.graphics.Paint()
        vp.shader = android.graphics.RadialGradient(
            w / 2f, h / 2f, hypot(w.toFloat(), h.toFloat()) / 2f,
            intArrayOf(0, android.graphics.Color.argb((e.vignette * 255).toInt(), 0, 0, 0)), floatArrayOf(0.55f, 1f), android.graphics.Shader.TileMode.CLAMP
        )
        c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), vp)
    }
    return out
}

// ---------------------------------------------------------------- AI Smart Filter (runs on the phone, nothing is uploaded)

/** What the AI "sees" in a photo: exposure, tonal range, colour cast, saturation and rough scene content (all 0..1 except cast). */
class PhotoStats(
    val mean: Float, val low: Float, val high: Float, val sat: Float, val cast: Float,
    val skin: Float, val sky: Float, val green: Float, val warm: Float, val dark: Float
)

fun analyzePhoto(src: Bitmap): PhotoStats {
    val side = 96
    val small = Bitmap.createScaledBitmap(src, side, side, true)
    val px = IntArray(side * side)
    small.getPixels(px, 0, side, 0, 0, side, side)
    val hist = IntArray(256)
    var sr = 0f; var sb = 0f; var ss = 0f
    var skin = 0; var sky = 0; var green = 0; var warm = 0; var dark = 0
    for (i in px.indices) {
        val p = px[i]
        val r = android.graphics.Color.red(p); val g = android.graphics.Color.green(p); val b = android.graphics.Color.blue(p)
        val mx = maxOf(r, g, b); val mn = minOf(r, g, b)
        val lum = (0.299f * r + 0.587f * g + 0.114f * b).toInt().coerceIn(0, 255)
        hist[lum]++
        sr += r; sb += b
        ss += if (mx == 0) 0f else (mx - mn).toFloat() / mx
        if (lum < 40) dark++
        if (r > 95 && g > 40 && b > 20 && r > g && r > b && (r - g) > 15 && (mx - mn) > 15 && (r - g) < 110) skin++
        if (i < px.size / 2 && b > r + 20 && b > g && lum > 90) sky++
        if (g > r + 8 && g > b + 8) green++
        if (r > g + 25 && r > b + 45 && mx > 120) warm++
    }
    val n = px.size.toFloat()
    var total = 0f; var acc = 0; var lo = 0; var hi = 255; var gotLo = false
    for (v in 0..255) {
        total += v * hist[v]; acc += hist[v]
        if (!gotLo && acc >= n * 0.02f) { lo = v; gotLo = true }
        if (acc >= n * 0.98f) { hi = v; break }
    }
    return PhotoStats(
        mean = total / (255f * n), low = lo / 255f, high = hi / 255f, sat = ss / n, cast = (sb - sr) / (255f * n),
        skin = skin / n, sky = sky / n, green = green / n, warm = warm / n, dark = dark / n
    )
}

fun sceneOf(s: PhotoStats): String = when {
    s.mean < 0.22f && s.dark > 0.4f -> "Low light"
    s.skin > 0.2f && s.sat < 0.6f -> "Portrait"
    s.sky + s.green > 0.3f -> "Landscape"
    s.warm > 0.2f && s.mean < 0.5f -> "Sunset"
    s.warm > 0.2f && s.sat > 0.4f -> "Food"
    else -> "Everyday"
}

fun PhotoStats.summary(): String {
    val exp = when { mean < 0.3f -> "Dark"; mean > 0.62f -> "Bright"; else -> "Balanced" }
    val tone = when { cast > 0.06f -> "Cool tones"; cast < -0.06f -> "Warm tones"; else -> "Neutral tones" }
    val col = when { sat < 0.25f -> "Muted"; sat > 0.55f -> "Vivid"; else -> "Natural colors" }
    return "$exp \u2022 $tone \u2022 $col"
}

/** Auto-correction every look starts from: exposure, contrast, white balance and saturation fixed from the photo's own statistics. */
fun autoFix(s: PhotoStats): Edit {
    val range = (s.high - s.low).coerceAtLeast(0.2f)
    val contrast = (0.82f / range).coerceIn(0.9f, 1.35f)
    val bright = ((0.46f * 255f - 128f - contrast * (s.mean * 255f - 128f)) / 100f).coerceIn(-0.3f, 0.45f)
    val warm = (s.cast * 2.5f).coerceIn(-0.8f, 0.8f)
    val sat = (0.42f / s.sat.coerceAtLeast(0.08f)).coerceIn(0.9f, 1.4f)
    return Edit(bright = bright, contrast = contrast, sat = sat, warm = warm)
}

private fun Edit.tuned(b: Float = 0f, c: Float = 1f, sa: Float = 1f, w: Float = 0f, v: Float = 0f) = copy(
    bright = (bright + b).coerceIn(-1f, 1f), contrast = (contrast * c).coerceIn(0.5f, 1.5f),
    sat = (sat * sa).coerceIn(0f, 2f), warm = (warm + w).coerceIn(-1f, 1f), vignette = v.coerceIn(0f, 1f)
)

class AiLook(val name: String, val scene: String, val make: (PhotoStats) -> Edit)

val AI_LOOKS = listOf(
    AiLook("Auto Enhance", "Everyday") { autoFix(it) },
    AiLook("Portrait Glow", "Portrait") { autoFix(it).tuned(b = 0.04f, c = 0.95f, sa = 0.95f, w = 0.12f, v = 0.12f) },
    AiLook("Vivid Scenery", "Landscape") { autoFix(it).tuned(c = 1.08f, sa = 1.25f, w = -0.05f, v = 0.1f) },
    AiLook("Golden Hour", "Sunset") { autoFix(it).tuned(c = 1.05f, sa = 1.1f, w = 0.45f, v = 0.2f) },
    AiLook("Night Boost", "Low light") { autoFix(it).tuned(b = 0.1f, c = 1.1f, sa = 1.15f, w = -0.1f) },
    AiLook("Food Fresh", "Food") { autoFix(it).tuned(b = 0.03f, c = 1.06f, sa = 1.2f, w = 0.1f, v = 0.1f) },
    AiLook("Cinematic", "") { autoFix(it).tuned(b = -0.03f, c = 1.18f, sa = 0.82f, w = -0.18f, v = 0.35f) },
    AiLook("B&W Drama", "") { autoFix(it).tuned(c = 1.3f, sa = 0f, v = 0.3f) }
)

fun bestLookFor(scene: String): Int = AI_LOOKS.indexOfFirst { it.scene == scene }.let { if (it < 0) 0 else it }

/** Applies an AI look at a given strength (0 = untouched, 1 = full) while keeping the user's rotate, flip and crop. */
fun Edit.withAi(t: Edit, k: Float) = copy(
    filter = 0, bright = t.bright * k, contrast = 1f + (t.contrast - 1f) * k,
    sat = 1f + (t.sat - 1f) * k, warm = t.warm * k, vignette = t.vignette * k
)

/** Advanced AI mark: a glowing dark chip, a spinning aurora ring and a pulsing four-point "neural" sparkle cluster. */
private fun sparklePath(cx: Float, cy: Float, r: Float, pinch: Float = 0.12f): Path = Path().apply {
    moveTo(cx, cy - r)
    quadraticBezierTo(cx + r * pinch, cy - r * pinch, cx + r, cy)
    quadraticBezierTo(cx + r * pinch, cy + r * pinch, cx, cy + r)
    quadraticBezierTo(cx - r * pinch, cy + r * pinch, cx - r, cy)
    quadraticBezierTo(cx - r * pinch, cy - r * pinch, cx, cy - r)
    close()
}

@Composable
fun AiIcon(iconSize: Dp = 24.dp) {
    val tr = rememberInfiniteTransition(label = "aiIcon")
    val spin by tr.animateFloat(0f, 360f, infiniteRepeatable(tween(5200, easing = LinearEasing)), label = "spin")
    val pulse by tr.animateFloat(0.78f, 1f, infiniteRepeatable(tween(1300, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "pulse")
    val twinkle by tr.animateFloat(0.3f, 1f, infiniteRepeatable(tween(900, easing = LinearEasing), RepeatMode.Reverse, StartOffset(300)), label = "tw")
    Canvas(Modifier.size(iconSize)) {
        val s = this.size.minDimension
        val c = Offset(s / 2f, s / 2f)
        val ring = listOf(Color(0xFF22D3EE), Color(0xFF8B5CF6), Color(0xFFFF4D8D), Color(0xFFFFB300), Color(0xFF22D3EE))
        // soft glow
        drawCircle(Brush.radialGradient(listOf(Color(0xFF8B5CF6).copy(alpha = 0.55f), Color.Transparent), center = c, radius = s / 2f), s / 2f, c)
        // dark core
        drawCircle(Brush.linearGradient(listOf(Color(0xFF1B1442), Color(0xFF0B2A3B)), Offset.Zero, Offset(s, s)), s * 0.42f, c)
        // spinning aurora ring
        rotate(spin, c) { drawCircle(Brush.sweepGradient(ring, c), s * 0.44f, c, style = Stroke(width = s * 0.08f)) }
        // main sparkle + two satellites
        val big = sparklePath(c.x - s * 0.04f, c.y + s * 0.03f, s * 0.27f * pulse)
        drawPath(big, Brush.linearGradient(listOf(Color.White, Color(0xFF9BE7FF), Color(0xFFC4A8FF)), Offset(0f, 0f), Offset(s, s)))
        drawPath(sparklePath(c.x + s * 0.20f, c.y - s * 0.20f, s * 0.12f * twinkle, 0.15f), SolidColor(Color.White.copy(alpha = twinkle)))
        drawPath(sparklePath(c.x + s * 0.17f, c.y + s * 0.20f, s * 0.08f * (1.3f - twinkle), 0.15f), SolidColor(Color(0xFFFFD36B).copy(alpha = 1.3f - twinkle)))
    }
}

@Composable
fun ToolChip(text: String, selected: Boolean, onClick: () -> Unit) {
    Box(Modifier.clip(RoundedCornerShape(50)).background(if (selected) Accent else Color.White.copy(alpha = 0.12f)).clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 9.dp)) {
        Text(text, color = if (selected) Color.Black else Color.White, fontSize = 14.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
fun AdjSlider(label: String, v: Float, range: ClosedFloatingPointRange<Float>, show: String, onChange: (Float) -> Unit) {
    Column {
        Row(Modifier.fillMaxWidth()) {
            Text(label, Modifier.weight(1f), color = Color.White.copy(alpha = 0.75f), fontSize = 13.sp)
            Text(show, color = Accent, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
        }
        Slider(v, onChange, Modifier.height(30.dp), valueRange = range, colors = SliderDefaults.colors(thumbColor = Accent, activeTrackColor = Accent, inactiveTrackColor = Color.White.copy(alpha = 0.2f)))
    }
}

@Composable
fun PhotoEditor(onClose: () -> Unit, onSave: (String) -> Unit) {
    val ctx = LocalContext.current
    var src by remember { mutableStateOf<Bitmap?>(null) }
    var e by remember { mutableStateOf(Edit()) }
    var tab by remember { mutableIntStateOf(0) }
    var compare by remember { mutableStateOf(false) }
    var aiLook by remember { mutableIntStateOf(-1) }
    var aiStrength by remember { mutableFloatStateOf(1f) }
    val pick = rememberLauncherForActivityResult(PickVisualMedia()) { uri -> if (uri != null) { src = decodeBitmap(ctx, uri); e = Edit(); aiLook = -1; aiStrength = 1f } }
    val choose: () -> Unit = { pick.launch(PickVisualMediaRequest(PickVisualMedia.ImageOnly)) }
    val bmp = src
    val stats = remember(bmp) { if (bmp != null) analyzePhoto(bmp) else null }

    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF17103A), Color(0xFF0A2E3B), Color(0xFF050509))))) {
        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp).height(60.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClose) { Icon(Icons.Filled.Close, "Close", tint = Color.White) }
                Column(Modifier.weight(1f)) {
                    Text("Photo Studio", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text("Edit \u2022 Enhance \u2022 Save", color = Color.White.copy(alpha = 0.6f), fontSize = 11.sp)
                }
                if (bmp != null) {
                    TextButton(choose) { Text("New", color = Color.White.copy(alpha = 0.8f)) }
                    TextButton({ e = Edit(); aiLook = -1; aiStrength = 1f }) { Text("Reset", color = Color.White.copy(alpha = 0.8f)) }
                    Box(
                        Modifier.padding(start = 4.dp, end = 8.dp).clip(RoundedCornerShape(50))
                            .background(Brush.horizontalGradient(listOf(Accent, Color(0xFFFF7A59))))
                            .clickable {
                                val name = "img_${System.currentTimeMillis()}"
                                val out = renderEdit(bmp, e)
                                File(ctx.filesDir, name).outputStream().use { out.compress(Bitmap.CompressFormat.JPEG, 92, it) }
                                onSave(name)
                                Toast.makeText(ctx, "Saved to PostIt", Toast.LENGTH_SHORT).show()
                            }.padding(horizontal = 18.dp, vertical = 9.dp)
                    ) { Text("Save", color = Color.Black, fontWeight = FontWeight.Bold) }
                }
            }
            if (bmp == null) {
                Column(Modifier.weight(1f).fillMaxWidth().padding(32.dp), Arrangement.Center, Alignment.CenterHorizontally) {
                    Box(Modifier.size(120.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Color(0xFF6C3BFF), Color(0xFFFF4D8D), Color(0xFFFF9E40)))), Alignment.Center) { Text("\uD83C\uDFA8", fontSize = 56.sp) }
                    Spacer(Modifier.height(24.dp))
                    Text("Make every photo shine", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                    Text("AI Filters \u2022 Adjustments \u2022 Crop \u2022 Rotate \u2022 Vignette", Modifier.padding(top = 8.dp), color = Color.White.copy(alpha = 0.65f), fontSize = 14.sp, textAlign = TextAlign.Center)
                    Spacer(Modifier.height(28.dp))
                    Box(Modifier.clip(RoundedCornerShape(50)).background(Brush.horizontalGradient(listOf(Accent, Color(0xFFFF7A59)))).clickable { choose() }.padding(horizontal = 32.dp, vertical = 14.dp)) {
                        Text("Choose a photo", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    }
                }
            } else {
                val base = remember(bmp, e.rot, e.flip) { transformBmp(bmp, e.rot, e.flip) }
                val baseImg = remember(base) { base.asImageBitmap() }
                val ratio = if (e.ratio > 0f) e.ratio else base.width.toFloat() / base.height
                Box(Modifier.weight(1f).fillMaxWidth().padding(16.dp), Alignment.Center) {
                    Box(
                        Modifier.aspectRatio(ratio).clip(RoundedCornerShape(20.dp))
                            .pointerInput(Unit) { detectTapGestures(onPress = { compare = true; tryAwaitRelease(); compare = false }) }
                    ) {
                        Image(baseImg, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop, colorFilter = if (compare) null else colorFilterOf(e))
                        if (!compare && e.vignette > 0f) Canvas(Modifier.fillMaxSize()) {
                            drawRect(Brush.radialGradient(0.55f to Color.Transparent, 1f to Color.Black.copy(alpha = e.vignette), center = center, radius = hypot(size.width, size.height) / 2f))
                        }
                        if (compare) Text("ORIGINAL", Modifier.align(Alignment.TopStart).padding(10.dp).clip(RoundedCornerShape(50)).background(Color.Black.copy(alpha = 0.55f)).padding(horizontal = 10.dp, vertical = 4.dp), color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
                Text("Hold the photo to compare", Modifier.fillMaxWidth(), color = Color.White.copy(alpha = 0.5f), fontSize = 11.sp, textAlign = TextAlign.Center)
                Row(Modifier.padding(16.dp).fillMaxWidth().clip(RoundedCornerShape(50)).background(Color.White.copy(alpha = 0.08f)).padding(4.dp)) {
                    listOf("\u2728 Filters", "\uD83C\uDF9A Adjust", "\u2702 Crop", "AI").forEachIndexed { i, t ->
                        Box(Modifier.weight(1f).clip(RoundedCornerShape(50)).background(if (tab == i) Accent else Color.Transparent).clickable { tab = i }.padding(vertical = if (i == 3) 6.dp else 10.dp), Alignment.Center) {
                            if (i == 3) Row(verticalAlignment = Alignment.CenterVertically) {
                                AiIcon(24.dp)
                                Spacer(Modifier.width(5.dp))
                                Text("AI", color = if (tab == i) Color.Black else Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            } else Text(t, color = if (tab == i) Color.Black else Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                        }
                    }
                }
                Column(Modifier.fillMaxWidth().height(224.dp).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp)) {
                    when (tab) {
                        0 -> Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            FILTERS.forEachIndexed { i, name ->
                                val shape = RoundedCornerShape(14.dp)
                                Column(Modifier.clickable { e = e.copy(filter = i) }, horizontalAlignment = Alignment.CenterHorizontally) {
                                    Image(baseImg, name, Modifier.size(88.dp).clip(shape).then(if (e.filter == i) Modifier.border(3.dp, Accent, shape) else Modifier), contentScale = ContentScale.Crop, colorFilter = colorFilterOf(Edit(filter = i)))
                                    Text(name, Modifier.padding(top = 6.dp), color = if (e.filter == i) Accent else Color.White, fontSize = 12.sp)
                                }
                            }
                        }
                        1 -> Column {
                            AdjSlider("Brightness", e.bright, -1f..1f, "${(e.bright * 100).toInt()}") { e = e.copy(bright = it) }
                            AdjSlider("Contrast", e.contrast, 0.5f..1.5f, "${((e.contrast - 1f) * 100).toInt()}") { e = e.copy(contrast = it) }
                            AdjSlider("Saturation", e.sat, 0f..2f, "${((e.sat - 1f) * 100).toInt()}") { e = e.copy(sat = it) }
                            AdjSlider("Warmth", e.warm, -1f..1f, "${(e.warm * 100).toInt()}") { e = e.copy(warm = it) }
                            AdjSlider("Vignette", e.vignette, 0f..1f, "${(e.vignette * 100).toInt()}%") { e = e.copy(vignette = it) }
                        }
                        2 -> Column {
                            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                RATIOS.forEach { (n, r) -> ToolChip(n, e.ratio == r) { e = e.copy(ratio = r) } }
                            }
                            Spacer(Modifier.height(14.dp))
                            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                ToolChip("\u27F2 Left", false) { e = e.copy(rot = (e.rot + 270) % 360) }
                                ToolChip("\u27F3 Right", false) { e = e.copy(rot = (e.rot + 90) % 360) }
                                ToolChip("\u21C6 Flip", e.flip) { e = e.copy(flip = !e.flip) }
                            }
                        }
                        else -> if (stats != null) {
                            val scene = sceneOf(stats)
                            val best = bestLookFor(scene)
                            val order = remember(stats) { AI_LOOKS.indices.sortedBy { if (it == best) -1 else it } }
                            val applyAi: (Int) -> Unit = { i -> aiLook = i; e = e.withAi(AI_LOOKS[i].make(stats), aiStrength) }
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    AiIcon(34.dp)
                                    Spacer(Modifier.width(10.dp))
                                    Column(Modifier.weight(1f)) {
                                        Text("AI scene: $scene", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                                        Text(stats.summary(), color = Color.White.copy(alpha = 0.6f), fontSize = 12.sp)
                                    }
                                    Box(
                                        Modifier.clip(RoundedCornerShape(50)).background(Brush.horizontalGradient(listOf(Accent, Color(0xFFFF7A59))))
                                            .clickable { applyAi(best) }.padding(horizontal = 16.dp, vertical = 8.dp)
                                    ) { Text("Auto", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 13.sp) }
                                }
                                Spacer(Modifier.height(10.dp))
                                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                    order.forEach { i ->
                                        val look = AI_LOOKS[i]
                                        val shape = RoundedCornerShape(14.dp)
                                        Column(Modifier.clickable { applyAi(i) }, horizontalAlignment = Alignment.CenterHorizontally) {
                                            Box {
                                                Image(baseImg, look.name, Modifier.size(88.dp).clip(shape).then(if (aiLook == i) Modifier.border(3.dp, Accent, shape) else Modifier), contentScale = ContentScale.Crop, colorFilter = colorFilterOf(look.make(stats)))
                                                if (i == best) Text("BEST", Modifier.align(Alignment.TopStart).padding(5.dp).clip(RoundedCornerShape(50)).background(Accent).padding(horizontal = 6.dp, vertical = 2.dp), color = Color.Black, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                            }
                                            Text(look.name, Modifier.padding(top = 6.dp), color = if (aiLook == i) Accent else Color.White, fontSize = 12.sp, maxLines = 1)
                                        }
                                    }
                                }
                                if (aiLook >= 0) AdjSlider("AI strength", aiStrength, 0f..1f, "${(aiStrength * 100).toInt()}%") { aiStrength = it; e = e.withAi(AI_LOOKS[aiLook].make(stats), it) }
                            }
                        }
                    }
                }
            }
        }
    }
}
