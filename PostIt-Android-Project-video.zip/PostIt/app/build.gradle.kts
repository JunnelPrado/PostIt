plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "com.postit.app"
    compileSdk = 34
    defaultConfig { applicationId = "com.postit.app"; minSdk = 24; targetSdk = 34; versionCode = 9; versionName = "1.8" }

    // One fixed key for every build, so updates install over the previous version.
    signingConfigs {
        create("postit") {
            storeFile = rootProject.file("postit.keystore")
            storePassword = "postit123"
            keyAlias = "postit"
            keyPassword = "postit123"
        }
    }
    buildTypes {
        getByName("debug") { signingConfig = signingConfigs.getByName("postit") }
        getByName("release") {
            signingConfig = signingConfigs.getByName("postit")
            isMinifyEnabled = false
        }
    }
    lint { checkReleaseBuilds = false; abortOnError = false }

    buildFeatures { compose = true }
    composeOptions { kotlinCompilerExtensionVersion = "1.5.14" }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.06.00"))
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.animation:animation-core")
    implementation("androidx.compose.material:material-icons-core")
    implementation("androidx.activity:activity-compose:1.9.0")
    implementation("io.coil-kt:coil-compose:2.6.0")
    implementation("androidx.core:core-splashscreen:1.0.1")
}
