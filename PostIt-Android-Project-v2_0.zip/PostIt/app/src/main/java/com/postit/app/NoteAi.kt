@file:OptIn(ExperimentalFoundationApi::class)

package com.postit.app

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.core.tween
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.relocation.BringIntoViewRequester
import androidx.compose.foundation.relocation.bringIntoViewRequester
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

// ---------------------------------------------------------------- Smart note engine (runs on the phone, nothing is uploaded)

/** What happens when a suggestion is tapped. */
enum class AiDo { TITLE, WORD, APPEND, REPLACE }

/** One tappable suggestion. [text] is what gets inserted; [group] is the heading it has in the popup. */
class AiTip(
    val emoji: String,
    val label: String,
    val doIt: AiDo,
    val text: String,
    val group: String,
    val hint: String = "",
    val title: String = ""
)

object NoteBrain {
    const val BUL = "\u2022"
    const val TASK = "\u2610"
    const val DONE = "\u2611"

    private val MARK = Regex("^\\s*(?:\u2022|\u2610|\u2611|\\*|-)\\s+")

    private val STOP = setOf(
        "this", "that", "with", "from", "have", "will", "your", "about", "would", "there", "their", "what", "when", "where",
        "which", "while", "been", "were", "they", "them", "then", "than", "into", "some", "just", "also", "very", "much",
        "need", "want", "going", "should", "could", "today", "tomorrow", "remember", "don't", "dont"
    )

    private val WORDS = listOf(
        "tomorrow", "tonight", "remember", "reminder", "meeting", "birthday", "appointment", "grocery", "groceries",
        "important", "dinner", "breakfast", "lunch", "project", "deadline", "homework", "exercise", "together", "beautiful",
        "thankful", "grateful", "schedule", "weekend", "vacation", "shopping", "message", "family", "friends", "because",
        "before", "after", "something", "everything", "finish", "complete", "hospital", "payment", "anniversary",
        "celebrate", "favorite", "different", "definitely", "probably", "though", "through", "between", "another",
        "question", "answer", "review", "update", "assignment", "presentation", "tickets", "reservation", "pharmacy",
        "medicine", "laundry", "cleaning", "budget", "savings", "goals", "organize", "prepare", "practice", "tonight"
    )

    private val TOPICS = listOf(
        "shopping" to Regex("\\b(buy|grocer\\w*|shopping|milk|eggs?|bread|rice|market|store|supermarket)\\b"),
        "trip" to Regex("\\b(trip|travel|flight|hotel|beach|vacation|ticket\\w*|luggage|passport)\\b"),
        "recipe" to Regex("\\b(recipe|cook\\w*|bake|baking|ingredient\\w*|oven)\\b"),
        "event" to Regex("\\b(birthday|anniversary|party|gift|celebrat\\w*|wedding)\\b"),
        "study" to Regex("\\b(study|exam|homework|class|school|quiz|lesson|assignment)\\b"),
        "work" to Regex("\\b(meeting|agenda|client|team|deadline|project|report|boss)\\b"),
        "idea" to Regex("\\b(idea|brainstorm|maybe|what if|concept)\\b"),
        "journal" to Regex("\\b(i feel|i felt|today i|grateful|thankful|miss you|happy|sad|tired)\\b"),
        "todo" to Regex("\\b(todo|to do|to-do|task|remember|don't forget|dont forget|remind|call|pay|bill)\\b")
    )

    private fun cap(s: String): String = if (s.isEmpty()) s else s.substring(0, 1).uppercase(Locale.getDefault()) + s.substring(1)

    private fun part(): String {
        val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        return when { h < 5 -> "night"; h < 12 -> "morning"; h < 17 -> "afternoon"; h < 21 -> "evening"; else -> "night" }
    }

    private fun dateShort(): String = SimpleDateFormat("EEE, MMM d", Locale.getDefault()).format(Date())

    fun topic(text: String): String {
        val t = text.lowercase(Locale.ROOT)
        return TOPICS.firstOrNull { it.second.containsMatchIn(t) }?.first ?: "general"
    }

    private fun emojiFor(topic: String): String = when (topic) {
        "shopping" -> "\uD83D\uDED2"
        "todo" -> "\u2705"
        "work" -> "\uD83D\uDCBC"
        "trip" -> "\u2708"
        "study" -> "\uD83D\uDCDA"
        "event" -> "\uD83C\uDF89"
        else -> "\u2728"
    }

    // ---- text helpers

    fun keywords(text: String, n: Int): List<String> {
        val freq = HashMap<String, Int>()
        Regex("[A-Za-z']{4,}").findAll(text.lowercase(Locale.ROOT)).map { it.value }.filter { it !in STOP }.forEach { freq[it] = (freq[it] ?: 0) + 1 }
        return freq.entries
            .sortedWith(compareByDescending<Map.Entry<String, Int>> { it.value }.thenByDescending { it.key.length }.thenBy { it.key })
            .take(n).map { it.key }
    }

    private fun asItems(body: String): List<String> {
        val lines = body.lines().map { it.trim() }.filter { it.isNotEmpty() }
        if (lines.size >= 2) return lines
        val one = lines.firstOrNull() ?: return emptyList()
        return one.split(Regex("[,;]\\s*|(?<=[.!?])\\s+")).map { it.trim().trimEnd('.') }.filter { it.isNotEmpty() }
    }

    private fun capSentences(s: String): String {
        val sb = StringBuilder()
        var up = true
        for (i in s.indices) {
            val ch = s[i]
            if (up && ch.isLetter()) { sb.append(ch.uppercaseChar()); up = false }
            else { sb.append(ch); if (ch.isLetterOrDigit()) up = false }
            if ((ch == '.' || ch == '!' || ch == '?') && (i + 1 >= s.length || s[i + 1] == ' ')) up = true
        }
        return sb.toString()
    }

    /** Fixes spacing, capital letters and end punctuation. List lines keep their bullet or checkbox. */
    fun tidy(body: String): String {
        val lines = body.lines().map { raw ->
            var s = raw.replace(Regex("[ \\t]+"), " ").trim()
            if (s.isEmpty()) return@map ""
            s = s.replace(Regex("\\s+([,.!?;:])"), "$1").replace(Regex("\\bi\\b"), "I")
            val marker = MARK.find(s)?.value ?: ""
            var text = capSentences(s.substring(marker.length))
            val words = text.split(' ').size
            val end = text.lastOrNull()
            if (marker.isEmpty() && words >= 5 && end != null && end !in ".!?:\u2026") text += "."
            marker + text
        }
        return lines.joinToString("\n").replace(Regex("\n{3,}"), "\n\n").trim()
    }

    fun toBullets(body: String): String = asItems(body).joinToString("\n") { BUL + " " + cap(it.replace(MARK, "")) }

    fun toChecklist(body: String): String = asItems(body).joinToString("\n") {
        if (it.startsWith(DONE)) it else TASK + " " + cap(it.replace(MARK, ""))
    }

    fun summary(body: String): String {
        val lines = body.lines().map { it.trim() }.filter { it.isNotEmpty() }
        val marked = lines.count { MARK.containsMatchIn(it) }
        if (lines.size >= 3 && marked * 2 >= lines.size) {
            val first = lines.filter { MARK.containsMatchIn(it) }.take(3).map { it.replace(MARK, "").trimEnd('.') }
            val tail = if (marked > 3) "\u2026" else ""
            return "$marked items: " + first.joinToString(", ") + tail
        }
        val text = body.replace(Regex("\\s+"), " ").trim()
        val sentence = text.split(Regex("(?<=[.!?])\\s+")).first()
        val w = sentence.split(" ")
        return if (w.size > 16) w.take(16).joinToString(" ") + "\u2026" else sentence
    }

    // ---- word + phrase prediction

    fun wordCompletions(text: String): List<String> {
        if (text.isEmpty() || !text.last().isLetter()) return emptyList()
        val partial = Regex("[A-Za-z']+\$").find(text)?.value ?: return emptyList()
        if (partial.length < 3) return emptyList()
        val p = partial.lowercase(Locale.ROOT)
        val mine = Regex("[A-Za-z']{5,}").findAll(text.dropLast(partial.length)).map { it.value.lowercase(Locale.ROOT) }.distinct().toList()
        val found = (mine + WORDS).filter { it.startsWith(p) && it.length > p.length }.distinct().take(3)
        val upper = partial[0].isUpperCase()
        return found.map { if (upper) cap(it) else it }
    }

    /** Replaces the half-typed last word with [word]. */
    fun completeWord(tf: TextFieldValue, word: String): TextFieldValue {
        val m = Regex("[A-Za-z']+\$").find(tf.text)
        val base = if (m != null) tf.text.substring(0, m.range.first) else tf.text
        val s = "$base$word "
        return TextFieldValue(s, TextRange(s.length))
    }

    private fun followUps(line: String): List<String> {
        val l = line.lowercase(Locale.ROOT).trimEnd()
        return when {
            Regex("(remember to|forget to|need to|have to|going to|want to|should|must)\$").containsMatchIn(l) -> listOf("call", "buy", "finish", "send", "book")
            Regex("\\b(buy|get|pick up)\$").containsMatchIn(l) -> listOf("milk", "eggs", "bread", "fruits")
            Regex("\\b(tomorrow|today|tonight|later|monday|tuesday|wednesday|thursday|friday|saturday|sunday)\$").containsMatchIn(l) -> listOf("at 9:00 AM", "morning", "afternoon", "evening")
            Regex("\\b(meeting|call|appointment|dinner|lunch|class)\$").containsMatchIn(l) -> listOf("at 10:00 AM", "with the team", "tomorrow")
            Regex("\\b(birthday|anniversary)\$").containsMatchIn(l) -> listOf("party", "gift ideas", "dinner plans")
            Regex("(i feel|feeling|i am|i'm|im)\$").containsMatchIn(l) -> listOf("grateful today", "a little tired", "really happy", "excited about")
            Regex("\\b(dear|hi|hello)\$").containsMatchIn(l) -> listOf("Mom,", "friend,", "everyone,")
            Regex("\\b(thank you|thanks)\$").containsMatchIn(l) -> listOf("so much", "for everything", "for your help")
            else -> emptyList()
        }
    }

    // ---- titles

    fun titleIdeas(title: String, body: String): List<String> {
        val out = LinkedHashSet<String>()
        val clean = body.trim()
        if (clean.isEmpty()) {
            out += cap(part()) + " thoughts"
            out += "To-do \u2013 " + dateShort()
            out += "Things to remember"
            out += "Quick note"
        } else {
            val firstLine = clean.lines().first { it.isNotBlank() }.trim().replace(MARK, "").trim()
            val words = firstLine.split(Regex("\\s+")).filter { it.isNotEmpty() }
            if (words.isNotEmpty()) out += cap(words.take(6).joinToString(" ").trimEnd('.', ',', ':', ';', '!', '?'))
            val keys = keywords(clean, 2)
            if (keys.size >= 2) out += keys.joinToString(" & ") { cap(it) }
            val label = when (topic("$title $clean")) {
                "shopping" -> "Shopping list"; "work" -> "Work notes"; "event" -> "Event plan"; "trip" -> "Trip plan"
                "recipe" -> "Recipe"; "idea" -> "Idea"; "journal" -> "Journal"; "study" -> "Study notes"; "todo" -> "To-do"
                else -> null
            }
            if (label != null) out += label
            out += SimpleDateFormat("EEEE", Locale.getDefault()).format(Date()) + " note"
        }
        return out.filter { it.isNotBlank() && !it.equals(title.trim(), true) }.take(4)
    }

    fun titleTips(title: String, body: String, mode: Int): List<AiTip> {
        val out = ArrayList<AiTip>()
        if (mode == 2) {
            if (title.isNotBlank()) wordCompletions(title).forEach { out += AiTip("\u270F", it, AiDo.WORD, it, "Keep writing") }
            smartCaptions("Everyday").forEach { if (!it.equals(title.trim(), true)) out += AiTip("\u2728", it, AiDo.TITLE, it, "Caption ideas") }
            return out
        }
        if (title.isNotBlank()) wordCompletions(title).forEach { out += AiTip("\u270F", it, AiDo.WORD, it, "Keep writing") }
        titleIdeas(title, body).forEach { out += AiTip("\uD83D\uDCA1", it, AiDo.TITLE, it, "Title ideas") }
        if (title.isNotBlank() && !title.contains("\u2013")) {
            val withDate = title.trim() + " \u2013 " + dateShort()
            out += AiTip("\uD83D\uDCC5", withDate, AiDo.TITLE, withDate, "Polish", "Adds today's date")
        }
        return out
    }

    // ---- templates

    private class Tpl(val emoji: String, val name: String, val title: String, val body: String, val hint: String)

    private fun templates(): List<Tpl> {
        val d = dateShort()
        val all = listOf(
            Tpl("\u2705", "To-do today", "To-do \u2013 $d", "$TASK Most important:\n$TASK Next up:\n$TASK If there's time:", "A short checklist for the day"),
            Tpl("\uD83D\uDED2", "Shopping list", "Shopping list", "$TASK Fruits & vegetables\n$TASK Milk & eggs\n$TASK Bread\n$TASK ", "A checklist you can tick off"),
            Tpl("\uD83D\uDCDD", "Meeting notes", "Meeting \u2013 $d", "Attendees:\n$BUL \n\nAgenda:\n$BUL \n\nAction items:\n$TASK ", "Attendees, agenda and action items"),
            Tpl("\uD83D\uDCD4", "Daily journal", "Journal \u2013 $d", "Today I felt:\n\nHighlight of the day:\n\nI'm grateful for:\n\nTomorrow I will:\n", "A calm end-of-day prompt"),
            Tpl("\uD83D\uDCA1", "Idea", "New idea", "The idea:\n\nWhy it matters:\n\nNext step:\n$TASK ", "Capture an idea and its next step"),
            Tpl("\u2708", "Trip plan", "Trip plan", "Where:\nWhen:\n\nPack:\n$TASK \n\nBook:\n$TASK ", "Plan, pack and book")
        )
        val first = when (part()) { "afternoon" -> "Meeting notes"; "evening", "night" -> "Daily journal"; else -> "To-do today" }
        return all.sortedBy { if (it.name == first) 0 else 1 }
    }

    // ---- body suggestions

    fun bodyTips(title: String, body: String): List<AiTip> {
        val out = ArrayList<AiTip>()
        if (body.isBlank()) {
            templates().forEach { out += AiTip(it.emoji, it.name, AiDo.APPEND, it.body, "Start with a template", it.hint, it.title) }
            return out
        }
        val fresh = body.endsWith("\n")
        val nl = if (fresh) "" else "\n"
        val sp = if (body.endsWith(" ") || fresh) "" else " "
        val gap = when { body.endsWith("\n\n") -> ""; fresh -> "\n"; else -> "\n\n" }
        val last = body.lines().lastOrNull { it.isNotBlank() }?.trim() ?: ""
        val topic = topic("$title $body")

        // 1. finish the word you are typing
        wordCompletions(body).forEach { out += AiTip("\u270F", it, AiDo.WORD, it, "Keep writing") }

        // 2. continue the list or sentence
        val usesTasks = body.lines().any { it.trim().startsWith(TASK) || it.trim().startsWith(DONE) }
        val marker = if (usesTasks) TASK else BUL
        val taskLine = last.startsWith(TASK) || last.startsWith(DONE)
        val bulletLine = last.startsWith(BUL) || last.startsWith("- ") || last.startsWith("* ")
        val emptyItem = last == BUL || last == TASK || last == DONE || last == "-" || last == "*"
        val listy = taskLine || bulletLine
        fun itemText(item: String) = if (emptyItem) (if (body.endsWith(" ")) "" else " ") + item else nl + marker + " " + item

        if (!emptyItem) {
            when {
                taskLine -> out += AiTip(TASK, "Next task", AiDo.APPEND, nl + TASK + " ", "Keep writing")
                bulletLine -> out += AiTip(BUL, "Next bullet", AiDo.APPEND, nl + BUL + " ", "Keep writing")
                last.endsWith(":") -> out += AiTip(BUL, "Start a list", AiDo.APPEND, nl + BUL + " ", "Keep writing")
            }
        }
        if (listy || last.endsWith(":")) {
            val pool = when (topic) {
                "shopping" -> listOf("Milk", "Eggs", "Bread", "Rice", "Fruits", "Vegetables", "Coffee", "Water")
                "todo", "work" -> listOf("Follow up", "Review and finalize", "Send update", "Schedule next step")
                "trip" -> listOf("Passport / ID", "Phone charger", "Tickets", "Toiletries", "Book hotel")
                "study" -> listOf("Review notes", "Practice problems", "Make flashcards")
                "event" -> listOf("Guest list", "Food and drinks", "Venue", "Gift")
                else -> emptyList()
            }
            val low = body.lowercase(Locale.ROOT)
            pool.filter { !low.contains(it.lowercase(Locale.ROOT)) }.take(3)
                .forEach { out += AiTip(emojiFor(topic), it, AiDo.APPEND, itemText(it), "Ideas for this list") }
        }
        if (!fresh) followUps(last).take(3).forEach { out += AiTip("\u2728", it, AiDo.APPEND, sp + it, "Keep writing") }

        // 3. improve what is written
        val trimmed = body.trim()
        val tidied = tidy(body)
        if (tidied != trimmed) out += AiTip("\u2728", "Tidy up", AiDo.REPLACE, tidied, "Improve this note", "Fix spacing, capitals and punctuation")
        val items = asItems(body)
        val noHeadings = items.none { it.endsWith(":") }
        if (items.size >= 2 && noHeadings && items.count { !MARK.containsMatchIn(it) } * 2 >= items.size) {
            out += AiTip(BUL, "Make a bullet list", AiDo.REPLACE, toBullets(body), "Improve this note", "One bullet for each line")
        }
        if (items.size >= 2 && noHeadings && items.any { !it.startsWith(TASK) && !it.startsWith(DONE) }) {
            out += AiTip("\u2705", "Make a checklist", AiDo.REPLACE, toChecklist(body), "Improve this note", "Tick items off as you go")
        }
        val words = trimmed.split(Regex("\\s+")).count { it.isNotEmpty() }
        if ((words >= 18 || items.size >= 4) && !body.contains("Summary:")) {
            val s = summary(body)
            out += AiTip("\uD83D\uDCDD", "Summarize", AiDo.APPEND, gap + "\u2728 Summary: " + s, "Improve this note", s)
        }
        val keys = keywords(body, 3)
        if (keys.isNotEmpty() && words >= 6 && !body.contains("#")) {
            val tags = keys.joinToString(" ") { "#$it" }
            out += AiTip("\uD83C\uDFF7", "Add tags", AiDo.APPEND, gap + tags, "Improve this note", tags)
        }

        // 4. title + templates
        if (title.isBlank()) titleIdeas(title, body).take(2).forEach { out += AiTip("\uD83D\uDCA1", it, AiDo.TITLE, it, "Title ideas") }
        templates().take(4).forEach { out += AiTip(it.emoji, it.name, AiDo.APPEND, gap + it.body, "Add a template", it.hint, it.title) }
        return out
    }
}

// ---------------------------------------------------------------- UI: strip, popup and the small AI button

private val AiViolet = Color(0xFF8B5CF6)
private val AiCyan = Color(0xFF22D3EE)

/** The small animated AI icon that sits on each text box. Tap it to pop up the suggestions. */
@Composable
fun AiButton(active: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.size(34.dp).clip(CircleShape)
            .background(if (active) AiViolet.copy(alpha = 0.22f) else Color.Transparent)
            .border(1.dp, if (active) AiViolet.copy(alpha = 0.7f) else Color.Transparent, CircleShape)
            .clickable(onClickLabel = "AI suggestions", role = Role.Button, onClick = onClick),
        Alignment.Center
    ) { AiIcon(26.dp) }
}

@Composable
private fun AiTipChip(tip: AiTip, ink: Color, onClick: () -> Unit) {
    val shape = RoundedCornerShape(50)
    Box(
        Modifier.clip(shape)
            .background(Brush.horizontalGradient(listOf(AiViolet.copy(alpha = 0.20f), AiCyan.copy(alpha = 0.20f))))
            .border(1.dp, AiViolet.copy(alpha = 0.45f), shape)
            .clickable(onClick = onClick).padding(horizontal = 12.dp, vertical = 7.dp)
    ) {
        Text(
            tip.emoji + " " + tip.label, Modifier.widthIn(max = 230.dp), color = ink, fontSize = 12.sp,
            fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
private fun AiStrip(tips: List<AiTip>, ink: Color, tone: Color, onPick: (AiTip) -> Unit, onUndo: (() -> Unit)?, onMore: () -> Unit) {
    Column(Modifier.fillMaxWidth().padding(top = 10.dp)) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("\u2728 AI SUGGESTS", color = tone, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
            Spacer(Modifier.weight(1f))
            if (onUndo != null) {
                Text(
                    "Undo", Modifier.clip(RoundedCornerShape(8.dp)).clickable(onClick = onUndo).padding(horizontal = 8.dp, vertical = 2.dp),
                    color = ink.copy(alpha = 0.7f), fontSize = 12.sp, fontWeight = FontWeight.SemiBold
                )
            }
            Text(
                "More", Modifier.clip(RoundedCornerShape(8.dp)).clickable(onClick = onMore).padding(horizontal = 8.dp, vertical = 2.dp),
                color = tone, fontSize = 12.sp, fontWeight = FontWeight.SemiBold
            )
        }
        Spacer(Modifier.height(6.dp))
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            tips.take(6).forEach { t -> AiTipChip(t, ink) { onPick(t) } }
        }
    }
}

@Composable
private fun AiTipRow(t: AiTip, ink: Color, tone: Color, onPick: (AiTip) -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).clickable { onPick(t) }.padding(horizontal = 10.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(30.dp).clip(CircleShape).background(AiViolet.copy(alpha = 0.16f)), Alignment.Center) { Text(t.emoji, fontSize = 15.sp) }
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(t.label, color = ink, fontSize = 14.sp, fontWeight = FontWeight.Medium, maxLines = 2, overflow = TextOverflow.Ellipsis)
            if (t.hint.isNotEmpty()) Text(t.hint, color = ink.copy(alpha = 0.55f), fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Spacer(Modifier.width(8.dp))
        Text("Apply", color = tone, fontSize = 12.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun AiPanel(tips: List<AiTip>, ink: Color, dark: Boolean, tone: Color, onPick: (AiTip) -> Unit, onUndo: (() -> Unit)?, onClose: () -> Unit) {
    val shape = RoundedCornerShape(22.dp)
    Column(
        Modifier.fillMaxWidth().padding(top = 10.dp).clip(shape)
            .background(Brush.linearGradient(listOf(AiViolet.copy(alpha = if (dark) 0.20f else 0.10f), AiCyan.copy(alpha = if (dark) 0.14f else 0.10f))))
            .border(1.dp, AiViolet.copy(alpha = 0.45f), shape)
    ) {
        Row(Modifier.fillMaxWidth().padding(start = 14.dp, end = 4.dp, top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            AiIcon(24.dp)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text("AI suggestions", color = ink, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                Text("Smart help that runs on your phone", color = ink.copy(alpha = 0.55f), fontSize = 11.sp)
            }
            if (onUndo != null) {
                Text(
                    "Undo", Modifier.clip(RoundedCornerShape(8.dp)).clickable(onClick = onUndo).padding(horizontal = 8.dp, vertical = 4.dp),
                    color = ink.copy(alpha = 0.7f), fontSize = 12.sp, fontWeight = FontWeight.SemiBold
                )
            }
            IconButton(onClick = onClose) { Icon(Icons.Filled.Close, "Close", tint = ink.copy(alpha = 0.6f), modifier = Modifier.size(20.dp)) }
        }
        Column(Modifier.fillMaxWidth().heightIn(max = 300.dp).verticalScroll(rememberScrollState()).padding(horizontal = 6.dp, vertical = 6.dp)) {
            if (tips.isEmpty()) {
                Text(
                    "Start typing and I'll suggest the next words, a title and quick fixes.",
                    Modifier.padding(10.dp), color = ink.copy(alpha = 0.7f), fontSize = 13.sp
                )
            }
            tips.groupBy { it.group }.forEach { (group, list) ->
                Text(
                    group.uppercase(Locale.getDefault()), Modifier.padding(start = 10.dp, top = 8.dp, bottom = 2.dp),
                    color = tone, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp
                )
                list.forEach { t -> AiTipRow(t, ink, tone, onPick) }
            }
        }
    }
}

/**
 * Sits under a text box. [show] = the box was tapped, so a strip of quick suggestions slides in.
 * [panel] = the small AI icon was tapped, so the full suggestion popup springs open instead.
 */
@Composable
fun AiAssist(
    show: Boolean, panel: Boolean, tips: List<AiTip>, ink: Color, dark: Boolean,
    onPick: (AiTip) -> Unit, onUndo: (() -> Unit)?, onMore: () -> Unit, onClose: () -> Unit
) {
    val tone = if (dark) Color(0xFFB9A2FF) else Color(0xFF6D3FE0)
    val bring = remember { BringIntoViewRequester() }
    LaunchedEffect(panel) {
        if (panel) { delay(280); try { bring.bringIntoView() } catch (_: Exception) { } }
    }
    Column(Modifier.fillMaxWidth().bringIntoViewRequester(bring)) {
        AnimatedVisibility(
            visible = show && !panel && tips.isNotEmpty(),
            enter = fadeIn(tween(180)) + expandVertically(tween(220), Alignment.Top),
            exit = fadeOut(tween(120)) + shrinkVertically(tween(160), Alignment.Top)
        ) { AiStrip(tips, ink, tone, onPick, onUndo, onMore) }
        AnimatedVisibility(
            visible = panel,
            enter = fadeIn(tween(160)) + scaleIn(tween(200), 0.9f, TransformOrigin(1f, 0f)) + expandVertically(tween(220), Alignment.Top),
            exit = fadeOut(tween(120)) + scaleOut(tween(140), 0.9f, TransformOrigin(1f, 0f)) + shrinkVertically(tween(160), Alignment.Top)
        ) { AiPanel(tips, ink, dark, tone, onPick, onUndo, onClose) }
    }
}
