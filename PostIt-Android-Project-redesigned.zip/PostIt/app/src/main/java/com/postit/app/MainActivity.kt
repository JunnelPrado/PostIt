@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)

package com.postit.app

import android.app.Activity
import android.content.Context
import android.os.Build
import android.content.SharedPreferences
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts.PickVisualMedia
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.DateFormat
import java.util.Date
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.lazy.staggeredgrid.LazyVerticalStaggeredGrid
import androidx.compose.foundation.lazy.staggeredgrid.StaggeredGridCells
import androidx.compose.foundation.lazy.staggeredgrid.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.material.icons.filled.Close
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.border
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.StartOffset
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.tween
import androidx.compose.ui.composed
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.filled.Edit
import androidx.compose.ui.unit.Dp
import androidx.compose.animation.core.LinearEasing
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.ui.viewinterop.AndroidView
import android.widget.ImageView
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.staggeredgrid.StaggeredGridItemSpan
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Search
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import java.util.TimeZone
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ColorMatrix as AColorMatrix
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.rotate
import kotlin.math.hypot
import androidx.compose.material.icons.filled.ArrowForward

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { PostItApp() }
    }
}

data class Memory(val file: String, val caption: String, val time: Long, val pinned: Boolean = false, val body: String = "", val note: Boolean = false)

fun load(p: SharedPreferences): List<Memory> {
    val a = JSONArray(p.getString("memories", "[]"))
    return (0 until a.length()).map { val o = a.getJSONObject(it); Memory(o.getString("f"), o.getString("c"), o.getLong("t"), o.optBoolean("p", false), o.optString("b", ""), o.optBoolean("n", false)) }
}

fun save(p: SharedPreferences, l: List<Memory>) {
    val a = JSONArray(l.map { JSONObject().put("f", it.file).put("c", it.caption).put("t", it.time).put("p", it.pinned).put("b", it.body).put("n", it.note) })
    p.edit().putString("memories", a.toString()).apply()
}

val FLOAT_STYLES = listOf("off" to "Off", "bob" to "Float", "sway" to "Sway", "drift" to "Drift", "pulse" to "Pulse")

/** Makes a picture gently float. Each picture starts at a different phase so the page feels alive. */
fun Modifier.floating(style: String, index: Int): Modifier = if (style == "off") this else composed {
    val tr = rememberInfiniteTransition(label = "float")
    val v by tr.animateFloat(
        -1f, 1f,
        infiniteRepeatable(tween(2600, easing = FastOutSlowInEasing), RepeatMode.Reverse, StartOffset((index * 370) % 2600)),
        label = "v"
    )
    graphicsLayer {
        when (style) {
            "bob" -> translationY = v * 6f * density
            "sway" -> { rotationZ = v * 2.5f; translationY = v * 2f * density }
            "drift" -> { translationX = v * 5f * density; translationY = (v * v - 0.5f) * 8f * density }
            "pulse" -> { scaleX = 1f + v * 0.03f; scaleY = 1f + v * 0.03f }
        }
    }
}


@Composable
fun SwitchRow(title: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(title, Modifier.weight(1f)); Switch(checked, onChange)
    }
}


val Accent = Color(0xFFF4B400)
private val DarkScheme = darkColorScheme(
    primary = Accent, onPrimary = Color.Black, background = Color.Black, surface = Color(0xFF121212),
    surfaceVariant = Color(0xFF232325), secondaryContainer = Color(0xFF4A3B00), onSecondaryContainer = Accent
)
private val LightScheme = lightColorScheme(primary = Color(0xFFC79100), onPrimary = Color.White, secondaryContainer = Color(0xFFFFE9A8))

/** One row of the "All memories" screen. */
sealed class Entry {
    object Title : Entry()
    object Empty : Entry()
    class Header(val text: String) : Entry()
    class Item(val m: Memory) : Entry()
}

class Pal(val bg: Color, val main: Color, val sub: Color, val glass: Boolean)

private fun startOfDay(daysAgo: Int): Long {
    val c = Calendar.getInstance()
    c.set(Calendar.HOUR_OF_DAY, 0); c.set(Calendar.MINUTE, 0); c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0)
    c.add(Calendar.DAY_OF_YEAR, -daysAgo)
    return c.timeInMillis
}

/** Section title: Today / Last 7 days / October / September 2024 ... */
fun bucketOf(t: Long): String {
    if (t >= startOfDay(0)) return "Today"
    if (t >= startOfDay(7)) return "Last 7 days"
    val c = Calendar.getInstance(); val y = c.get(Calendar.YEAR); c.timeInMillis = t
    return SimpleDateFormat(if (c.get(Calendar.YEAR) == y) "MMMM" else "MMMM yyyy", Locale.getDefault()).format(Date(t))
}

/** Right-hand date on a card: Just now / 4:26 PM / Yesterday / October 14. */
fun dateLabel(t: Long): String {
    val f = { p: String -> SimpleDateFormat(p, Locale.getDefault()).format(Date(t)) }
    return when {
        System.currentTimeMillis() - t < 60_000 -> "Just now"
        t >= startOfDay(0) -> f("h:mm a")
        t >= startOfDay(1) -> "Yesterday"
        t >= startOfDay(0).let { Calendar.getInstance().apply { timeInMillis = it; set(Calendar.DAY_OF_YEAR, 1) }.timeInMillis } -> f("MMMM d")
        else -> f("MMM d, yyyy")
    }
}

/** Date and time a note was posted: "Nov 19, 2026 · 2:05 PM" (grid cards drop the year: "Nov 19 · 2:05 PM"). */
fun postedLabel(t: Long, compact: Boolean): String =
    SimpleDateFormat(if (compact) "MMM d \u00B7 h:mm a" else "MMM d, yyyy \u00B7 h:mm a", Locale.getDefault()).format(Date(t))

/** Icon, colours and label of a sidebar filter. The drawer rows and the main heading both read from here so they always match. */
class FilterLook(val emoji: String, val label: String, val c1: Color, val c2: Color)

fun filterLook(f: String): FilterLook = when (f) {
    "pinned" -> FilterLook("\uD83D\uDCCC", "Pinned", Color(0xFFFF5252), Color(0xFFFF9100))
    "notes" -> FilterLook("\uD83D\uDCDD", "Text notes", Color(0xFF00C853), Color(0xFF00BFA5))
    "images" -> FilterLook("\uD83D\uDDBC\uFE0F", "Images", Color(0xFFFF4081), Color(0xFFFF80AB))
    else -> FilterLook("\uD83D\uDDC2\uFE0F", "All memories", Color(0xFF7C4DFF), Color(0xFF448AFF))
}

@Composable
fun FolderIcon(color: Color, size: Dp = 20.dp) = Canvas(Modifier.size(size)) {
    drawRoundRect(color, Offset(0f, this.size.height * 0.08f), Size(this.size.width * 0.5f, this.size.height * 0.3f), CornerRadius(this.size.width * 0.1f))
    drawRoundRect(color, Offset(0f, this.size.height * 0.24f), Size(this.size.width, this.size.height * 0.68f), CornerRadius(this.size.width * 0.14f))
}

@Composable
fun GridIcon(color: Color, size: Dp = 24.dp) = Canvas(Modifier.size(size)) {
    val s = this.size.width * 0.38f; val o = this.size.width * 0.62f
    for (x in listOf(0.06f * this.size.width, o - 0.06f * this.size.width)) for (y in listOf(0.06f * this.size.width, o - 0.06f * this.size.width))
        drawRoundRect(color, Offset(x, y), Size(s, s), CornerRadius(s * 0.28f), style = Stroke(2.2.dp.toPx()))
}

@Composable
fun ListIcon(color: Color, size: Dp = 24.dp) = Canvas(Modifier.size(size)) {
    for (i in 0..2) drawRoundRect(color, Offset(this.size.width * 0.08f, this.size.height * (0.16f + i * 0.3f)), Size(this.size.width * 0.84f, this.size.height * 0.14f), CornerRadius(this.size.height * 0.07f))
}

@Composable
fun PictureIcon(color: Color, size: Dp = 24.dp) = Canvas(Modifier.size(size)) {
    val w = this.size.width; val st = Stroke(2.2.dp.toPx())
    drawRoundRect(color, Offset(w * 0.06f, w * 0.12f), Size(w * 0.88f, w * 0.76f), CornerRadius(w * 0.16f), style = st)
    drawCircle(color, w * 0.08f, Offset(w * 0.34f, w * 0.38f))
    drawPath(Path().apply { moveTo(w * 0.1f, w * 0.8f); lineTo(w * 0.42f, w * 0.52f); lineTo(w * 0.62f, w * 0.7f); lineTo(w * 0.76f, w * 0.58f); lineTo(w * 0.9f, w * 0.76f) }, color, style = st)
}

/** Floating pill: layout toggle, big "+" (new note) and add-picture. */
@Composable
fun BottomPill(grid: Boolean, onLayout: () -> Unit, onNew: () -> Unit, onCalendar: () -> Unit, onPicture: () -> Unit, modifier: Modifier = Modifier) {
    Row(
        modifier.height(56.dp).clip(RoundedCornerShape(50)).background(Color(0xFF3A3A3C)).padding(horizontal = 12.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Box(Modifier.size(44.dp).clip(CircleShape).clickable(onClick = onLayout), Alignment.Center) { if (grid) ListIcon(Accent) else GridIcon(Accent) }
        Box(Modifier.size(48.dp).clip(CircleShape).background(Accent).clickable(onClick = onNew), Alignment.Center) { Icon(Icons.Filled.Add, "New note", tint = Color.White, modifier = Modifier.size(30.dp)) }
        Box(Modifier.size(44.dp).clip(CircleShape).clickable(onClick = onCalendar), Alignment.Center) { CalendarIcon(Accent) }
        Box(Modifier.size(44.dp).clip(CircleShape).clickable(onClick = onPicture), Alignment.Center) { PictureIcon(Accent) }
    }
}

/** Notes-app card: title, preview, optional thumbnail, folder + date. Long-press for Pin / Delete. */
@Composable
fun NoteCard(m: Memory, compact: Boolean, index: Int, floatStyle: String, pal: Pal, onOpen: () -> Unit, onPin: () -> Unit, onDelete: () -> Unit) {
    val ctx = LocalContext.current
    val shape = RoundedCornerShape(20.dp)
    var menu by remember { mutableStateOf(false) }
    val title = if (m.note) m.caption else m.caption.ifEmpty { "Image note" }
    val preview = if (m.note) m.body else "1 image"
    val photo = File(ctx.filesDir, m.file)
    Box(Modifier.fillMaxWidth().floating(floatStyle, index)) {
        Column(
            Modifier.fillMaxWidth().clip(shape).background(pal.bg)
                .then(if (pal.glass) Modifier.border(1.dp, Color.White.copy(alpha = 0.25f), shape) else Modifier)
                .combinedClickable(onClick = onOpen, onLongClick = { menu = true }).padding(16.dp)
        ) {
            if (compact && !m.note) {
                AsyncImage(photo, m.caption, Modifier.fillMaxWidth().aspectRatio(1.2f).clip(RoundedCornerShape(14.dp)), contentScale = ContentScale.Crop)
                Spacer(Modifier.height(10.dp))
            }
            Row(verticalAlignment = Alignment.Top) {
                Column(Modifier.weight(1f)) {
                    if (title.isNotEmpty()) Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(title, Modifier.weight(1f, fill = false), color = pal.main, fontSize = 20.sp, fontWeight = FontWeight.Medium, maxLines = if (compact) 2 else 1, overflow = TextOverflow.Ellipsis)
                        if (m.pinned) Text("\uD83D\uDCCC", Modifier.padding(start = 6.dp), fontSize = 14.sp)
                    }
                    if (preview.isNotEmpty()) Text(preview, Modifier.padding(top = 4.dp), color = pal.sub, fontSize = 16.sp, lineHeight = 22.sp, maxLines = if (compact) 4 else 2, overflow = TextOverflow.Ellipsis)
                }
                if (!compact && !m.note) {
                    Spacer(Modifier.width(12.dp))
                    AsyncImage(photo, m.caption, Modifier.size(64.dp).clip(RoundedCornerShape(14.dp)), contentScale = ContentScale.Crop)
                }
            }
            Spacer(Modifier.height(14.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                CalendarIcon(Accent, 18.dp)
                Spacer(Modifier.width(if (compact) 6.dp else 8.dp))
                Text(postedLabel(m.time, compact), Modifier.weight(1f), color = pal.sub, fontSize = if (compact) 12.sp else 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
        DropdownMenu(menu, { menu = false }) {
            DropdownMenuItem({ Text(if (m.pinned) "Unpin" else "Pin to top") }, { menu = false; onPin() })
            DropdownMenuItem({ Text("Delete") }, { menu = false; onDelete() })
        }
    }
}

@Composable
fun EntryContent(
    e: Entry, index: Int, compact: Boolean, pal: Pal, filter: String, heading: String, count: String, floatStyle: String,
    onOpen: (Memory) -> Unit, onPin: (Memory) -> Unit, onDelete: (Memory) -> Unit
) {
    when (e) {
        is Entry.Title -> Row(Modifier.padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            val look = filterLook(filter)
            Box(Modifier.size(52.dp).clip(RoundedCornerShape(16.dp)).background(Brush.linearGradient(listOf(look.c1, look.c2))), Alignment.Center) { Text(look.emoji, fontSize = 26.sp) }
            Spacer(Modifier.width(14.dp))
            Column {
                Text(heading, color = pal.main, fontSize = 30.sp, fontWeight = FontWeight.SemiBold)
                Text(count, color = pal.sub, fontSize = 16.sp, modifier = Modifier.padding(top = 2.dp))
            }
        }
        is Entry.Header -> Text(e.text, Modifier.padding(start = 12.dp, top = 22.dp, bottom = 2.dp), color = pal.sub, fontSize = 18.sp)
        is Entry.Empty -> Text("No notes here yet.\nTap + to write a note or the picture icon to add a photo.", Modifier.fillMaxWidth().padding(top = 60.dp), color = pal.sub, textAlign = TextAlign.Center)
        is Entry.Item -> NoteCard(e.m, compact, index, floatStyle, pal, { onOpen(e.m) }, { onPin(e.m) }, { onDelete(e.m) })
    }
}


@Composable
fun PostItApp() {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("postit", Context.MODE_PRIVATE) }
    var dark by remember { mutableStateOf(prefs.getBoolean("dark", true)) }
    var cols by remember { mutableIntStateOf(prefs.getInt("gridCols", 2)) }
    var newest by remember { mutableStateOf(prefs.getBoolean("newest", true)) }
    var memories by remember { mutableStateOf(load(prefs)) }
    var settings by remember { mutableStateOf(false) }
    var pending by remember { mutableStateOf<Uri?>(null) }
    var caption by remember { mutableStateOf("") }
    var confirmClear by remember { mutableStateOf(false) }
    var viewing by remember { mutableStateOf<Memory?>(null) }
    var noteOpen by remember { mutableStateOf(false) }
    var noteEditing by remember { mutableStateOf<Memory?>(null) }
    var noteTitle by remember { mutableStateOf("") }
    var noteBody by remember { mutableStateOf("") }
    fun editNote(m: Memory?) { noteEditing = m; noteTitle = m?.caption ?: ""; noteBody = m?.body ?: ""; noteOpen = true }
    var layout by remember { mutableStateOf(prefs.getString("layout", "list") ?: "list") }
    var filter by remember { mutableStateOf("all") }
    var searching by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    var moreOpen by remember { mutableStateOf(false) }
    var calOpen by remember { mutableStateOf(false) }
    var editorOpen by remember { mutableStateOf(false) }
    var annivs by remember { mutableStateOf(loadAnn(prefs)) }
    var floatStyle by remember { mutableStateOf(prefs.getString("floatStyle", "off") ?: "off") }

    var bgKind by remember { mutableStateOf(prefs.getString("bgKind", "none") ?: "none") }
    var bgPhoto by remember { mutableStateOf(prefs.getString("bgPhoto", "") ?: "") }
    var bgAnimated by remember { mutableStateOf(prefs.getBoolean("bgAnimated", true)) }
    var bgSparkles by remember { mutableStateOf(prefs.getBoolean("bgSparkles", true)) }
    var bgDim by remember { mutableFloatStateOf(prefs.getFloat("bgDim", 0.25f)) }
    var bgBlur by remember { mutableFloatStateOf(prefs.getFloat("bgBlur", 0f)) }

    val picker = rememberLauncherForActivityResult(PickVisualMedia()) { uri -> pending = uri; caption = "" }
    val bgPicker = rememberLauncherForActivityResult(PickVisualMedia()) { uri ->
        if (uri != null) {
            val name = "bg_${System.currentTimeMillis()}"
            ctx.contentResolver.openInputStream(uri)?.use { i -> File(ctx.filesDir, name).outputStream().use { o -> i.copyTo(o) } }
            if (bgPhoto.isNotEmpty()) File(ctx.filesDir, bgPhoto).delete()
            bgPhoto = name; bgKind = "custom"
            prefs.edit().putString("bgPhoto", name).putString("bgKind", "custom").apply()
        }
    }
    fun commit(l: List<Memory>) { memories = l; save(prefs, l) }
    BackHandler(settings) { settings = false }
    BackHandler(calOpen) { calOpen = false }
    BackHandler(editorOpen) { editorOpen = false }

    // Keep status/navigation bar icons readable on top of the background.
    val view = LocalView.current
    val lightBars = !editorOpen && !dark && !(bgKind != "none" && !settings && !calOpen)
    SideEffect {
        val win = (view.context as Activity).window
        val c = WindowCompat.getInsetsController(win, view)
        c.isAppearanceLightStatusBars = lightBars
        c.isAppearanceLightNavigationBars = lightBars
    }

    MaterialTheme(colorScheme = if (dark) DarkScheme else LightScheme) {
        if (editorOpen) {
            PhotoEditor({ editorOpen = false }, { name -> commit(memories + Memory(name, "Edited photo", System.currentTimeMillis())) })
        } else if (calOpen) {
            AnniversaryScreen(annivs, { annivs = it; saveAnn(prefs, it) }, { calOpen = false })
        } else if (settings) {
            Scaffold(topBar = {
                TopAppBar(title = { Text("Settings") }, navigationIcon = {
                    IconButton({ settings = false }) { Icon(Icons.Filled.ArrowBack, "Back") }
                })
            }) { pad ->
                Column(Modifier.padding(pad).padding(16.dp).verticalScroll(rememberScrollState())) {
                    Box(
                        Modifier.fillMaxWidth().padding(bottom = 12.dp).clip(RoundedCornerShape(20.dp))
                            .background(Brush.linearGradient(listOf(Color(0xFF6C3BFF), Color(0xFFFF4D8D), Color(0xFFFF9E40))))
                            .clickable { editorOpen = true }.padding(18.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("\uD83C\uDFA8", fontSize = 34.sp)
                            Spacer(Modifier.width(14.dp))
                            Column(Modifier.weight(1f)) {
                                Text("Photo Studio", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                                Text("Filters, adjustments, crop & rotate", color = Color.White.copy(alpha = 0.85f), fontSize = 13.sp)
                            }
                            Text("\u203A", color = Color.White, fontSize = 30.sp)
                        }
                    }
                    SwitchRow("Dark mode", dark) { dark = it; prefs.edit().putBoolean("dark", it).apply() }
                    SwitchRow("Newest memories first", newest) { newest = it; prefs.edit().putBoolean("newest", it).apply() }
                    Text("Columns in grid view", Modifier.padding(top = 8.dp))
                    Row(Modifier.padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        for (n in 2..4) FilterChip(selected = cols == n, onClick = { cols = n; prefs.edit().putInt("gridCols", n).apply() }, label = { Text("$n") })
                    }
                    Text("Notes layout", Modifier.padding(top = 8.dp))
                    Row(Modifier.padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        for ((k, label) in listOf("list" to "List", "grid" to "Grid")) {
                            FilterChip(selected = layout == k, onClick = { layout = k; prefs.edit().putString("layout", k).apply() }, label = { Text(label) })
                        }
                    }
                    Text("Floating pictures", Modifier.padding(top = 8.dp))
                    Text("Make the pictures on your homepage float in a style you like.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Row(Modifier.padding(vertical = 8.dp).horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        for ((k, label) in FLOAT_STYLES) {
                            FilterChip(selected = floatStyle == k, onClick = { floatStyle = k; prefs.edit().putString("floatStyle", k).apply() }, label = { Text(label) })
                        }
                    }
                    Text("Homepage background", Modifier.padding(top = 16.dp), style = MaterialTheme.typography.titleMedium)
                    Text("Pick a live background for your homepage.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Row(Modifier.padding(vertical = 12.dp).horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        val photoFile = if (bgPhoto.isNotEmpty()) File(ctx.filesDir, bgPhoto) else null
                        val options = listOf("none" to "Off") + THEMES.map { it.key to it.label } + listOf("custom" to "Photo")
                        for ((k, label) in options) {
                            BgSwatch(k, label, bgKind == k, photoFile, dark) {
                                if (k == "custom" && photoFile == null) bgPicker.launch(PickVisualMediaRequest(PickVisualMedia.ImageOnly))
                                else { bgKind = k; prefs.edit().putString("bgKind", k).apply() }
                            }
                        }
                    }
                    if (bgKind == "custom") {
                        OutlinedButton({ bgPicker.launch(PickVisualMediaRequest(PickVisualMedia.ImageOnly)) }) { Text("Choose a different photo") }
                        Text("Photo dimming: ${(bgDim * 100).toInt()}%", Modifier.padding(top = 8.dp))
                        Slider(bgDim, { bgDim = it }, valueRange = 0f..0.8f, onValueChangeFinished = { prefs.edit().putFloat("bgDim", bgDim).apply() })
                        if (Build.VERSION.SDK_INT >= 31) {
                            Text("Photo blur: ${bgBlur.toInt()}")
                            Slider(bgBlur, { bgBlur = it }, valueRange = 0f..25f, onValueChangeFinished = { prefs.edit().putFloat("bgBlur", bgBlur).apply() })
                        }
                    } else if (bgKind != "none") {
                        SwitchRow("Animate background", bgAnimated) { bgAnimated = it; prefs.edit().putBoolean("bgAnimated", it).apply() }
                        SwitchRow("Floating sparkles", bgSparkles) { bgSparkles = it; prefs.edit().putBoolean("bgSparkles", it).apply() }
                    }
                    Spacer(Modifier.height(16.dp))
                    Button({ confirmClear = true }, colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)) {
                        Text("Delete all memories (${memories.size})")
                    }
                    Text("Developed by Junnel Entoma", Modifier.fillMaxWidth().padding(top = 24.dp), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center)
                }
            }

        } else {
            val themed = bgKind != "none"
            val light = !dark && !themed
            val main = if (light) Color(0xFF121212) else Color.White
            val pal = Pal(when { themed -> Color.Black.copy(alpha = 0.4f); dark -> Color(0xFF232325); else -> Color(0xFFF0F0F3) }, main, main.copy(alpha = 0.62f), themed)
            val drawerState = rememberDrawerState(DrawerValue.Closed)
            val scope = rememberCoroutineScope()
            val focus = remember { FocusRequester() }
            LaunchedEffect(searching) { if (searching) focus.requestFocus() }
            BackHandler(searching) { searching = false; query = "" }

            val q = query.trim().lowercase()
            val sorted = (if (newest) memories.sortedByDescending { it.time } else memories.sortedBy { it.time }).filter { m ->
                (when (filter) { "pinned" -> m.pinned; "notes" -> m.note; "images" -> !m.note; else -> true }) &&
                    (q.isEmpty() || m.caption.lowercase().contains(q) || m.body.lowercase().contains(q))
            }
            val entries = buildList<Entry> {
                add(Entry.Title)
                if (sorted.isEmpty()) add(Entry.Empty)
                val top = if (filter == "pinned") emptyList() else sorted.filter { it.pinned }
                if (top.isNotEmpty()) { add(Entry.Header("Pinned")); top.forEach { add(Entry.Item(it)) } }
                var last = ""
                sorted.filter { it !in top }.forEach { m ->
                    val b = bucketOf(m.time)
                    if (b != last) { add(Entry.Header(b)); last = b }
                    add(Entry.Item(m))
                }
            }
            val heading = filterLook(filter).label
            val count = "${sorted.size} ${if (sorted.size == 1) "note" else "notes"}"
            val open: (Memory) -> Unit = { if (it.note) editNote(it) else viewing = it }
            val del: (Memory) -> Unit = { File(ctx.filesDir, it.file).delete(); commit(memories - it) }
            val pin: (Memory) -> Unit = { m -> commit(memories.map { if (it.file == m.file) it.copy(pinned = !it.pinned) else it }) }
            val keyOf: (Entry) -> Any = { e -> when (e) { is Entry.Title -> "title"; is Entry.Empty -> "empty"; is Entry.Header -> "h_${e.text}"; is Entry.Item -> e.m.file } }
            val pad = PaddingValues(start = 12.dp, end = 12.dp, bottom = 130.dp)

            ModalNavigationDrawer(drawerState = drawerState, drawerContent = {
                ModalDrawerSheet {
                    Column(Modifier.verticalScroll(rememberScrollState())) {
                        Box(Modifier.fillMaxWidth().background(Brush.linearGradient(listOf(Color(0xFF2A1B6B), Color(0xFF0F6E7A), Color(0xFFD9552B)))).statusBarsPadding().padding(22.dp)) {
                            Column {
                                Box(Modifier.size(56.dp).graphicsLayer { rotationZ = -8f }.clip(RoundedCornerShape(16.dp)).background(Brush.linearGradient(listOf(Color(0xFFFFEB3B), Color(0xFFFFB300)))), Alignment.Center) { Text("\uD83D\uDCCC", fontSize = 28.sp) }
                                Spacer(Modifier.height(14.dp))
                                Text("PostIt", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Black)
                                Text("Your memories, pinned", color = Color.White.copy(alpha = 0.8f), fontSize = 13.sp)
                                Spacer(Modifier.height(10.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    for (t in listOf("${memories.size} memories", "${annivs.size} anniversaries"))
                                        Text(t, Modifier.clip(RoundedCornerShape(50)).background(Color.White.copy(alpha = 0.2f)).padding(horizontal = 10.dp, vertical = 4.dp), color = Color.White, fontSize = 12.sp)
                                }
                            }
                        }
                        Spacer(Modifier.height(8.dp))
                        val close: () -> Unit = { scope.launch { drawerState.close() } }
                        DrawerItem({ Text(filterLook("all").emoji, fontSize = 18.sp) }, filterLook("all").label, "${memories.size}", filter == "all", filterLook("all").c1, filterLook("all").c2) { filter = "all"; close() }
                        DrawerItem({ Text(filterLook("pinned").emoji, fontSize = 18.sp) }, filterLook("pinned").label, "${memories.count { it.pinned }}", filter == "pinned", filterLook("pinned").c1, filterLook("pinned").c2) { filter = "pinned"; close() }
                        DrawerItem({ Text(filterLook("notes").emoji, fontSize = 18.sp) }, filterLook("notes").label, "${memories.count { it.note }}", filter == "notes", filterLook("notes").c1, filterLook("notes").c2) { filter = "notes"; close() }
                        DrawerItem({ Text(filterLook("images").emoji, fontSize = 18.sp) }, filterLook("images").label, "${memories.count { !it.note }}", filter == "images", filterLook("images").c1, filterLook("images").c2) { filter = "images"; close() }
                        Spacer(Modifier.height(10.dp))
                        DrawerItem({ CalendarIcon(Color.White, 20.dp) }, "Anniversaries", "${annivs.size}", false, Color(0xFFF4B400), Color(0xFFFF7A59)) { calOpen = true; close() }
                        DrawerItem({ Text("\uD83C\uDFA8", fontSize = 18.sp) }, "Photo Studio", null, false, Color(0xFF6C3BFF), Color(0xFFFF4D8D)) { editorOpen = true; close() }
                        DrawerItem({ Icon(Icons.Filled.Settings, null, Modifier.size(20.dp), tint = Color.White) }, "Settings", null, false, Color(0xFF607D8B), Color(0xFF90A4AE)) { settings = true; close() }
                        Text("Developed by Junnel Entoma", Modifier.fillMaxWidth().padding(vertical = 20.dp), textAlign = TextAlign.Center, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }) {
                Box(Modifier.fillMaxSize().background(if (themed) Color.Transparent else MaterialTheme.colorScheme.background)) {
                    if (themed) HomeBackground(
                        bgKind, bgAnimated, bgSparkles, dark,
                        if (bgPhoto.isNotEmpty()) File(ctx.filesDir, bgPhoto) else null,
                        bgDim, bgBlur, Modifier.fillMaxSize()
                    )
                    Column(Modifier.fillMaxSize().statusBarsPadding()) {
                        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp).height(64.dp), verticalAlignment = Alignment.CenterVertically) {
                            if (searching) {
                                IconButton({ searching = false; query = "" }) { Icon(Icons.Filled.ArrowBack, "Close search", tint = main) }
                                TextField(
                                    query, { query = it }, Modifier.weight(1f).focusRequester(focus), singleLine = true, placeholder = { Text("Search notes") },
                                    colors = TextFieldDefaults.colors(
                                        focusedContainerColor = Color.Transparent, unfocusedContainerColor = Color.Transparent,
                                        focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent,
                                        focusedTextColor = main, unfocusedTextColor = main, cursorColor = Accent,
                                        focusedPlaceholderColor = pal.sub, unfocusedPlaceholderColor = pal.sub
                                    )
                                )
                            } else {
                                Box(Modifier.padding(start = 4.dp)) { MenuOrb(drawerState.targetValue == DrawerValue.Open, main) { scope.launch { drawerState.open() } } }
                                Spacer(Modifier.weight(1f))
                                IconButton({ searching = true }) { Icon(Icons.Filled.Search, "Search", tint = main) }
                                Box {
                                    IconButton({ moreOpen = true }) { Icon(Icons.Filled.MoreVert, "More", tint = main) }
                                    DropdownMenu(moreOpen, { moreOpen = false }) {
                                        DropdownMenuItem({ Text(if (newest) "Show oldest first" else "Show newest first") }, { newest = !newest; prefs.edit().putBoolean("newest", newest).apply(); moreOpen = false })
                                    }
                                }
                            }
                        }
                        val content: @Composable (Entry, Int, Boolean) -> Unit = { e, i, compact ->
                            EntryContent(e, i, compact, pal, filter, heading, count, floatStyle, open, pin, del)
                        }
                        if (layout == "grid") LazyVerticalStaggeredGrid(
                            StaggeredGridCells.Fixed(cols), Modifier.fillMaxSize(), contentPadding = pad,
                            verticalItemSpacing = 10.dp, horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            itemsIndexed(entries, key = { _, e -> keyOf(e) }, span = { _, e -> if (e is Entry.Item) StaggeredGridItemSpan.SingleLane else StaggeredGridItemSpan.FullLine }) { i, e -> content(e, i, true) }
                        } else LazyColumn(Modifier.fillMaxSize(), contentPadding = pad, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            itemsIndexed(entries, key = { _, e -> keyOf(e) }) { i, e -> content(e, i, false) }
                        }
                    }
                    BottomPill(
                        layout == "grid",
                        { layout = if (layout == "grid") "list" else "grid"; prefs.edit().putString("layout", layout).apply() },
                        { editNote(null) },
                        { calOpen = true },
                        { picker.launch(PickVisualMediaRequest(PickVisualMedia.ImageOnly)) },
                        Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 20.dp)
                    )
                }
            }
        }


        pending?.let { uri ->
            AlertDialog(
                onDismissRequest = { pending = null }, title = { Text("New memory") },
                text = {
                    Column {
                        AsyncImage(uri, null, Modifier.fillMaxWidth().height(200.dp), contentScale = ContentScale.Crop)
                        Spacer(Modifier.height(8.dp))
                        OutlinedTextField(caption, { caption = it }, label = { Text("Caption") })
                    }
                },
                confirmButton = {
                    TextButton({
                        val name = "img_${System.currentTimeMillis()}"
                        ctx.contentResolver.openInputStream(uri)?.use { i -> File(ctx.filesDir, name).outputStream().use { o -> i.copyTo(o) } }
                        commit(memories + Memory(name, caption.trim(), System.currentTimeMillis()))
                        pending = null
                    }) { Text("Post") }
                },
                dismissButton = { TextButton({ pending = null }) { Text("Cancel") } }
            )
        }
        viewing?.let { m ->
            Dialog(onDismissRequest = { viewing = null }, properties = DialogProperties(usePlatformDefaultWidth = false)) {
                Box(Modifier.fillMaxSize().background(Color.Black).clickable { viewing = null }) {
                    AsyncImage(File(ctx.filesDir, m.file), m.caption, Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
                    IconButton({ viewing = null }, Modifier.align(Alignment.TopEnd).padding(8.dp)) { Icon(Icons.Filled.Close, "Close", tint = Color.White) }
                    if (m.caption.isNotEmpty()) Text(m.caption, color = Color.White, modifier = Modifier.align(Alignment.BottomCenter).padding(16.dp))
                }
            }
        }
        if (confirmClear) {
            AlertDialog(
                onDismissRequest = { confirmClear = false }, title = { Text("Delete all memories?") }, text = { Text("This cannot be undone.") },
                confirmButton = { TextButton({ memories.forEach { File(ctx.filesDir, it.file).delete() }; commit(emptyList()); confirmClear = false }) { Text("Delete") } },
                dismissButton = { TextButton({ confirmClear = false }) { Text("Cancel") } }
            )
        }

        if (noteOpen) {
            AlertDialog(
                onDismissRequest = { noteOpen = false },
                title = { Text(if (noteEditing == null) "New note" else "Edit note") },
                text = {
                    Column {
                        OutlinedTextField(noteTitle, { noteTitle = it }, label = { Text("Title") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                        Spacer(Modifier.height(8.dp))
                        OutlinedTextField(noteBody, { noteBody = it }, label = { Text("Note") }, minLines = 5, modifier = Modifier.fillMaxWidth())
                    }
                },
                confirmButton = {
                    TextButton({
                        val e = noteEditing
                        if (e == null) commit(memories + Memory("note_${System.currentTimeMillis()}", noteTitle.trim(), System.currentTimeMillis(), false, noteBody.trim(), true))
                        else commit(memories.map { if (it.file == e.file) it.copy(caption = noteTitle.trim(), body = noteBody.trim()) else it })
                        noteOpen = false
                    }, enabled = noteTitle.isNotBlank() || noteBody.isNotBlank()) { Text("Save") }
                },
                dismissButton = { TextButton({ noteOpen = false }) { Text("Cancel") } }
            )
        }

        // Opening screen: app icon in the middle, developer credit at the lower part.
        var showSplash by remember { mutableStateOf(true) }
        LaunchedEffect(Unit) { delay(1800); showSplash = false }
        val splashAlpha by animateFloatAsState(if (showSplash) 1f else 0f, tween(500), label = "splash")
        if (showSplash || splashAlpha > 0f) {
            Box(
                Modifier.fillMaxSize().graphicsLayer { alpha = splashAlpha }
                    .background(Brush.verticalGradient(listOf(Color(0xFF1B1442), Color(0xFF0F6E7A))))
                    .clickable(enabled = false) {}
            ) {
                AndroidView(
                    factory = { c -> ImageView(c).apply { setImageResource(R.mipmap.ic_launcher) } },
                    modifier = Modifier.align(Alignment.Center).size(120.dp)
                )
                Text(
                    "Developed by: Junnel Entoma", color = Color.White, style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 32.dp)
                )
            }
        }
    }
}

// ---------------------------------------------------------------- Anniversary calendar

data class Anniv(val id: Long, val title: String, val year: Int, val month: Int, val day: Int)

val MONTHS = listOf("January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December")

fun loadAnn(p: SharedPreferences): List<Anniv> {
    val a = JSONArray(p.getString("anniv", "[]"))
    return (0 until a.length()).map { val o = a.getJSONObject(it); Anniv(o.getLong("i"), o.getString("t"), o.getInt("y"), o.getInt("m"), o.getInt("d")) }
}

fun saveAnn(p: SharedPreferences, l: List<Anniv>) {
    val a = JSONArray(l.map { JSONObject().put("i", it.id).put("t", it.title).put("y", it.year).put("m", it.month).put("d", it.day) })
    p.edit().putString("anniv", a.toString()).apply()
}

/** Anniversaries repeat every year, starting from the year they were first set. */
fun Anniv.on(y: Int, m: Int, d: Int) = month == m && day == d && y >= year

/** Days until the next occurrence (0 = today) and how many years it will be. */
fun Anniv.next(): Pair<Int, Int> {
    val today = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }
    fun at(yy: Int) = Calendar.getInstance().apply { set(yy, month - 1, day, 0, 0, 0); set(Calendar.MILLISECOND, 0) }
    var y = maxOf(today.get(Calendar.YEAR), year)
    var c = at(y)
    if (c.before(today)) { y++; c = at(y) }
    return Math.round((c.timeInMillis - today.timeInMillis) / 86400000.0).toInt() to (y - year)
}

@Composable
fun CalendarIcon(color: Color, size: Dp = 24.dp) = Canvas(Modifier.size(size)) {
    val w = this.size.width; val sw = 2.2.dp.toPx()
    drawRoundRect(color, Offset(w * 0.08f, w * 0.16f), Size(w * 0.84f, w * 0.76f), CornerRadius(w * 0.16f), style = Stroke(sw))
    drawLine(color, Offset(w * 0.08f, w * 0.4f), Offset(w * 0.92f, w * 0.4f), strokeWidth = sw)
    drawLine(color, Offset(w * 0.32f, w * 0.06f), Offset(w * 0.32f, w * 0.26f), strokeWidth = sw)
    drawLine(color, Offset(w * 0.68f, w * 0.06f), Offset(w * 0.68f, w * 0.26f), strokeWidth = sw)
    drawCircle(color, w * 0.07f, Offset(w * 0.5f, w * 0.66f))
}

@Composable
fun AnnivDialog(initial: Anniv?, def: Triple<Int, Int, Int>, onSave: (Anniv) -> Unit, onDismiss: () -> Unit) {
    var title by remember { mutableStateOf(initial?.title ?: "") }
    var y by remember { mutableIntStateOf(initial?.year ?: def.first) }
    var m by remember { mutableIntStateOf(initial?.month ?: def.second) }
    var d by remember { mutableIntStateOf(initial?.day ?: def.third) }
    var picking by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "New anniversary" else "Edit anniversary") },
        text = {
            Column {
                OutlinedTextField(title, { title = it }, label = { Text("Title") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(12.dp))
                OutlinedButton({ picking = true }, Modifier.fillMaxWidth()) { Text("${MONTHS[m - 1]} $d, $y") }
                Text("Repeats every year", Modifier.padding(top = 8.dp), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        },
        confirmButton = { TextButton({ onSave(Anniv(initial?.id ?: System.currentTimeMillis(), title.trim(), y, m, d)) }, enabled = title.isNotBlank()) { Text("Save") } },
        dismissButton = { TextButton(onDismiss) { Text("Cancel") } }
    )
    if (picking) {
        val utc = TimeZone.getTimeZone("UTC")
        val st = rememberDatePickerState(initialSelectedDateMillis = Calendar.getInstance(utc).apply { clear(); set(y, m - 1, d) }.timeInMillis)
        DatePickerDialog(
            { picking = false },
            confirmButton = {
                TextButton({
                    st.selectedDateMillis?.let { ms -> val c = Calendar.getInstance(utc); c.timeInMillis = ms; y = c.get(Calendar.YEAR); m = c.get(Calendar.MONTH) + 1; d = c.get(Calendar.DAY_OF_MONTH) }
                    picking = false
                }) { Text("OK") }
            },
            dismissButton = { TextButton({ picking = false }) { Text("Cancel") } }
        ) { DatePicker(st) }
    }
}

@Composable
fun AnnivRow(a: Anniv, onEdit: () -> Unit, onDelete: () -> Unit) {
    val (days, years) = a.next()
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(MaterialTheme.colorScheme.surfaceVariant).clickable(onClick = onEdit).padding(start = 16.dp, top = 12.dp, bottom = 12.dp, end = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(a.title, fontSize = 18.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text("${MONTHS[a.month - 1]} ${a.day}, ${a.year}", fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Column(horizontalAlignment = Alignment.End) {
            Text(when (days) { 0 -> "Today \uD83C\uDF89"; 1 -> "Tomorrow"; else -> "in $days days" }, color = Accent, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
            if (years > 0) Text("$years ${if (years == 1) "year" else "years"}", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        IconButton(onDelete) { Icon(Icons.Filled.Delete, "Delete", Modifier.size(18.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant) }
    }
}

@Composable
fun AnniversaryScreen(list: List<Anniv>, onChange: (List<Anniv>) -> Unit, onBack: () -> Unit) {
    val now = remember { Calendar.getInstance() }
    val ty = now.get(Calendar.YEAR); val tm = now.get(Calendar.MONTH) + 1; val td = now.get(Calendar.DAY_OF_MONTH)
    var ym by remember { mutableIntStateOf(ty * 12 + tm - 1) }
    var sel by remember { mutableStateOf(Triple(ty, tm, td)) }
    var editing by remember { mutableStateOf<Anniv?>(null) }
    var dialog by remember { mutableStateOf(false) }
    val year = ym / 12; val month = ym % 12 + 1
    val first = Calendar.getInstance().apply { set(year, month - 1, 1) }
    val offset = first.get(Calendar.DAY_OF_WEEK) - 1
    val dim = first.getActualMaximum(Calendar.DAY_OF_MONTH)
    val weeks = (offset + dim + 6) / 7
    val onDay = list.filter { it.on(sel.first, sel.second, sel.third) }
    val upcoming = list.sortedBy { it.next().first }
    val fg = MaterialTheme.colorScheme.onBackground

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Anniversaries") },
                navigationIcon = { IconButton(onBack) { Icon(Icons.Filled.ArrowBack, "Back") } },
                actions = { TextButton({ ym = ty * 12 + tm - 1; sel = Triple(ty, tm, td) }) { Text("Today", color = Accent) } }
            )
        },
        floatingActionButton = {
            FloatingActionButton({ editing = null; dialog = true }, containerColor = Accent, contentColor = Color.White) { Icon(Icons.Filled.Add, "Add anniversary") }
        }
    ) { pad ->
        LazyColumn(Modifier.fillMaxSize().padding(pad), contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 96.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            item {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    IconButton({ ym-- }) { Icon(Icons.Filled.ArrowBack, "Previous month") }
                    Text("${MONTHS[month - 1]} $year", Modifier.weight(1f), textAlign = TextAlign.Center, fontSize = 20.sp, fontWeight = FontWeight.Medium)
                    IconButton({ ym++ }) { Icon(Icons.Filled.ArrowForward, "Next month") }
                }
                Row(Modifier.fillMaxWidth()) {
                    for (w in listOf("S", "M", "T", "W", "T", "F", "S")) Text(w, Modifier.weight(1f), textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
                }
                for (w in 0 until weeks) Row(Modifier.fillMaxWidth()) {
                    for (c in 0..6) {
                        val d = w * 7 + c - offset + 1
                        if (d < 1 || d > dim) { Spacer(Modifier.weight(1f).aspectRatio(1f)); continue }
                        val isSel = sel == Triple(year, month, d)
                        val isToday = year == ty && month == tm && d == td
                        val has = list.any { it.on(year, month, d) }
                        Box(
                            Modifier.weight(1f).aspectRatio(1f).padding(3.dp).clip(CircleShape)
                                .background(if (isSel) Accent else Color.Transparent)
                                .then(if (isToday && !isSel) Modifier.border(1.5.dp, Accent, CircleShape) else Modifier)
                                .clickable { sel = Triple(year, month, d) },
                            Alignment.Center
                        ) {
                            Text("$d", color = if (isSel) Color.Black else fg, fontWeight = if (isToday) FontWeight.Bold else FontWeight.Normal)
                            if (has) Box(Modifier.align(Alignment.BottomCenter).padding(bottom = 5.dp).size(5.dp).clip(CircleShape).background(if (isSel) Color.Black else Accent))
                        }
                    }
                }
            }
            item { Text("${MONTHS[sel.second - 1]} ${sel.third}, ${sel.first}", Modifier.padding(top = 12.dp), fontSize = 16.sp, fontWeight = FontWeight.SemiBold) }
            if (onDay.isEmpty()) item { Text("No anniversaries on this day.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
            items(onDay, key = { "d${it.id}" }) { a -> AnnivRow(a, { editing = a; dialog = true }, { onChange(list - a) }) }
            item { Text("Upcoming", Modifier.padding(top = 16.dp), fontSize = 16.sp, fontWeight = FontWeight.SemiBold) }
            if (upcoming.isEmpty()) item { Text("Tap + to add your first anniversary.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
            items(upcoming, key = { "u${it.id}" }) { a -> AnnivRow(a, { editing = a; dialog = true }, { onChange(list - a) }) }
        }
    }
    if (dialog) {
        AnnivDialog(editing, sel, { n ->
            onChange(if (editing == null) list + n else list.map { if (it.id == n.id) n else it })
            val vy = maxOf(year, n.year)
            sel = Triple(vy, n.month, n.day)
            ym = vy * 12 + n.month - 1
            dialog = false
        }, { dialog = false })
    }
}


// ---------------------------------------------------------------- Sidebar icon + drawer rows

/** Animated menu button: gradient tile whose bars morph into an X while the drawer is open. */
@Composable
fun MenuOrb(open: Boolean, tint: Color, onClick: () -> Unit) {
    val p by animateFloatAsState(if (open) 1f else 0f, tween(350), label = "orb")
    val shape = RoundedCornerShape(14.dp)
    Box(
        Modifier.size(44.dp).clip(shape)
            .background(Brush.linearGradient(listOf(Accent.copy(alpha = 0.30f), Color(0xFFFF7A59).copy(alpha = 0.22f))))
            .border(1.dp, Accent.copy(alpha = 0.6f), shape).clickable(onClick = onClick),
        Alignment.Center
    ) {
        Canvas(Modifier.size(22.dp)) {
            val w = size.width; val h = size.height; val t = 2.6.dp.toPx(); val cx = w / 2f; val cy = h / 2f
            fun bar(y: Float, len: Float, deg: Float, a: Float) {
                val l = w * len
                val x = w * 0.04f + ((w - l) / 2f - w * 0.04f) * p
                rotate(deg, Offset(cx, cy)) { drawRoundRect(tint.copy(alpha = a), Offset(x, y - t / 2f), Size(l, t), CornerRadius(t / 2f)) }
            }
            bar(h * 0.2f + (cy - h * 0.2f) * p, 0.92f, 45f * p, 1f)
            bar(cy, 0.55f, 0f, 1f - p)
            bar(h * 0.8f - (h * 0.8f - cy) * p, 0.75f + 0.17f * p, -45f * p, 1f)
        }
    }
}

@Composable
fun DrawerItem(icon: @Composable () -> Unit, label: String, badge: String?, selected: Boolean, c1: Color, c2: Color, onClick: () -> Unit) {
    Row(
        Modifier.padding(horizontal = 12.dp, vertical = 2.dp).fillMaxWidth().clip(RoundedCornerShape(16.dp))
            .background(if (selected) Accent.copy(alpha = 0.18f) else Color.Transparent).clickable(onClick = onClick).padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(38.dp).clip(RoundedCornerShape(12.dp)).background(Brush.linearGradient(listOf(c1, c2))), Alignment.Center) { icon() }
        Spacer(Modifier.width(14.dp))
        Text(label, Modifier.weight(1f), fontSize = 16.sp, fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium)
        if (badge != null) Text(badge, fontSize = 14.sp, color = if (selected) Accent else MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

// ---------------------------------------------------------------- Photo Studio

data class Edit(
    val filter: Int = 0, val bright: Float = 0f, val contrast: Float = 1f, val sat: Float = 1f, val warm: Float = 0f,
    val vignette: Float = 0f, val rot: Int = 0, val flip: Boolean = false, val ratio: Float = 0f
)

val FILTERS = listOf("Original", "Vivid", "Warm", "Cool", "Mono", "Noir", "Sepia", "Fade", "Dream")
val RATIOS = listOf("Free" to 0f, "1:1" to 1f, "4:5" to 0.8f, "4:3" to 1.3333f, "16:9" to 1.7778f, "9:16" to 0.5625f)

private fun cm(vararg v: Float) = AColorMatrix(v)

fun filterBase(i: Int): AColorMatrix {
    val m = AColorMatrix()
    when (i) {
        1 -> { m.setSaturation(1.5f); m.postConcat(cm(1.1f,0f,0f,0f,-8f, 0f,1.1f,0f,0f,-8f, 0f,0f,1.1f,0f,-8f, 0f,0f,0f,1f,0f)) }
        2 -> m.set(floatArrayOf(1.12f,0f,0f,0f,8f, 0f,1.02f,0f,0f,0f, 0f,0f,0.88f,0f,-8f, 0f,0f,0f,1f,0f))
        3 -> m.set(floatArrayOf(0.88f,0f,0f,0f,-6f, 0f,1f,0f,0f,0f, 0f,0f,1.14f,0f,10f, 0f,0f,0f,1f,0f))
        4 -> m.setSaturation(0f)
        5 -> { m.setSaturation(0f); m.postConcat(cm(1.45f,0f,0f,0f,-45f, 0f,1.45f,0f,0f,-45f, 0f,0f,1.45f,0f,-45f, 0f,0f,0f,1f,0f)) }
        6 -> m.set(floatArrayOf(0.393f,0.769f,0.189f,0f,0f, 0.349f,0.686f,0.168f,0f,0f, 0.272f,0.534f,0.131f,0f,0f, 0f,0f,0f,1f,0f))
        7 -> { m.setSaturation(0.75f); m.postConcat(cm(0.85f,0f,0f,0f,28f, 0f,0.85f,0f,0f,28f, 0f,0f,0.85f,0f,28f, 0f,0f,0f,1f,0f)) }
        8 -> { m.setSaturation(1.25f); m.postConcat(cm(1f,0f,0f,0f,18f, 0f,1f,0f,0f,6f, 0f,0f,1.08f,0f,22f, 0f,0f,0f,1f,0f)) }
    }
    return m
}

fun adjustMatrix(e: Edit): AColorMatrix {
    val m = filterBase(e.filter)
    val sat = AColorMatrix().apply { setSaturation(e.sat) }
    val c = e.contrast
    val t = (1f - c) * 128f + e.bright * 100f
    val w = e.warm * 30f
    m.postConcat(sat)
    m.postConcat(cm(c,0f,0f,0f,t, 0f,c,0f,0f,t, 0f,0f,c,0f,t, 0f,0f,0f,1f,0f))
    m.postConcat(cm(1f,0f,0f,0f,w, 0f,1f,0f,0f,0f, 0f,0f,1f,0f,-w, 0f,0f,0f,1f,0f))
    return m
}

fun colorFilterOf(e: Edit) = androidx.compose.ui.graphics.ColorFilter.colorMatrix(androidx.compose.ui.graphics.ColorMatrix(adjustMatrix(e).array))

fun decodeBitmap(ctx: Context, uri: Uri, max: Int = 2048): Bitmap? = try {
    val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
    var s = 1
    while (o.outWidth / s > max || o.outHeight / s > max) s *= 2
    val o2 = BitmapFactory.Options().apply { inSampleSize = s }
    ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o2) }
} catch (ex: Exception) { null }

fun transformBmp(b: Bitmap, rot: Int, flip: Boolean): Bitmap {
    if (rot == 0 && !flip) return b
    val m = android.graphics.Matrix()
    m.postRotate(rot.toFloat())
    if (flip) m.postScale(-1f, 1f)
    return Bitmap.createBitmap(b, 0, 0, b.width, b.height, m, true)
}

/** Full-resolution export: rotate/flip, centre-crop to ratio, colour matrix, vignette. */
fun renderEdit(src: Bitmap, e: Edit): Bitmap {
    val base = transformBmp(src, e.rot, e.flip)
    var w = base.width; var h = base.height; var x = 0; var y = 0
    if (e.ratio > 0f) {
        if (w.toFloat() / h > e.ratio) { val nw = (h * e.ratio).toInt(); x = (w - nw) / 2; w = nw }
        else { val nh = (w / e.ratio).toInt(); y = (h - nh) / 2; h = nh }
    }
    val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
    val c = android.graphics.Canvas(out)
    val p = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG or android.graphics.Paint.FILTER_BITMAP_FLAG)
    p.colorFilter = android.graphics.ColorMatrixColorFilter(adjustMatrix(e))
    c.drawBitmap(base, -x.toFloat(), -y.toFloat(), p)
    if (e.vignette > 0f) {
        val vp = android.graphics.Paint()
        vp.shader = android.graphics.RadialGradient(
            w / 2f, h / 2f, hypot(w.toFloat(), h.toFloat()) / 2f,
            intArrayOf(0, android.graphics.Color.argb((e.vignette * 255).toInt(), 0, 0, 0)), floatArrayOf(0.55f, 1f), android.graphics.Shader.TileMode.CLAMP
        )
        c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), vp)
    }
    return out
}

// ---------------------------------------------------------------- AI Smart Filter (runs on the phone, nothing is uploaded)

/** What the AI "sees" in a photo: exposure, tonal range, colour cast, saturation and rough scene content (all 0..1 except cast). */
class PhotoStats(
    val mean: Float, val low: Float, val high: Float, val sat: Float, val cast: Float,
    val skin: Float, val sky: Float, val green: Float, val warm: Float, val dark: Float
)

fun analyzePhoto(src: Bitmap): PhotoStats {
    val side = 96
    val small = Bitmap.createScaledBitmap(src, side, side, true)
    val px = IntArray(side * side)
    small.getPixels(px, 0, side, 0, 0, side, side)
    val hist = IntArray(256)
    var sr = 0f; var sb = 0f; var ss = 0f
    var skin = 0; var sky = 0; var green = 0; var warm = 0; var dark = 0
    for (i in px.indices) {
        val p = px[i]
        val r = android.graphics.Color.red(p); val g = android.graphics.Color.green(p); val b = android.graphics.Color.blue(p)
        val mx = maxOf(r, g, b); val mn = minOf(r, g, b)
        val lum = (0.299f * r + 0.587f * g + 0.114f * b).toInt().coerceIn(0, 255)
        hist[lum]++
        sr += r; sb += b
        ss += if (mx == 0) 0f else (mx - mn).toFloat() / mx
        if (lum < 40) dark++
        if (r > 95 && g > 40 && b > 20 && r > g && r > b && (r - g) > 15 && (mx - mn) > 15 && (r - g) < 110) skin++
        if (i < px.size / 2 && b > r + 20 && b > g && lum > 90) sky++
        if (g > r + 8 && g > b + 8) green++
        if (r > g + 25 && r > b + 45 && mx > 120) warm++
    }
    val n = px.size.toFloat()
    var total = 0f; var acc = 0; var lo = 0; var hi = 255; var gotLo = false
    for (v in 0..255) {
        total += v * hist[v]; acc += hist[v]
        if (!gotLo && acc >= n * 0.02f) { lo = v; gotLo = true }
        if (acc >= n * 0.98f) { hi = v; break }
    }
    return PhotoStats(
        mean = total / (255f * n), low = lo / 255f, high = hi / 255f, sat = ss / n, cast = (sb - sr) / (255f * n),
        skin = skin / n, sky = sky / n, green = green / n, warm = warm / n, dark = dark / n
    )
}

fun sceneOf(s: PhotoStats): String = when {
    s.mean < 0.22f && s.dark > 0.4f -> "Low light"
    s.skin > 0.2f && s.sat < 0.6f -> "Portrait"
    s.sky + s.green > 0.3f -> "Landscape"
    s.warm > 0.2f && s.mean < 0.5f -> "Sunset"
    s.warm > 0.2f && s.sat > 0.4f -> "Food"
    else -> "Everyday"
}

fun PhotoStats.summary(): String {
    val exp = when { mean < 0.3f -> "Dark"; mean > 0.62f -> "Bright"; else -> "Balanced" }
    val tone = when { cast > 0.06f -> "Cool tones"; cast < -0.06f -> "Warm tones"; else -> "Neutral tones" }
    val col = when { sat < 0.25f -> "Muted"; sat > 0.55f -> "Vivid"; else -> "Natural colors" }
    return "$exp \u2022 $tone \u2022 $col"
}

/** Auto-correction every look starts from: exposure, contrast, white balance and saturation fixed from the photo's own statistics. */
fun autoFix(s: PhotoStats): Edit {
    val range = (s.high - s.low).coerceAtLeast(0.2f)
    val contrast = (0.82f / range).coerceIn(0.9f, 1.35f)
    val bright = ((0.46f * 255f - 128f - contrast * (s.mean * 255f - 128f)) / 100f).coerceIn(-0.3f, 0.45f)
    val warm = (s.cast * 2.5f).coerceIn(-0.8f, 0.8f)
    val sat = (0.42f / s.sat.coerceAtLeast(0.08f)).coerceIn(0.9f, 1.4f)
    return Edit(bright = bright, contrast = contrast, sat = sat, warm = warm)
}

private fun Edit.tuned(b: Float = 0f, c: Float = 1f, sa: Float = 1f, w: Float = 0f, v: Float = 0f) = copy(
    bright = (bright + b).coerceIn(-1f, 1f), contrast = (contrast * c).coerceIn(0.5f, 1.5f),
    sat = (sat * sa).coerceIn(0f, 2f), warm = (warm + w).coerceIn(-1f, 1f), vignette = v.coerceIn(0f, 1f)
)

class AiLook(val name: String, val scene: String, val make: (PhotoStats) -> Edit)

val AI_LOOKS = listOf(
    AiLook("Auto Enhance", "Everyday") { autoFix(it) },
    AiLook("Portrait Glow", "Portrait") { autoFix(it).tuned(b = 0.04f, c = 0.95f, sa = 0.95f, w = 0.12f, v = 0.12f) },
    AiLook("Vivid Scenery", "Landscape") { autoFix(it).tuned(c = 1.08f, sa = 1.25f, w = -0.05f, v = 0.1f) },
    AiLook("Golden Hour", "Sunset") { autoFix(it).tuned(c = 1.05f, sa = 1.1f, w = 0.45f, v = 0.2f) },
    AiLook("Night Boost", "Low light") { autoFix(it).tuned(b = 0.1f, c = 1.1f, sa = 1.15f, w = -0.1f) },
    AiLook("Food Fresh", "Food") { autoFix(it).tuned(b = 0.03f, c = 1.06f, sa = 1.2f, w = 0.1f, v = 0.1f) },
    AiLook("Cinematic", "") { autoFix(it).tuned(b = -0.03f, c = 1.18f, sa = 0.82f, w = -0.18f, v = 0.35f) },
    AiLook("B&W Drama", "") { autoFix(it).tuned(c = 1.3f, sa = 0f, v = 0.3f) }
)

fun bestLookFor(scene: String): Int = AI_LOOKS.indexOfFirst { it.scene == scene }.let { if (it < 0) 0 else it }

/** Applies an AI look at a given strength (0 = untouched, 1 = full) while keeping the user's rotate, flip and crop. */
fun Edit.withAi(t: Edit, k: Float) = copy(
    filter = 0, bright = t.bright * k, contrast = 1f + (t.contrast - 1f) * k,
    sat = 1f + (t.sat - 1f) * k, warm = t.warm * k, vignette = t.vignette * k
)

@Composable
fun ToolChip(text: String, selected: Boolean, onClick: () -> Unit) {
    Box(Modifier.clip(RoundedCornerShape(50)).background(if (selected) Accent else Color.White.copy(alpha = 0.12f)).clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 9.dp)) {
        Text(text, color = if (selected) Color.Black else Color.White, fontSize = 14.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
fun AdjSlider(label: String, v: Float, range: ClosedFloatingPointRange<Float>, show: String, onChange: (Float) -> Unit) {
    Column {
        Row(Modifier.fillMaxWidth()) {
            Text(label, Modifier.weight(1f), color = Color.White.copy(alpha = 0.75f), fontSize = 13.sp)
            Text(show, color = Accent, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
        }
        Slider(v, onChange, Modifier.height(30.dp), valueRange = range, colors = SliderDefaults.colors(thumbColor = Accent, activeTrackColor = Accent, inactiveTrackColor = Color.White.copy(alpha = 0.2f)))
    }
}

@Composable
fun PhotoEditor(onClose: () -> Unit, onSave: (String) -> Unit) {
    val ctx = LocalContext.current
    var src by remember { mutableStateOf<Bitmap?>(null) }
    var e by remember { mutableStateOf(Edit()) }
    var tab by remember { mutableIntStateOf(0) }
    var compare by remember { mutableStateOf(false) }
    var aiLook by remember { mutableIntStateOf(-1) }
    var aiStrength by remember { mutableFloatStateOf(1f) }
    val pick = rememberLauncherForActivityResult(PickVisualMedia()) { uri -> if (uri != null) { src = decodeBitmap(ctx, uri); e = Edit(); aiLook = -1; aiStrength = 1f } }
    val choose: () -> Unit = { pick.launch(PickVisualMediaRequest(PickVisualMedia.ImageOnly)) }
    val bmp = src
    val stats = remember(bmp) { if (bmp != null) analyzePhoto(bmp) else null }

    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF17103A), Color(0xFF0A2E3B), Color(0xFF050509))))) {
        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp).height(60.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClose) { Icon(Icons.Filled.Close, "Close", tint = Color.White) }
                Column(Modifier.weight(1f)) {
                    Text("Photo Studio", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text("Edit \u2022 Enhance \u2022 Save", color = Color.White.copy(alpha = 0.6f), fontSize = 11.sp)
                }
                if (bmp != null) {
                    TextButton(choose) { Text("New", color = Color.White.copy(alpha = 0.8f)) }
                    TextButton({ e = Edit(); aiLook = -1; aiStrength = 1f }) { Text("Reset", color = Color.White.copy(alpha = 0.8f)) }
                    Box(
                        Modifier.padding(start = 4.dp, end = 8.dp).clip(RoundedCornerShape(50))
                            .background(Brush.horizontalGradient(listOf(Accent, Color(0xFFFF7A59))))
                            .clickable {
                                val name = "img_${System.currentTimeMillis()}"
                                val out = renderEdit(bmp, e)
                                File(ctx.filesDir, name).outputStream().use { out.compress(Bitmap.CompressFormat.JPEG, 92, it) }
                                onSave(name)
                                Toast.makeText(ctx, "Saved to PostIt", Toast.LENGTH_SHORT).show()
                            }.padding(horizontal = 18.dp, vertical = 9.dp)
                    ) { Text("Save", color = Color.Black, fontWeight = FontWeight.Bold) }
                }
            }
            if (bmp == null) {
                Column(Modifier.weight(1f).fillMaxWidth().padding(32.dp), Arrangement.Center, Alignment.CenterHorizontally) {
                    Box(Modifier.size(120.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Color(0xFF6C3BFF), Color(0xFFFF4D8D), Color(0xFFFF9E40)))), Alignment.Center) { Text("\uD83C\uDFA8", fontSize = 56.sp) }
                    Spacer(Modifier.height(24.dp))
                    Text("Make every photo shine", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                    Text("AI Filters \u2022 Adjustments \u2022 Crop \u2022 Rotate \u2022 Vignette", Modifier.padding(top = 8.dp), color = Color.White.copy(alpha = 0.65f), fontSize = 14.sp, textAlign = TextAlign.Center)
                    Spacer(Modifier.height(28.dp))
                    Box(Modifier.clip(RoundedCornerShape(50)).background(Brush.horizontalGradient(listOf(Accent, Color(0xFFFF7A59)))).clickable { choose() }.padding(horizontal = 32.dp, vertical = 14.dp)) {
                        Text("Choose a photo", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    }
                }
            } else {
                val base = remember(bmp, e.rot, e.flip) { transformBmp(bmp, e.rot, e.flip) }
                val baseImg = remember(base) { base.asImageBitmap() }
                val ratio = if (e.ratio > 0f) e.ratio else base.width.toFloat() / base.height
                Box(Modifier.weight(1f).fillMaxWidth().padding(16.dp), Alignment.Center) {
                    Box(
                        Modifier.aspectRatio(ratio).clip(RoundedCornerShape(20.dp))
                            .pointerInput(Unit) { detectTapGestures(onPress = { compare = true; tryAwaitRelease(); compare = false }) }
                    ) {
                        Image(baseImg, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop, colorFilter = if (compare) null else colorFilterOf(e))
                        if (!compare && e.vignette > 0f) Canvas(Modifier.fillMaxSize()) {
                            drawRect(Brush.radialGradient(0.55f to Color.Transparent, 1f to Color.Black.copy(alpha = e.vignette), center = center, radius = hypot(size.width, size.height) / 2f))
                        }
                        if (compare) Text("ORIGINAL", Modifier.align(Alignment.TopStart).padding(10.dp).clip(RoundedCornerShape(50)).background(Color.Black.copy(alpha = 0.55f)).padding(horizontal = 10.dp, vertical = 4.dp), color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
                Text("Hold the photo to compare", Modifier.fillMaxWidth(), color = Color.White.copy(alpha = 0.5f), fontSize = 11.sp, textAlign = TextAlign.Center)
                Row(Modifier.padding(16.dp).fillMaxWidth().clip(RoundedCornerShape(50)).background(Color.White.copy(alpha = 0.08f)).padding(4.dp)) {
                    listOf("\u2728 Filters", "\uD83C\uDF9A Adjust", "\u2702 Crop", "\uD83E\uDD16 AI").forEachIndexed { i, t ->
                        Box(Modifier.weight(1f).clip(RoundedCornerShape(50)).background(if (tab == i) Accent else Color.Transparent).clickable { tab = i }.padding(vertical = 10.dp), Alignment.Center) {
                            Text(t, color = if (tab == i) Color.Black else Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                        }
                    }
                }
                Column(Modifier.fillMaxWidth().height(224.dp).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp)) {
                    when (tab) {
                        0 -> Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            FILTERS.forEachIndexed { i, name ->
                                val shape = RoundedCornerShape(14.dp)
                                Column(Modifier.clickable { e = e.copy(filter = i) }, horizontalAlignment = Alignment.CenterHorizontally) {
                                    Image(baseImg, name, Modifier.size(88.dp).clip(shape).then(if (e.filter == i) Modifier.border(3.dp, Accent, shape) else Modifier), contentScale = ContentScale.Crop, colorFilter = colorFilterOf(Edit(filter = i)))
                                    Text(name, Modifier.padding(top = 6.dp), color = if (e.filter == i) Accent else Color.White, fontSize = 12.sp)
                                }
                            }
                        }
                        1 -> Column {
                            AdjSlider("Brightness", e.bright, -1f..1f, "${(e.bright * 100).toInt()}") { e = e.copy(bright = it) }
                            AdjSlider("Contrast", e.contrast, 0.5f..1.5f, "${((e.contrast - 1f) * 100).toInt()}") { e = e.copy(contrast = it) }
                            AdjSlider("Saturation", e.sat, 0f..2f, "${((e.sat - 1f) * 100).toInt()}") { e = e.copy(sat = it) }
                            AdjSlider("Warmth", e.warm, -1f..1f, "${(e.warm * 100).toInt()}") { e = e.copy(warm = it) }
                            AdjSlider("Vignette", e.vignette, 0f..1f, "${(e.vignette * 100).toInt()}%") { e = e.copy(vignette = it) }
                        }
                        2 -> Column {
                            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                RATIOS.forEach { (n, r) -> ToolChip(n, e.ratio == r) { e = e.copy(ratio = r) } }
                            }
                            Spacer(Modifier.height(14.dp))
                            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                ToolChip("\u27F2 Left", false) { e = e.copy(rot = (e.rot + 270) % 360) }
                                ToolChip("\u27F3 Right", false) { e = e.copy(rot = (e.rot + 90) % 360) }
                                ToolChip("\u21C6 Flip", e.flip) { e = e.copy(flip = !e.flip) }
                            }
                        }
                        else -> if (stats != null) {
                            val scene = sceneOf(stats)
                            val best = bestLookFor(scene)
                            val order = remember(stats) { AI_LOOKS.indices.sortedBy { if (it == best) -1 else it } }
                            val applyAi: (Int) -> Unit = { i -> aiLook = i; e = e.withAi(AI_LOOKS[i].make(stats), aiStrength) }
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Column(Modifier.weight(1f)) {
                                        Text("AI scene: $scene", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                                        Text(stats.summary(), color = Color.White.copy(alpha = 0.6f), fontSize = 12.sp)
                                    }
                                    Box(
                                        Modifier.clip(RoundedCornerShape(50)).background(Brush.horizontalGradient(listOf(Accent, Color(0xFFFF7A59))))
                                            .clickable { applyAi(best) }.padding(horizontal = 16.dp, vertical = 8.dp)
                                    ) { Text("\u2728 Auto", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 13.sp) }
                                }
                                Spacer(Modifier.height(10.dp))
                                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                    order.forEach { i ->
                                        val look = AI_LOOKS[i]
                                        val shape = RoundedCornerShape(14.dp)
                                        Column(Modifier.clickable { applyAi(i) }, horizontalAlignment = Alignment.CenterHorizontally) {
                                            Box {
                                                Image(baseImg, look.name, Modifier.size(88.dp).clip(shape).then(if (aiLook == i) Modifier.border(3.dp, Accent, shape) else Modifier), contentScale = ContentScale.Crop, colorFilter = colorFilterOf(look.make(stats)))
                                                if (i == best) Text("BEST", Modifier.align(Alignment.TopStart).padding(5.dp).clip(RoundedCornerShape(50)).background(Accent).padding(horizontal = 6.dp, vertical = 2.dp), color = Color.Black, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                            }
                                            Text(look.name, Modifier.padding(top = 6.dp), color = if (aiLook == i) Accent else Color.White, fontSize = 12.sp, maxLines = 1)
                                        }
                                    }
                                }
                                if (aiLook >= 0) AdjSlider("AI strength", aiStrength, 0f..1f, "${(aiStrength * 100).toInt()}%") { aiStrength = it; e = e.withAi(AI_LOOKS[aiLook].make(stats), it) }
                            }
                        }
                    }
                }
            }
        }
    }
}
