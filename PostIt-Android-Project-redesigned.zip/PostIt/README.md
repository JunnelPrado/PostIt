# PostIt

Post your memorable pictures on a styled homepage (Grid, Masonry or Mosaic), tap to view full screen,
and customize it from Settings, including a live animated homepage background
(Aurora, Sunset, Ocean, Neon, Forest, Rose) or your own photo with dimming and blur. Developed by Junnel Entoma.
Homepage pictures are compact notes-style cards, and you can write text notes (pencil button) that sit beside them.
Pictures can float in different styles (Float, Sway, Drift, Pulse) from Settings, and every picture has a pin button that keeps it at the top of the homepage.
Opening the app shows the icon with "Developed by: Junnel Entoma" at the lower part.
The launcher icon is a "memories" icon (stacked polaroid photos with a heart) and supports themed icons on Android 13+.

## Get the APK from GitHub (no Android Studio needed)
1. Create a new repository on github.com and upload this project (or the .zip) plus the
   `.github/workflows/build.yml` workflow.
2. Open the **Actions** tab. **Build PostIt APK** runs on every push (or press **Run workflow**).
3. When it turns green, open the run and download **PostIt-apk** under *Artifacts*.
   Unzip it and install `PostIt.apk`.
