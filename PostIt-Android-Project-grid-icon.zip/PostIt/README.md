# PostIt

Post your memorable pictures on a styled homepage (Grid, Masonry or Mosaic), tap to view full screen,
and customize it from Settings, including a live animated homepage background
(Aurora, Sunset, Ocean, Neon, Forest, Rose) or your own photo with dimming and blur. Developed by Junnel Entoma.
Homepage pictures are compact notes-style cards, and you can write text notes (pencil button) that sit beside them.
Pictures can float in different styles (Float, Sway, Drift, Pulse) from Settings, and every picture has a pin button that keeps it at the top of the homepage.
Opening the app shows the system launch screen with the icon and "Developed by: Junnel Entoma" at the lower part (Android 12+), then goes straight to the homepage.
The launcher icon is a "memories" icon (stacked polaroid photos with a heart) and supports themed icons on Android 13+.

## Get the APK from GitHub (no Android Studio needed)
1. Create a new repository on github.com and upload this project (or the .zip) plus the
   `.github/workflows/build.yml` workflow.
2. Open the **Actions** tab. **Build PostIt APK** runs on every push (or press **Run workflow**).
3. When it turns green, open the run and download **PostIt-apk** under *Artifacts*.
   Unzip it and install `PostIt.apk`.

## Photo Studio: AI Smart Filter
The **AI** tab in Photo Studio looks at your photo (exposure, tonal range, colour cast, saturation and rough scene such as
Portrait, Landscape, Sunset, Low light or Food), then suggests the **Best** look and builds eight ready-made looks
(Auto Enhance, Portrait Glow, Vivid Scenery, Golden Hour, Night Boost, Food Fresh, Cinematic, B&W Drama) tuned to that
photo. Tap **Auto** for the best match, and use **AI strength** to dial it up or down. It runs on the phone, so nothing is uploaded.

## Editable image notes
Tap the **caption** of an image note to edit it. Tap the **picture** to view it full screen.

## Photo Studio: new AI icon
The AI tab now uses an animated gradient sparkle icon (spinning aurora ring, pulsing four-point star) instead of the robot emoji.

## Grid icon (all homepage buttons in one place)
The bottom group of buttons is now a single animated **grid icon**. Tap it and a responsive grid panel springs open (the icon spins into an X) with every button inside it as a tile: **New note** (hero tile), **Grid/List view**, **Anniversaries** and **Add picture**. Tiles pop in one after another with a bounce and a haptic tick; tap outside the panel, the X or Back to close it. **Long-press the grid icon for a quick new note.**
The panel is responsive: the number of columns follows the screen width (2 on small phones, 3 on larger ones, 4 on tablets/landscape) and it never gets wider than 420dp.

## Customize Buttons
Settings > **Customize Buttons** has a live, tappable preview of the grid icon and lets you show or hide each button inside it, pick a style (Dark, Glass, Aurora, Light), button color, size, grid columns (Auto, 2, 3 or 4) and which side the icon sits on (left, center, right).

## Pictures
Tap a picture on the homepage to view it full screen. Tap the full-screen picture and it flips over so you can write a note on the back (saved automatically); tap **Flip back to picture** to return. Tap the caption to edit it. Long-press a card for View picture, Edit caption, Pin and Delete.

## Anniversary countdown
Every anniversary shows a live **days left** badge, a months/days breakdown, the anniversary number (1st, 2nd...) and a progress bar. The count is exact (calendar days, no clock rounding) and updates by itself at midnight, when you open the app, and when the phone's date, time or time zone changes. On the day it shows "Today!". Feb 29 anniversaries are celebrated on Feb 28 in non-leap years. The sidebar header shows the next upcoming anniversary.
