# PostIt

Post your memorable pictures on a styled homepage (Grid, Masonry or Mosaic), tap to view full screen,
and customize it from Settings, including a live animated homepage background
(Aurora, Sunset, Ocean, Neon, Forest, Rose) or your own photo with dimming and blur. Developed by Junnel Entoma.
Homepage pictures are compact notes-style cards, and you can write text notes (pencil button) that sit beside them.
Pictures can float in different styles (Float, Sway, Drift, Pulse) from Settings, and every picture has a pin button that keeps it at the top of the homepage.
Opening the app shows the system launch screen with the icon and "Developed by: Junnel Entoma" at the lower part (Android 12+), then goes straight to the homepage.
The launcher icon is a "memories" icon (stacked polaroid photos with a heart) and supports themed icons on Android 13+.

## Get the APK from GitHub (no Android Studio needed)
1. Create a new repository on github.com and upload this project (or the .zip) plus the
   `.github/workflows/build.yml` workflow.
2. Open the **Actions** tab. **Build PostIt APK** runs on every push (or press **Run workflow**).
3. When it turns green, open the run and download **PostIt-apk** under *Artifacts*.
   Unzip it and install `PostIt.apk`.

## Photo Studio: AI Smart Filter
The **AI** tab in Photo Studio looks at your photo (exposure, tonal range, colour cast, saturation and rough scene such as
Portrait, Landscape, Sunset, Low light or Food), then suggests the **Best** look and builds eight ready-made looks
(Auto Enhance, Portrait Glow, Vivid Scenery, Golden Hour, Night Boost, Food Fresh, Cinematic, B&W Drama) tuned to that
photo. Tap **Auto** for the best match, and use **AI strength** to dial it up or down. It runs on the phone, so nothing is uploaded.

## Editable image notes
Tap the **text** of an image note (title or caption) to edit its caption and note text. Tap the **picture** to view it full screen; long-press the card and choose **Edit text**.

## Photo Studio: new AI icon
The AI tab now uses an animated gradient sparkle icon (spinning aurora ring, pulsing four-point star) instead of the robot emoji.

## Customize Buttons
Settings > **Customize Buttons** lets you show or hide each button in the bottom group on the homepage (grid/list, +, anniversaries, add picture), pick a style (Dark, Glass, Aurora, Light), button color, size and position (left, center, right), with a live preview.

## Flip a picture and write notes on the back
Tap a picture on the homepage and the card flips in 3D. Write notes on the back (saved automatically), then tap **Flip back**. Cards with notes show a small "Notes" badge. The note text no longer shows under the caption. Long-press a picture card for **View picture** (full screen), **Edit text**, Pin and Delete.
