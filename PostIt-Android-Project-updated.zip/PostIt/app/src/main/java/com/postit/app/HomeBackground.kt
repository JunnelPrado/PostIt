package com.postit.app

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import java.io.File
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin
import kotlin.random.Random

/** A live background theme: a moving base gradient plus glowing blobs drifting over it. */
class BgTheme(val key: String, val label: String, val base: List<Color>, val blobs: List<Color>)

val THEMES = listOf(
    BgTheme("aurora", "Aurora",
        listOf(Color(0xFF0B1026), Color(0xFF0F3D4C), Color(0xFF2A1B6B)),
        listOf(Color(0xFF00E5A0), Color(0xFF7C4DFF), Color(0xFF00B8FF))),
    BgTheme("sunset", "Sunset",
        listOf(Color(0xFF2B1055), Color(0xFF8E2C6B), Color(0xFFD9552B)),
        listOf(Color(0xFFFF9E40), Color(0xFFFF4D8D), Color(0xFFFFD166))),
    BgTheme("ocean", "Ocean",
        listOf(Color(0xFF031B34), Color(0xFF065A82), Color(0xFF1C7293)),
        listOf(Color(0xFF21D4FD), Color(0xFF2AF598), Color(0xFF3A7BD5))),
    BgTheme("neon", "Neon",
        listOf(Color(0xFF0D0221), Color(0xFF261447), Color(0xFF0F084B)),
        listOf(Color(0xFFFF2BD6), Color(0xFF00F0FF), Color(0xFF8A2BE2))),
    BgTheme("forest", "Forest",
        listOf(Color(0xFF04210F), Color(0xFF0B4D2C), Color(0xFF1F6F43)),
        listOf(Color(0xFF7CFF6B), Color(0xFF1DE9B6), Color(0xFFC6F68D))),
    BgTheme("rose", "Rose",
        listOf(Color(0xFF3A0F2E), Color(0xFF8A2D5B), Color(0xFFE0709A)),
        listOf(Color(0xFFFFB3C7), Color(0xFFB388FF), Color(0xFFFF80AB)))
)

private class Spark(val x: Float, val y: Float, val k: Int, val r: Float, val ph: Float)

private val SPARKS: List<Spark> = Random(7).let { rnd ->
    List(34) { Spark(rnd.nextFloat(), rnd.nextFloat(), 1 + rnd.nextInt(3), 1f + rnd.nextFloat() * 2.5f, rnd.nextFloat() * 6.2831f) }
}

/**
 * Fills its bounds with the chosen background.
 * kind = one of THEMES keys, or "custom" (uses [photo], with [dim] and [blurRadius]).
 * All motion loops seamlessly and is only drawn (not recomposed) every frame.
 */
@Composable
fun HomeBackground(
    kind: String,
    animated: Boolean,
    sparkles: Boolean,
    dark: Boolean,
    photo: File?,
    dim: Float,
    blurRadius: Float,
    modifier: Modifier = Modifier
) {
    if (kind == "custom" && photo != null && photo.exists()) {
        Box(modifier) {
            AsyncImage(
                photo, null,
                Modifier.fillMaxSize().then(if (blurRadius > 0f) Modifier.blur(blurRadius.dp) else Modifier),
                contentScale = ContentScale.Crop
            )
            Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = (dim + if (dark) 0.15f else 0f).coerceIn(0f, 0.9f))))
        }
        return
    }

    val theme = THEMES.firstOrNull { it.key == kind } ?: THEMES[0]
    val phase: State<Float> = if (animated) {
        rememberInfiniteTransition(label = "bg").animateFloat(
            initialValue = 0f, targetValue = 1f,
            animationSpec = infiniteRepeatable(tween(36000, easing = LinearEasing), RepeatMode.Restart),
            label = "phase"
        )
    } else remember { mutableFloatStateOf(0.15f) }

    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val p = phase.value
        val ang = p * 2f * PI.toFloat()

        // 1) slowly rotating base gradient
        drawRect(
            Brush.linearGradient(
                theme.base,
                start = Offset(w * (0.5f + 0.7f * cos(ang)), h * (0.5f + 0.7f * sin(ang))),
                end = Offset(w * (0.5f - 0.7f * cos(ang)), h * (0.5f - 0.7f * sin(ang)))
            )
        )

        // 2) glowing blobs drifting on smooth looping paths
        val big = max(w, h)
        theme.blobs.forEachIndexed { i, c ->
            val cx = w * (0.5f + 0.42f * sin(ang + i * 2.1f))
            val cy = h * (0.5f + 0.42f * cos(ang * (1 + i % 2) + i * 1.3f))
            val r = big * (0.48f + 0.08f * sin(ang * 2f + i))
            drawCircle(
                Brush.radialGradient(listOf(c.copy(alpha = 0.55f), Color.Transparent), center = Offset(cx, cy), radius = r),
                radius = r, center = Offset(cx, cy)
            )
        }

        // 3) twinkling sparkles floating upward
        if (sparkles) {
            for (s in SPARKS) {
                val yy = (((s.y - p * s.k) % 1f) + 1f) % 1f
                val xx = s.x + 0.025f * sin(ang * 2f + s.ph)
                val a = 0.25f + 0.55f * abs(sin(ang * (s.k + 1) + s.ph))
                val c = Offset(xx * w, yy * h)
                drawCircle(Color.White.copy(alpha = a * 0.3f), s.r.dp.toPx() * 2.6f, c)
                drawCircle(Color.White.copy(alpha = a), s.r.dp.toPx(), c)
            }
        }

        // 4) deepen everything a little in dark mode
        if (dark) drawRect(Color.Black.copy(alpha = 0.3f))
    }
}

/** Small tappable preview used in Settings. */
@Composable
fun BgSwatch(kind: String, label: String, selected: Boolean, photo: File?, dark: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(16.dp)
    Column(Modifier.width(78.dp).clickable(onClick = onClick), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier.size(78.dp, 108.dp).clip(shape).border(
                if (selected) 3.dp else 1.dp,
                if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant,
                shape
            ),
            contentAlignment = Alignment.Center
        ) {
            when {
                kind == "none" -> Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.surfaceVariant), Alignment.Center) { Text("Off") }
                kind == "custom" && photo != null && photo.exists() ->
                    AsyncImage(photo, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                kind == "custom" -> Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.surfaceVariant), Alignment.Center) {
                    Icon(Icons.Filled.Add, "Choose photo")
                }
                else -> HomeBackground(kind, false, true, dark, null, 0f, 0f, Modifier.fillMaxSize())
            }
        }
        Text(label, Modifier.padding(top = 4.dp), style = MaterialTheme.typography.labelSmall)
    }
}
