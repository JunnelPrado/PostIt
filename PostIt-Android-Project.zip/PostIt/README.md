# PostIt

Post your memorable pictures on a styled homepage (Grid, Masonry or Mosaic), tap to view full screen,
and customize it from Settings. Developed by Junnel Entoma.

## Get the APK from GitHub (no Android Studio needed)
1. Create a new repository on github.com and upload this project (or the .zip) plus the
   `.github/workflows/build.yml` workflow.
2. Open the **Actions** tab. **Build PostIt APK** runs on every push (or press **Run workflow**).
3. When it turns green, open the run and download **PostIt-apk** under *Artifacts*.
   Unzip it and install `PostIt.apk`.
