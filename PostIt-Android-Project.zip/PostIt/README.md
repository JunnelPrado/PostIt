# PostIt

Post your memorable pictures on a styled homepage (Grid, Masonry or Mosaic), tap to view full screen,
and back them up from Settings. Developed by Junnel Entoma.

## Get the APK from GitHub (no Android Studio needed)
1. Create a new repository on github.com and upload everything in this folder (keep the `.github` folder).
2. Open the **Actions** tab. The **Build PostIt APK** workflow runs on every push (or press **Run workflow**).
3. When it turns green, open the run and download **PostIt-debug-apk** under *Artifacts*. Unzip it and install `app-debug.apk`.

Cloud sign-in setup (optional): see `SETUP.txt`.
