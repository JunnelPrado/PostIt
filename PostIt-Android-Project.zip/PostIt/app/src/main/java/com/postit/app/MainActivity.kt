@file:OptIn(ExperimentalMaterial3Api::class)

package com.postit.app

import android.content.Context
import android.content.SharedPreferences
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts.PickVisualMedia
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.DateFormat
import java.util.Date
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.lazy.staggeredgrid.LazyVerticalStaggeredGrid
import androidx.compose.foundation.lazy.staggeredgrid.StaggeredGridCells
import androidx.compose.foundation.lazy.staggeredgrid.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.material.icons.filled.Close
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { PostItApp() }
    }
}

data class Memory(val file: String, val caption: String, val time: Long)

fun load(p: SharedPreferences): List<Memory> {
    val a = JSONArray(p.getString("memories", "[]"))
    return (0 until a.length()).map { val o = a.getJSONObject(it); Memory(o.getString("f"), o.getString("c"), o.getLong("t")) }
}

fun save(p: SharedPreferences, l: List<Memory>) {
    val a = JSONArray(l.map { JSONObject().put("f", it.file).put("c", it.caption).put("t", it.time) })
    p.edit().putString("memories", a.toString()).apply()
}

@Composable
fun Tile(m: Memory, ratio: Float, onOpen: () -> Unit, onDelete: () -> Unit) {
    val ctx = LocalContext.current
    Box(Modifier.fillMaxWidth().aspectRatio(ratio).clip(RoundedCornerShape(14.dp)).clickable { onOpen() }) {
        AsyncImage(File(ctx.filesDir, m.file), m.caption, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        if (m.caption.isNotEmpty()) {
            Text(
                m.caption, color = Color.White, maxLines = 2, overflow = TextOverflow.Ellipsis,
                modifier = Modifier.align(Alignment.BottomStart).fillMaxWidth()
                    .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xAA000000)))).padding(10.dp)
            )
        }
        IconButton(onDelete, Modifier.align(Alignment.TopEnd)) { Icon(Icons.Filled.Delete, "Delete", tint = Color.White) }
    }
}

@Composable
fun SwitchRow(title: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(title, Modifier.weight(1f)); Switch(checked, onChange)
    }
}

@Composable
fun PostItApp() {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("postit", Context.MODE_PRIVATE) }
    var dark by remember { mutableStateOf(prefs.getBoolean("dark", false)) }
    var cols by remember { mutableIntStateOf(prefs.getInt("cols", 2)) }
    var newest by remember { mutableStateOf(prefs.getBoolean("newest", true)) }
    var memories by remember { mutableStateOf(load(prefs)) }
    var settings by remember { mutableStateOf(false) }
    var pending by remember { mutableStateOf<Uri?>(null) }
    var caption by remember { mutableStateOf("") }
    var confirmClear by remember { mutableStateOf(false) }
    var viewing by remember { mutableStateOf<Memory?>(null) }
    var style by remember { mutableStateOf(prefs.getString("style", "mosaic") ?: "mosaic") }

    val picker = rememberLauncherForActivityResult(PickVisualMedia()) { uri -> pending = uri; caption = "" }
    fun commit(l: List<Memory>) { memories = l; save(prefs, l) }
    BackHandler(settings) { settings = false }

    MaterialTheme(colorScheme = if (dark) darkColorScheme() else lightColorScheme()) {
        if (settings) {
            Scaffold(topBar = {
                TopAppBar(title = { Text("Settings") }, navigationIcon = {
                    IconButton({ settings = false }) { Icon(Icons.Filled.ArrowBack, "Back") }
                })
            }) { pad ->
                Column(Modifier.padding(pad).padding(16.dp).verticalScroll(rememberScrollState())) {
                    SwitchRow("Dark mode", dark) { dark = it; prefs.edit().putBoolean("dark", it).apply() }
                    SwitchRow("Newest memories first", newest) { newest = it; prefs.edit().putBoolean("newest", it).apply() }
                    Text("Pictures per row", Modifier.padding(top = 8.dp))
                    Row(Modifier.padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        for (n in 1..3) FilterChip(selected = cols == n, onClick = { cols = n; prefs.edit().putInt("cols", n).apply() }, label = { Text("$n") })
                    }
                    Text("Grid style", Modifier.padding(top = 8.dp))
                    Row(Modifier.padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        for ((k, label) in listOf("grid" to "Grid", "masonry" to "Masonry", "mosaic" to "Mosaic")) {
                            FilterChip(selected = style == k, onClick = { style = k; prefs.edit().putString("style", k).apply() }, label = { Text(label) })
                        }
                    }
                    Spacer(Modifier.height(16.dp))
                    Button({ confirmClear = true }, colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)) {
                        Text("Delete all memories (${memories.size})")
                    }
                    Text("Developed by Junnel Entoma", Modifier.fillMaxWidth().padding(top = 24.dp), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center)
                }
            }
        } else {
            val list = if (newest) memories.sortedByDescending { it.time } else memories.sortedBy { it.time }
            Scaffold(
                topBar = {
                    TopAppBar(title = { Text("PostIt") }, actions = {
                        IconButton({ settings = true }) { Icon(Icons.Filled.Settings, "Settings") }
                    })
                },
                floatingActionButton = {
                    FloatingActionButton({ picker.launch(PickVisualMediaRequest(PickVisualMedia.ImageOnly)) }) { Icon(Icons.Filled.Add, "Post a picture") }
                }
            ) { pad ->
                if (list.isEmpty()) {
                    Box(Modifier.fillMaxSize().padding(pad), Alignment.Center) { Text("No memories yet.\nTap + to post your first one.") }
                } else {
                    Column(Modifier.padding(pad)) {
                        val gap = 12.dp
                        val open: (Memory) -> Unit = { viewing = it }
                        val del: (Memory) -> Unit = { File(ctx.filesDir, it.file).delete(); commit(memories - it) }
                        when (style) {
                            "masonry" -> LazyVerticalStaggeredGrid(
                                StaggeredGridCells.Fixed(cols), Modifier.fillMaxSize(), contentPadding = PaddingValues(12.dp),
                                verticalItemSpacing = gap, horizontalArrangement = Arrangement.spacedBy(gap)
                            ) {
                                itemsIndexed(list, key = { _, m -> m.file }) { i, m ->
                                    Tile(m, listOf(1f, 0.75f, 1.25f, 0.85f)[i % 4], { open(m) }, { del(m) })
                                }
                            }
                            "mosaic" -> LazyVerticalGrid(
                                GridCells.Fixed(cols), Modifier.fillMaxSize(), contentPadding = PaddingValues(12.dp),
                                horizontalArrangement = Arrangement.spacedBy(gap), verticalArrangement = Arrangement.spacedBy(gap)
                            ) {
                                itemsIndexed(list, key = { _, m -> m.file }, span = { i, _ -> GridItemSpan(if (cols > 1 && i % 5 == 0) 2 else 1) }) { _, m ->
                                    Tile(m, 1f, { open(m) }, { del(m) })
                                }
                            }
                            else -> LazyVerticalGrid(
                                GridCells.Fixed(cols), Modifier.fillMaxSize(), contentPadding = PaddingValues(12.dp),
                                horizontalArrangement = Arrangement.spacedBy(gap), verticalArrangement = Arrangement.spacedBy(gap)
                            ) {
                                items(list, key = { it.file }) { m ->
                                    Card {
                                        AsyncImage(File(ctx.filesDir, m.file), m.caption, Modifier.fillMaxWidth().aspectRatio(1f).clickable { viewing = m }, contentScale = ContentScale.Crop)
                                        Row(Modifier.padding(start = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                                            Column(Modifier.weight(1f)) {
                                                if (m.caption.isNotEmpty()) Text(m.caption, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                                Text(DateFormat.getDateInstance().format(Date(m.time)), style = MaterialTheme.typography.labelSmall)
                                            }
                                            IconButton({ del(m) }) { Icon(Icons.Filled.Delete, "Delete") }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        pending?.let { uri ->
            AlertDialog(
                onDismissRequest = { pending = null }, title = { Text("New memory") },
                text = {
                    Column {
                        AsyncImage(uri, null, Modifier.fillMaxWidth().height(200.dp), contentScale = ContentScale.Crop)
                        Spacer(Modifier.height(8.dp))
                        OutlinedTextField(caption, { caption = it }, label = { Text("Caption") })
                    }
                },
                confirmButton = {
                    TextButton({
                        val name = "img_${System.currentTimeMillis()}"
                        ctx.contentResolver.openInputStream(uri)?.use { i -> File(ctx.filesDir, name).outputStream().use { o -> i.copyTo(o) } }
                        commit(memories + Memory(name, caption.trim(), System.currentTimeMillis()))
                        pending = null
                    }) { Text("Post") }
                },
                dismissButton = { TextButton({ pending = null }) { Text("Cancel") } }
            )
        }
        viewing?.let { m ->
            Dialog(onDismissRequest = { viewing = null }, properties = DialogProperties(usePlatformDefaultWidth = false)) {
                Box(Modifier.fillMaxSize().background(Color.Black).clickable { viewing = null }) {
                    AsyncImage(File(ctx.filesDir, m.file), m.caption, Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
                    IconButton({ viewing = null }, Modifier.align(Alignment.TopEnd).padding(8.dp)) { Icon(Icons.Filled.Close, "Close", tint = Color.White) }
                    if (m.caption.isNotEmpty()) Text(m.caption, color = Color.White, modifier = Modifier.align(Alignment.BottomCenter).padding(16.dp))
                }
            }
        }
        if (confirmClear) {
            AlertDialog(
                onDismissRequest = { confirmClear = false }, title = { Text("Delete all memories?") }, text = { Text("This cannot be undone.") },
                confirmButton = { TextButton({ memories.forEach { File(ctx.filesDir, it.file).delete() }; commit(emptyList()); confirmClear = false }) { Text("Delete") } },
                dismissButton = { TextButton({ confirmClear = false }) { Text("Cancel") } }
            )
        }
    }
}
