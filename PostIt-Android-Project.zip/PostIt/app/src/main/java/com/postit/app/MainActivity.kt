@file:OptIn(ExperimentalMaterial3Api::class)

package com.postit.app

import android.app.Activity
import android.content.Context
import android.os.Build
import android.content.SharedPreferences
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts.PickVisualMedia
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.DateFormat
import java.util.Date
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.lazy.staggeredgrid.LazyVerticalStaggeredGrid
import androidx.compose.foundation.lazy.staggeredgrid.StaggeredGridCells
import androidx.compose.foundation.lazy.staggeredgrid.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.material.icons.filled.Close
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.border
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.StartOffset
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.tween
import androidx.compose.ui.composed
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.filled.Edit
import androidx.compose.ui.unit.Dp
import androidx.compose.animation.core.LinearEasing
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.ui.viewinterop.AndroidView
import android.widget.ImageView
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { PostItApp() }
    }
}

data class Memory(val file: String, val caption: String, val time: Long, val pinned: Boolean = false, val body: String = "", val note: Boolean = false)

fun load(p: SharedPreferences): List<Memory> {
    val a = JSONArray(p.getString("memories", "[]"))
    return (0 until a.length()).map { val o = a.getJSONObject(it); Memory(o.getString("f"), o.getString("c"), o.getLong("t"), o.optBoolean("p", false), o.optString("b", ""), o.optBoolean("n", false)) }
}

fun save(p: SharedPreferences, l: List<Memory>) {
    val a = JSONArray(l.map { JSONObject().put("f", it.file).put("c", it.caption).put("t", it.time).put("p", it.pinned).put("b", it.body).put("n", it.note) })
    p.edit().putString("memories", a.toString()).apply()
}

val FLOAT_STYLES = listOf("off" to "Off", "bob" to "Float", "sway" to "Sway", "drift" to "Drift", "pulse" to "Pulse")

/** Makes a picture gently float. Each picture starts at a different phase so the page feels alive. */
fun Modifier.floating(style: String, index: Int): Modifier = if (style == "off") this else composed {
    val tr = rememberInfiniteTransition(label = "float")
    val v by tr.animateFloat(
        -1f, 1f,
        infiniteRepeatable(tween(2600, easing = FastOutSlowInEasing), RepeatMode.Reverse, StartOffset((index * 370) % 2600)),
        label = "v"
    )
    graphicsLayer {
        when (style) {
            "bob" -> translationY = v * 6f * density
            "sway" -> { rotationZ = v * 2.5f; translationY = v * 2f * density }
            "drift" -> { translationX = v * 5f * density; translationY = (v * v - 0.5f) * 8f * density }
            "pulse" -> { scaleX = 1f + v * 0.03f; scaleY = 1f + v * 0.03f }
        }
    }
}

/** Animated gradient "PostIt" logo with a tilted sticky-note badge and tagline. */
@Composable
fun PostItTitle(themed: Boolean) {
    val tr = rememberInfiniteTransition(label = "title")
    val shift by tr.animateFloat(0f, 300f, infiniteRepeatable(tween(3500, easing = LinearEasing), RepeatMode.Restart), label = "shift")
    val colors = if (themed) listOf(Color.White, Color(0xFFFFB3C7), Color(0xFF9BF6FF), Color.White)
    else listOf(Color(0xFF7C4DFF), Color(0xFFFF4081), Color(0xFFFF9100), Color(0xFF7C4DFF))
    val brush = Brush.linearGradient(colors, start = Offset(shift, 0f), end = Offset(shift + 300f, 0f), tileMode = TileMode.Repeated)
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier.graphicsLayer { rotationZ = -8f }.size(36.dp)
                .shadow(6.dp, RoundedCornerShape(9.dp)).clip(RoundedCornerShape(9.dp))
                .background(Brush.linearGradient(listOf(Color(0xFFFFEB3B), Color(0xFFFFB300)))),
            contentAlignment = Alignment.Center
        ) { Text("\uD83D\uDCCC", fontSize = 19.sp) }
        Spacer(Modifier.width(10.dp))
        Column {
            Text(
                "PostIt",
                style = TextStyle(
                    brush = brush, fontSize = 27.sp, fontWeight = FontWeight.Black, letterSpacing = 1.sp,
                    shadow = Shadow(Color.Black.copy(alpha = 0.25f), Offset(0f, 3f), 6f)
                )
            )
            Text(
                "YOUR MEMORIES, PINNED", fontSize = 9.sp, letterSpacing = 1.6.sp, fontWeight = FontWeight.Medium,
                color = if (themed) Color.White.copy(alpha = 0.8f) else MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
fun PinButton(pinned: Boolean, onPin: () -> Unit, modifier: Modifier = Modifier, size: Dp = 32.dp) {
    Box(
        modifier.padding(if (size < 30.dp) 4.dp else 8.dp).size(size).clip(CircleShape)
            .background(if (pinned) Color(0xFFE53935) else Color.Black.copy(alpha = 0.4f))
            .clickable { onPin() },
        contentAlignment = Alignment.Center
    ) {
        Text("\uD83D\uDCCC", fontSize = (size.value * 0.5f).sp, modifier = Modifier.graphicsLayer { rotationZ = if (pinned) 0f else 35f; alpha = if (pinned) 1f else 0.7f })
    }
}

/** Compact, notes-app style card: a small picture thumbnail (or a sticky note) with title/preview and date. */
@Composable
fun Tile(
    m: Memory, ratio: Float, index: Int, floatStyle: String,
    onOpen: () -> Unit, onDelete: () -> Unit, onPin: () -> Unit, glass: Boolean = false
) {
    val ctx = LocalContext.current
    val shape = RoundedCornerShape(12.dp)
    val container = when {
        m.note && glass -> Color(0xFFFFEB3B).copy(alpha = 0.28f)
        m.note -> Color(0xFFFFF3B0)
        glass -> Color.Black.copy(alpha = 0.35f)
        else -> MaterialTheme.colorScheme.surfaceVariant
    }
    val content = when {
        m.note && !glass -> Color(0xFF3B3200)
        glass -> Color.White
        else -> MaterialTheme.colorScheme.onSurfaceVariant
    }
    Column(
        Modifier.fillMaxWidth().floating(floatStyle, index).clip(shape).background(container)
            .then(if (glass) Modifier.border(1.dp, Color.White.copy(alpha = 0.3f), shape) else Modifier)
            .clickable { onOpen() }
    ) {
        if (!m.note) {
            Box(Modifier.fillMaxWidth().aspectRatio(ratio)) {
                AsyncImage(File(ctx.filesDir, m.file), m.caption, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                PinButton(m.pinned, onPin, Modifier.align(Alignment.TopStart), 24.dp)
                IconButton(onDelete, Modifier.align(Alignment.TopEnd).size(32.dp)) { Icon(Icons.Filled.Delete, "Delete", tint = Color.White, modifier = Modifier.size(16.dp)) }
            }
        } else {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                PinButton(m.pinned, onPin, Modifier, 24.dp)
                Spacer(Modifier.weight(1f))
                IconButton(onDelete, Modifier.size(32.dp)) { Icon(Icons.Filled.Delete, "Delete", tint = content, modifier = Modifier.size(16.dp)) }
            }
        }
        Column(Modifier.padding(start = 8.dp, end = 8.dp, bottom = 8.dp, top = if (m.note) 0.dp else 6.dp)) {
            if (m.caption.isNotEmpty()) Text(m.caption, color = content, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.SemiBold)
            if (m.note && m.body.isNotEmpty()) Text(m.body, color = content, maxLines = 5, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall)
            Text(DateFormat.getDateInstance(DateFormat.SHORT).format(Date(m.time)), color = content.copy(alpha = 0.65f), style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(top = 2.dp))
        }
    }
}

@Composable
fun SwitchRow(title: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(title, Modifier.weight(1f)); Switch(checked, onChange)
    }
}

@Composable
fun PostItApp() {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("postit", Context.MODE_PRIVATE) }
    var dark by remember { mutableStateOf(prefs.getBoolean("dark", false)) }
    var cols by remember { mutableIntStateOf(prefs.getInt("cols", 3)) }
    var newest by remember { mutableStateOf(prefs.getBoolean("newest", true)) }
    var memories by remember { mutableStateOf(load(prefs)) }
    var settings by remember { mutableStateOf(false) }
    var pending by remember { mutableStateOf<Uri?>(null) }
    var caption by remember { mutableStateOf("") }
    var confirmClear by remember { mutableStateOf(false) }
    var viewing by remember { mutableStateOf<Memory?>(null) }
    var noteOpen by remember { mutableStateOf(false) }
    var noteEditing by remember { mutableStateOf<Memory?>(null) }
    var noteTitle by remember { mutableStateOf("") }
    var noteBody by remember { mutableStateOf("") }
    fun editNote(m: Memory?) { noteEditing = m; noteTitle = m?.caption ?: ""; noteBody = m?.body ?: ""; noteOpen = true }
    var style by remember { mutableStateOf(prefs.getString("style", "mosaic") ?: "mosaic") }
    var floatStyle by remember { mutableStateOf(prefs.getString("floatStyle", "bob") ?: "bob") }

    var bgKind by remember { mutableStateOf(prefs.getString("bgKind", "aurora") ?: "aurora") }
    var bgPhoto by remember { mutableStateOf(prefs.getString("bgPhoto", "") ?: "") }
    var bgAnimated by remember { mutableStateOf(prefs.getBoolean("bgAnimated", true)) }
    var bgSparkles by remember { mutableStateOf(prefs.getBoolean("bgSparkles", true)) }
    var bgDim by remember { mutableFloatStateOf(prefs.getFloat("bgDim", 0.25f)) }
    var bgBlur by remember { mutableFloatStateOf(prefs.getFloat("bgBlur", 0f)) }

    val picker = rememberLauncherForActivityResult(PickVisualMedia()) { uri -> pending = uri; caption = "" }
    val bgPicker = rememberLauncherForActivityResult(PickVisualMedia()) { uri ->
        if (uri != null) {
            val name = "bg_${System.currentTimeMillis()}"
            ctx.contentResolver.openInputStream(uri)?.use { i -> File(ctx.filesDir, name).outputStream().use { o -> i.copyTo(o) } }
            if (bgPhoto.isNotEmpty()) File(ctx.filesDir, bgPhoto).delete()
            bgPhoto = name; bgKind = "custom"
            prefs.edit().putString("bgPhoto", name).putString("bgKind", "custom").apply()
        }
    }
    fun commit(l: List<Memory>) { memories = l; save(prefs, l) }
    BackHandler(settings) { settings = false }

    // Keep status/navigation bar icons readable on top of the background.
    val view = LocalView.current
    val lightBars = !dark && !(bgKind != "none" && !settings)
    SideEffect {
        val win = (view.context as Activity).window
        val c = WindowCompat.getInsetsController(win, view)
        c.isAppearanceLightStatusBars = lightBars
        c.isAppearanceLightNavigationBars = lightBars
    }

    MaterialTheme(colorScheme = if (dark) darkColorScheme() else lightColorScheme()) {
        if (settings) {
            Scaffold(topBar = {
                TopAppBar(title = { Text("Settings") }, navigationIcon = {
                    IconButton({ settings = false }) { Icon(Icons.Filled.ArrowBack, "Back") }
                })
            }) { pad ->
                Column(Modifier.padding(pad).padding(16.dp).verticalScroll(rememberScrollState())) {
                    SwitchRow("Dark mode", dark) { dark = it; prefs.edit().putBoolean("dark", it).apply() }
                    SwitchRow("Newest memories first", newest) { newest = it; prefs.edit().putBoolean("newest", it).apply() }
                    Text("Pictures per row", Modifier.padding(top = 8.dp))
                    Row(Modifier.padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        for (n in 1..4) FilterChip(selected = cols == n, onClick = { cols = n; prefs.edit().putInt("cols", n).apply() }, label = { Text("$n") })
                    }
                    Text("Grid style", Modifier.padding(top = 8.dp))
                    Row(Modifier.padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        for ((k, label) in listOf("grid" to "Grid", "masonry" to "Masonry", "mosaic" to "Mosaic")) {
                            FilterChip(selected = style == k, onClick = { style = k; prefs.edit().putString("style", k).apply() }, label = { Text(label) })
                        }
                    }
                    Text("Floating pictures", Modifier.padding(top = 8.dp))
                    Text("Make the pictures on your homepage float in a style you like.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Row(Modifier.padding(vertical = 8.dp).horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        for ((k, label) in FLOAT_STYLES) {
                            FilterChip(selected = floatStyle == k, onClick = { floatStyle = k; prefs.edit().putString("floatStyle", k).apply() }, label = { Text(label) })
                        }
                    }
                    Text("Homepage background", Modifier.padding(top = 16.dp), style = MaterialTheme.typography.titleMedium)
                    Text("Pick a live background for your homepage.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Row(Modifier.padding(vertical = 12.dp).horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        val photoFile = if (bgPhoto.isNotEmpty()) File(ctx.filesDir, bgPhoto) else null
                        val options = listOf("none" to "Off") + THEMES.map { it.key to it.label } + listOf("custom" to "Photo")
                        for ((k, label) in options) {
                            BgSwatch(k, label, bgKind == k, photoFile, dark) {
                                if (k == "custom" && photoFile == null) bgPicker.launch(PickVisualMediaRequest(PickVisualMedia.ImageOnly))
                                else { bgKind = k; prefs.edit().putString("bgKind", k).apply() }
                            }
                        }
                    }
                    if (bgKind == "custom") {
                        OutlinedButton({ bgPicker.launch(PickVisualMediaRequest(PickVisualMedia.ImageOnly)) }) { Text("Choose a different photo") }
                        Text("Photo dimming: ${(bgDim * 100).toInt()}%", Modifier.padding(top = 8.dp))
                        Slider(bgDim, { bgDim = it }, valueRange = 0f..0.8f, onValueChangeFinished = { prefs.edit().putFloat("bgDim", bgDim).apply() })
                        if (Build.VERSION.SDK_INT >= 31) {
                            Text("Photo blur: ${bgBlur.toInt()}")
                            Slider(bgBlur, { bgBlur = it }, valueRange = 0f..25f, onValueChangeFinished = { prefs.edit().putFloat("bgBlur", bgBlur).apply() })
                        }
                    } else if (bgKind != "none") {
                        SwitchRow("Animate background", bgAnimated) { bgAnimated = it; prefs.edit().putBoolean("bgAnimated", it).apply() }
                        SwitchRow("Floating sparkles", bgSparkles) { bgSparkles = it; prefs.edit().putBoolean("bgSparkles", it).apply() }
                    }
                    Spacer(Modifier.height(16.dp))
                    Button({ confirmClear = true }, colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)) {
                        Text("Delete all memories (${memories.size})")
                    }
                    Text("Developed by Junnel Entoma", Modifier.fillMaxWidth().padding(top = 24.dp), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center)
                }
            }
        } else {
            val list = (if (newest) memories.sortedByDescending { it.time } else memories.sortedBy { it.time }).sortedByDescending { it.pinned }
            val themed = bgKind != "none"
            Box(Modifier.fillMaxSize()) {
            if (themed) HomeBackground(
                bgKind, bgAnimated, bgSparkles, dark,
                if (bgPhoto.isNotEmpty()) File(ctx.filesDir, bgPhoto) else null,
                bgDim, bgBlur, Modifier.fillMaxSize()
            )
            Scaffold(
                containerColor = if (themed) Color.Transparent else MaterialTheme.colorScheme.background,
                topBar = {
                    TopAppBar(
                        title = { PostItTitle(themed) },
                        actions = { IconButton({ settings = true }) { Icon(Icons.Filled.Settings, "Settings") } },
                        colors = if (themed) TopAppBarDefaults.topAppBarColors(
                            containerColor = Color.Transparent, scrolledContainerColor = Color.Transparent,
                            titleContentColor = Color.White, actionIconContentColor = Color.White
                        ) else TopAppBarDefaults.topAppBarColors()
                    )
                },
                floatingActionButton = {
                    Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        SmallFloatingActionButton({ editNote(null) }) { Icon(Icons.Filled.Edit, "New note") }
                        FloatingActionButton({ picker.launch(PickVisualMediaRequest(PickVisualMedia.ImageOnly)) }) { Icon(Icons.Filled.Add, "Post a picture") }
                    }
                }
            ) { pad ->
                if (list.isEmpty()) {
                    Box(Modifier.fillMaxSize().padding(pad), Alignment.Center) { Text("No memories yet.\nTap + to post a picture or the pencil to write a note.", color = if (themed) Color.White else Color.Unspecified, textAlign = TextAlign.Center) }
                } else {
                    Column(Modifier.padding(pad)) {
                        val gap = 12.dp
                        val open: (Memory) -> Unit = { if (it.note) editNote(it) else viewing = it }
                        val del: (Memory) -> Unit = { File(ctx.filesDir, it.file).delete(); commit(memories - it) }
                        val pin: (Memory) -> Unit = { m -> commit(memories.map { if (it.file == m.file) it.copy(pinned = !it.pinned) else it }) }
                        when (style) {
                            "masonry" -> LazyVerticalStaggeredGrid(
                                StaggeredGridCells.Fixed(cols), Modifier.fillMaxSize(), contentPadding = PaddingValues(12.dp),
                                verticalItemSpacing = gap, horizontalArrangement = Arrangement.spacedBy(gap)
                            ) {
                                itemsIndexed(list, key = { _, m -> m.file }) { i, m ->
                                    Tile(m, listOf(1.3f, 1f, 1.6f, 1.15f)[i % 4], i, floatStyle, { open(m) }, { del(m) }, { pin(m) }, themed)
                                }
                            }
                            "mosaic" -> LazyVerticalGrid(
                                GridCells.Fixed(cols), Modifier.fillMaxSize(), contentPadding = PaddingValues(12.dp),
                                horizontalArrangement = Arrangement.spacedBy(gap), verticalArrangement = Arrangement.spacedBy(gap)
                            ) {
                                itemsIndexed(list, key = { _, m -> m.file }, span = { i, _ -> GridItemSpan(if (cols > 1 && i % 5 == 0) 2 else 1) }) { i, m ->
                                    Tile(m, if (cols > 1 && i % 5 == 0) 2.4f else 1.2f, i, floatStyle, { open(m) }, { del(m) }, { pin(m) }, themed)
                                }
                            }
                            else -> LazyVerticalGrid(
                                GridCells.Fixed(cols), Modifier.fillMaxSize(), contentPadding = PaddingValues(12.dp),
                                horizontalArrangement = Arrangement.spacedBy(gap), verticalArrangement = Arrangement.spacedBy(gap)
                            ) {
                                itemsIndexed(list, key = { _, m -> m.file }) { i, m ->
                                    Tile(m, 1.25f, i, floatStyle, { open(m) }, { del(m) }, { pin(m) }, themed)
                                }
                            }
                        }
                    }
                }
            }
            }
        }

        pending?.let { uri ->
            AlertDialog(
                onDismissRequest = { pending = null }, title = { Text("New memory") },
                text = {
                    Column {
                        AsyncImage(uri, null, Modifier.fillMaxWidth().height(200.dp), contentScale = ContentScale.Crop)
                        Spacer(Modifier.height(8.dp))
                        OutlinedTextField(caption, { caption = it }, label = { Text("Caption") })
                    }
                },
                confirmButton = {
                    TextButton({
                        val name = "img_${System.currentTimeMillis()}"
                        ctx.contentResolver.openInputStream(uri)?.use { i -> File(ctx.filesDir, name).outputStream().use { o -> i.copyTo(o) } }
                        commit(memories + Memory(name, caption.trim(), System.currentTimeMillis()))
                        pending = null
                    }) { Text("Post") }
                },
                dismissButton = { TextButton({ pending = null }) { Text("Cancel") } }
            )
        }
        viewing?.let { m ->
            Dialog(onDismissRequest = { viewing = null }, properties = DialogProperties(usePlatformDefaultWidth = false)) {
                Box(Modifier.fillMaxSize().background(Color.Black).clickable { viewing = null }) {
                    AsyncImage(File(ctx.filesDir, m.file), m.caption, Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
                    IconButton({ viewing = null }, Modifier.align(Alignment.TopEnd).padding(8.dp)) { Icon(Icons.Filled.Close, "Close", tint = Color.White) }
                    if (m.caption.isNotEmpty()) Text(m.caption, color = Color.White, modifier = Modifier.align(Alignment.BottomCenter).padding(16.dp))
                }
            }
        }
        if (confirmClear) {
            AlertDialog(
                onDismissRequest = { confirmClear = false }, title = { Text("Delete all memories?") }, text = { Text("This cannot be undone.") },
                confirmButton = { TextButton({ memories.forEach { File(ctx.filesDir, it.file).delete() }; commit(emptyList()); confirmClear = false }) { Text("Delete") } },
                dismissButton = { TextButton({ confirmClear = false }) { Text("Cancel") } }
            )
        }

        if (noteOpen) {
            AlertDialog(
                onDismissRequest = { noteOpen = false },
                title = { Text(if (noteEditing == null) "New note" else "Edit note") },
                text = {
                    Column {
                        OutlinedTextField(noteTitle, { noteTitle = it }, label = { Text("Title") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                        Spacer(Modifier.height(8.dp))
                        OutlinedTextField(noteBody, { noteBody = it }, label = { Text("Note") }, minLines = 5, modifier = Modifier.fillMaxWidth())
                    }
                },
                confirmButton = {
                    TextButton({
                        val e = noteEditing
                        if (e == null) commit(memories + Memory("note_${System.currentTimeMillis()}", noteTitle.trim(), System.currentTimeMillis(), false, noteBody.trim(), true))
                        else commit(memories.map { if (it.file == e.file) it.copy(caption = noteTitle.trim(), body = noteBody.trim()) else it })
                        noteOpen = false
                    }, enabled = noteTitle.isNotBlank() || noteBody.isNotBlank()) { Text("Save") }
                },
                dismissButton = { TextButton({ noteOpen = false }) { Text("Cancel") } }
            )
        }

        // Opening screen: app icon in the middle, developer credit at the lower part.
        var showSplash by remember { mutableStateOf(true) }
        LaunchedEffect(Unit) { delay(1800); showSplash = false }
        val splashAlpha by animateFloatAsState(if (showSplash) 1f else 0f, tween(500), label = "splash")
        if (showSplash || splashAlpha > 0f) {
            Box(
                Modifier.fillMaxSize().graphicsLayer { alpha = splashAlpha }
                    .background(Brush.verticalGradient(listOf(Color(0xFF1B1442), Color(0xFF0F6E7A))))
                    .clickable(enabled = false) {}
            ) {
                AndroidView(
                    factory = { c -> ImageView(c).apply { setImageResource(R.mipmap.ic_launcher) } },
                    modifier = Modifier.align(Alignment.Center).size(120.dp)
                )
                Text(
                    "Developed by: Junnel Entoma", color = Color.White, style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 32.dp)
                )
            }
        }
    }
}
